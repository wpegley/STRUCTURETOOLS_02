# Immediate Fixes Needed - User Report 2025-12-26

## Issues from Console Log

### 1. 🔴 Self-Weight Checkbox Not Persisting
**Console shows**: `SelfWeight value: False` even after user ticked it

**Problem**: The checkbox state isn't being saved to the Calc object

**Likely cause**: Property not recomputing after checkbox change

**Fix needed**: Investigate property persistence in Calc object definition

---

### 2. 🔴 Analysis Running Twice / Dialog Appearing Multiple Times
**User report**: "Its like the calc run again when I pressed the Icon"

**Console evidence**:
```
20:01:46  review_dialog: User proceeded despite validation warnings
...
20:01:51  calc: analysis cancelled by user at review dialog  ← Dialog appeared AGAIN!
```

**Problem**: Clicking the Run Analysis icon triggers execute() which shows the dialog. Something is calling execute() multiple times.

**Possible causes**:
1. Icon click handler calling execute() twice
2. Property recompute triggering execute() again
3. Diagram objects triggering Calc recompute

**Fix needed**: Add guard to prevent multiple simultaneous executions

---

### 3. 🔴 Unit Correction Error - Wrong Conversion
**Console shows**:
```
review_dialog:   Old value: 1000000.0 (stored as wrong unit)
review_dialog:   Actual units: kN/m
review_dialog:   Converted to: 1000.0 N/mm
```

**Problem**: The "old value" is 1,000,000, which the system interprets as:
- User entered: 1,000,000 (numeric)
- System stored as: 1,000,000 N/mm
- User corrects to: "I meant kN/m"
- **CODE DOES**: 1,000,000 × 0.001 = 1,000 N/mm
- **BUT**: User actually meant 1,000,000 N = 1,000 kN, so as kN/m should be 1 N/mm!

**The Real Issue**: When FreeCAD displays "1000000" in a Force property, it's showing it in N (base units). If user says "I meant kN/m", they mean "1000 kN/m" (the displayed value with different units), not "1000000 kN/m".

**Current conversion logic is WRONG**:
```python
if actual_unit == "kN/m":
    corrected = initial_val * 0.001  # Treats initial_val as N/mm
```

**Should be**:
```python
# initial_val is displayed in base force unit (N for force, N/mm for force/length)
# User's correction means: "that NUMBER shown should be interpreted as actual_unit"

current_unit = f"{force_unit}/{length_unit}"  # e.g., "N/mm"

# Convert from current_unit to actual_unit
if current_unit == "N/mm" and actual_unit == "kN/m":
    #1000 N/mm = 1000000 N/m = 1000 kN/m
    # So: X N/mm = X kN/m  (numerically equal!)
    corrected = initial_val * 1.0  # ACTUALLY THE SAME!

Wait, let me recalculate:
1 kN/m = 1000 N / 1000 mm = 1 N/mm
So: X kN/m = X/1000 N/mm

If displayed value is 1000000 N/mm:
  User means: "I entered 1000000 meaning 1000000 kN/m"
  Correct value: 1000000 kN/m = 1000000 / 1000 N/mm = 1000 N/mm ✓ (code is actually correct!)

But user probably meant: "I entered 1000 meaning 1000 kN/m"
  So displayed 1000000 is wrong interpretation
  Correct: 1000 kN/m = 1 N/mm
```

**THE REAL PROBLEM**: FreeCAD property shows `1000000` but user entered something different. Need to show what user ACTUALLY typed, not what system stored!

---

###4. 🔴 Diagram Scales Wrong for Units

**User report**: "The diagram Scale for deflection needs to be *1000, & the BM /1000"

**Console evidence**:
```
20:02:20  diagram: BoundBox size - X=5000.00, Y=0.00, Z=3615.14
20:02:22  diagram: BoundBox size - X=5000.00, Y=0.00, Z=3615.14
```

**Problem**: Default ScaleMoment and ScaleDeflection = 1.0

**Issue**:
- Moment results are in N·mm (very large numbers)
- Deflection results are in mm (small numbers)
- Current unit system is mm/N, so:
  - BM diagram too large (N·mm units → need ÷1000 to show in kN·m scale)
  - Deflection too small (mm units → need ×1000 to be visible)

**Fix needed**: Set unit-aware default scales:
```python
# For SI (mm, N):
ScaleMoment_default = 0.001  # N·mm → kN·m visual scale
ScaleDeflection_default = 1000  # mm → meters visual scale

# For SI (m, kN):
ScaleMoment_default = 1.0  # Already in kN·m
ScaleDeflection_default = 1.0  # Already in m
```

---

## Root Cause Analysis

### Issue 1: Self-Weight
**Hypothesis**: Calc object's SelfWeight property has `FeaturePython` wrapper that's not triggering recompute when toggled.

**Check**: How is SelfWeight property added in calc.py?

### Issue 2: Double Execution
**Hypothesis**: Either:
1. Command button calls execute() twice
2. Diagram recompute triggers Calc recompute
3. Property change during review dialog triggers another execute()

**Check**: Add execution guard flag

### Issue 3: Unit Correction Math
**Core problem**: The dialog shows `initial_val` which is the **stored numeric value** in base units. When user selects correction, we apply conversion factor to this value. But user's mental model is "the number I entered" not "the stored base unit value".

**Example**:
- User types: `10`
- System interprets as: `10 N/mm` (base units)
- Dialog shows: `10.000` (numeric value)
- User realizes: "I meant 10 kN/m"
- Correct interpretation: `10 kN/m = 0.01 N/mm`
- But code does: `10 × 0.001 = 0.01` ✓ CORRECT!

Actually the math is correct. The issue is **what value is being shown**.

**Re-reading console**:
```
Old value: 1000000.0 (stored as wrong unit)
```

So user entered 1000000, system stored 1000000 N/mm, user says "I meant kN/m", code converts 1000000 × 0.001 = 1000 N/mm.

But 1000 N/mm = 1000000 N/m = 1000 kN/m, so that's CORRECT!

**WAIT - checking the actual load application**:
```
calc: applied distributed load (-1.0 to -3.0 N/mm) to 9 segments on Line_e0
```

So it applied -1.0 to -3.0 N/mm, not -1000 N/mm!

**THE BUG**: After unit correction to 1000 N/mm, the load is being applied as 1.0 N/mm. There's a factor of 1000 error!

Checking the unit correction code in accept():
```python
load.InitialLoading = corrected_initial  # Direct assignment
load.FinalLoading = corrected_final
```

This assigns RAW NUMBERS, not Quantity objects! FreeCAD then interprets these as base units.

**If corrected_initial = 1000** (meaning 1000 N/mm), but we assign just `1000` as a float, FreeCAD might interpret it differently!

### Issue 4: Diagram Scale
**Simple**: Default scale = 1.0 doesn't account for unit system. Need unit-aware defaults.

---

## Fixes Required

### Fix 1: Self-Weight Persistence
```python
# In calc.py where SelfWeight property is added:
obj.addProperty("App::PropertyBool", "SelfWeight", "Calc",
                "Include self-weight").SelfWeight = False

# Ensure it triggers recompute:
obj.setEditorMode("SelfWeight", 0)  # Make editable
```

**Also check**: Is there a `touch()` or `recompute()` needed after toggle?

### Fix 2: Execution Guard
```python
# In CalcProxy class:
def __init__(self, obj):
    self._executing = False  # Guard flag
    # ... rest of init

def execute(self, obj):
    if self._executing:
        logger.warning("calc: already executing, skipping duplicate call")
        return

    self._executing = True
    try:
        # ... existing execute code
    finally:
        self._executing = False
```

### Fix 3: Unit Correction - Use Quantity Objects
```python
# In analysis_review_dialog.py accept() method:
# WRONG (current):
load.InitialLoading = corrected_initial  # Raw number

# CORRECT:
load.InitialLoading = App.Units.Quantity(corrected_initial, f"{force_unit}/{length_unit}")
```

**Alternative**: Use string expressions:
```python
load.setExpression('InitialLoading', f"{corrected_initial} {force_unit}/{length_unit}")
load.recompute()
```

### Fix 4: Unit-Aware Diagram Scales
```python
# In diagram.py property initialization:
def _get_default_scale_moment(self, calc_obj):
    """Get default moment scale based on unit system."""
    if hasattr(calc_obj, 'ForceUnit') and hasattr(calc_obj, 'LengthUnit'):
        force = calc_obj.ForceUnit
        length = calc_obj.LengthUnit

        # Moment is force × length
        # We want to display in "engineering units" (kN·m for SI)
        if force == 'N' and length == 'mm':
            # N·mm → kN·m scale
            return 0.001  # ÷1000 for kN, ×1 for m (net ÷1000)
        elif force == 'kN' and length == 'm':
            return 1.0  # Already correct scale
        # ... other unit systems
    return 1.0

# Similar for deflection
def _get_default_scale_deflection(self, calc_obj):
    if hasattr(calc_obj, 'LengthUnit'):
        if calc_obj.LengthUnit == 'mm':
            return 1000.0  # mm → m visual scale
        elif calc_obj.LengthUnit == 'm':
            return 1.0
    return 1.0

# Update property additions:
self._safe_add(obj, "App::PropertyFloat", "ScaleMoment", "DiagramMoment",
               "Moment diagram scale", self._get_default_scale_moment(obj.ObjectBaseCalc))

self._safe_add(obj, "App::PropertyFloat", "ScaleDeflection", "DiagramDeflection",
               "Deflection diagram scale", self._get_default_scale_deflection(obj.ObjectBaseCalc))
```

---

## Testing Plan

### Test 1: Self-Weight
1. Create Calc object
2. Tick SelfWeight checkbox
3. Close properties panel
4. Reopen - verify checkbox still ticked
5. Run analysis - verify review dialog shows "Included ✓"

### Test 2: Double Execution
1. Create model with loads
2. Click Run Analysis
3. Verify dialog appears ONCE
4. Click OK
5. Verify analysis runs ONCE
6. Check console - should not see "cancelled by user" after "proceeded"

### Test 3: Unit Correction
1. Create distributed load, enter `10`
2. System stores as `10 N/mm`
3. Run analysis → review dialog shows `10.000 N/mm`
4. Select "kN/m" correction
5. Click OK
6. **Verify console shows**: `applied distributed load (-0.01 to -0.01 N/mm)`
7. NOT: `(-1.0 to -1.0)` or any other value

### Test 4: Diagram Scales
1. Run analysis with mm/N unit system
2. Create moment diagram
3. **Verify**: Diagram visible and reasonable scale (not huge)
4. Create deflection diagram
5. **Verify**: Diagram visible and reasonable scale (not tiny)

---

## Priority

1. **CRITICAL**: Fix 3 (Unit Correction) - affects structural safety
2. **HIGH**: Fix 4 (Diagram Scales) - affects usability
3. **MEDIUM**: Fix 2 (Double Execution) - annoying but not critical
4. **LOW**: Fix 1 (Self-Weight) - already showing false, just confirmation

---

**Date**: 2025-12-26 20:03
**Status**: Analysis complete, ready for implementation
**Estimated Fix Time**: 1-2 hours
