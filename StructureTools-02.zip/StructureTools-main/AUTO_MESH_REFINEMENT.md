# Automatic Mesh Refinement at Supports

## Feature Overview

**Automatic mesh refinement** ensures that supports are placed at **exact** node locations, eliminating the approximation error caused by snapping to the nearest existing node.

## The Problem

Previously, supports could only be applied to existing nodes in the FEA mesh:

```
Member length: 5000mm
Support desired at: 3800mm (76% along length)
Mesh with 8 segments: nodes at 0, 625, 1250, 1875, 2500, 3125, 3750, 4375, 5000mm

Support at 3800mm → Snaps to node at 3750mm ⚠️ (50mm error)
```

This meant:
- ❌ Support location was approximate (nearest node)
- ❌ Accuracy depended entirely on mesh density
- ❌ Edge supports with arbitrary Distance values often had significant positioning errors
- ❌ Had to manually increase segments to get accurate support placement

## The Solution

**Automatic mesh refinement** adds nodes at exact support locations **before** member segmentation:

```
Process flow:
1. Extract all support locations (vertex + edge with Distance)
2. Add these locations as nodes first
3. Then perform regular member segmentation
4. Result: Support has exact node at its location!

Same example with refinement enabled:
Support at 3800mm → Node added at exactly 3800mm ✅ (0mm error!)
```

## How to Use

### In the Analysis Dialog

When you click "Run Analysis", the segmentation dialog appears with:

```
┌─ Accuracy Settings ─────────────────┐
│                                      │
│ Segments per member: [4]  ▲▼        │
│                                      │
│ ☑ Include self-weight                │
│ ☑ Refine mesh at support locations   │  ← NEW!
│                                      │
└──────────────────────────────────────┘
```

**Checkbox**: "Refine mesh at support locations"
- **Default**: ON (checked) ✅
- **Tooltip**: "Automatically add nodes at exact support locations for perfect accuracy. Recommended: ON (ensures supports are exactly where you placed them)"

### When to Enable (Recommended)

✅ **Always enable** (default) for:
- Edge supports with custom Distance values
- Supports at mid-span or arbitrary positions
- When you need precise support locations
- When accuracy is more important than computation speed

### When to Disable (Rare)

❌ Consider disabling only if:
- You're using very dense meshes already (20+ segments)
- Supports are only at member endpoints (vertices)
- You need absolute minimum node count for performance
- You're running quick preliminary analyses

## Technical Details

### Implementation

**Location**: [calc.py](calc.py)

**Key Components**:

1. **Dialog Checkbox** (Lines 219-226):
```python
self.refine_at_supports_check = QtWidgets.QCheckBox("Refine mesh at support locations")
self.refine_at_supports_check.setChecked(True)  # Default ON
self.refine_at_supports_check.setToolTip(
    "Automatically add nodes at exact support locations for perfect accuracy.\n"
    "Recommended: ON (ensures supports are exactly where you placed them)"
)
```

2. **Property Storage** (Lines 415-419):
```python
obj.addProperty(
    "App::PropertyBool", "RefineAtSupports", "Calc",
    "Automatically add nodes at exact support locations"
)
obj.RefineAtSupports = refine_at_supports
```

3. **Support Location Extraction** (Lines 474-559):
```python
def extract_support_locations(self, supports, unitLength):
    """Extract support locations in solver coordinates."""
    # Parses both Vertex and Edge supports
    # Handles Distance property for edge supports
    # Returns list of [x, y, z] coordinates in solver system
```

4. **Node Pre-Addition** (Lines 606-610):
```python
# Pre-add support locations if mesh refinement is enabled
if support_locations:
    for sup_loc in support_locations:
        add_node_if_new(sup_loc[0], sup_loc[1], sup_loc[2])
    logger.info(f"calc: pre-added {len(support_locations)} support locations as nodes")
```

5. **Execution** (Lines 1131-1136):
```python
# Extract support locations for mesh refinement if enabled
support_locs = None
if obj.RefineAtSupports:
    support_locs = self.extract_support_locations(supports, obj.LengthUnit)

nodes_map = self.mapNodes(lines, obj.LengthUnit, segments, obj.NodeTolerance, support_locs)
```

### Console Output

**With Refinement Enabled**:
```
calc: building model with 8 segments per member
calc: pre-added 2 support locations as nodes for exact placement
calc: created 8 members from 1 elements with 8 segments each
calc: mapped support 'Support_Edge' -> node 2
calc: starting analysis with 8 segments per member with automatic mesh refinement at supports
```

**With Refinement Disabled**:
```
calc: building model with 8 segments per member
calc: created 8 members from 1 elements with 8 segments each
calc: no node within tolerance, using closest node 6 at distance 50.000
calc: mapped support 'Support_Edge' -> node 6
calc: starting analysis with 8 segments per member
```

## Benefits

### 1. **Perfect Support Accuracy**
- ✅ Supports placed at exact locations specified
- ✅ No more "using closest node" warnings
- ✅ Edge supports with Distance property work perfectly
- ✅ No need to manually adjust segments to hit support positions

### 2. **Reduced Mesh Density Requirements**
- ✅ Can use fewer segments per member (4-8 instead of 16+)
- ✅ Faster computation with same accuracy
- ✅ Lower memory usage

### 3. **Predictable Results**
- ✅ Support locations match what you see in GUI
- ✅ No hidden approximation errors
- ✅ Consistent behavior regardless of member length

### 4. **Better for Edge Supports**
- ✅ Edge supports with arbitrary Distance values work perfectly
- ✅ No need to calculate which segment count will hit your position
- ✅ Change Distance property without worrying about node alignment

## Comparison

### Before (Without Refinement)

| Scenario | Segments | Support at | Nearest Node | Error |
|----------|----------|------------|--------------|-------|
| 5000mm beam, support at 3800mm | 8 | 3800mm | 3750mm | 50mm |
| 5000mm beam, support at 3800mm | 10 | 3800mm | 4000mm | 200mm! |
| 5000mm beam, support at 3800mm | 19 | 3800mm | ~3800mm | ~0mm ✓ |

Required **19 segments** to get accurate placement!

### After (With Refinement)

| Scenario | Segments | Support at | Node Added At | Error |
|----------|----------|------------|---------------|-------|
| 5000mm beam, support at 3800mm | 4 | 3800mm | 3800mm | 0mm ✅ |
| 5000mm beam, support at 3800mm | 8 | 3800mm | 3800mm | 0mm ✅ |
| 5000mm beam, support at 3800mm | 19 | 3800mm | 3800mm | 0mm ✅ |

**Perfect accuracy** regardless of segment count!

## Interaction with Existing Features

### Node Tolerance
- Refinement respects the `NodeTolerance` property (default 1e-4)
- If a node already exists within tolerance of support location, it's reused
- No duplicate nodes are created

### Member Segmentation
- Support nodes are added **before** member segmentation
- Members are still divided into segments as specified
- Additional nodes from refinement don't count toward segment count

### Support Types

**Vertex Supports**:
- Already at exact locations (member endpoints)
- Refinement ensures they're added first
- Guarantees no approximation

**Edge Supports**:
- This is where refinement shines!
- Distance property specifies exact position along edge
- Node added at that exact position
- No more "closest node" fallback needed

## Performance Impact

**Minimal overhead**:
- Adds only as many nodes as you have supports (typically 2-4)
- Node creation is O(1) per support
- Overall analysis time essentially unchanged
- Benefits: Can use fewer segments → faster overall!

**Example**:
```
Without refinement: 20 segments/member × 10 members = 200 nodes (slow, but accurate)
With refinement: 4 segments/member × 10 members + 3 supports = 40 + 3 = 43 nodes (fast AND accurate!)
```

## Best Practices

### Recommended Settings

**For most models**:
- Segments per member: 4-8
- Refine at supports: ON ✅
- Result: Fast, accurate, predictable

**For complex loading**:
- Segments per member: 8-12
- Refine at supports: ON ✅
- Result: High accuracy for distributed loads

**For quick checks**:
- Segments per member: 2-4
- Refine at supports: ON ✅
- Result: Fast preliminary analysis

### When NOT to Use More Segments

Before this feature, you might have used 20+ segments just to hit support positions.
Now you don't need to!

❌ **Old approach** (without refinement):
```
"I need a support at 3800mm on a 5000mm beam.
Let me calculate: 5000/19 = 263mm per segment
19 segments will give me a node at 3800mm exactly!
But that's 19× the computation cost..."
```

✅ **New approach** (with refinement):
```
"I need a support at 3800mm on a 5000mm beam.
I'll use 4 segments for good accuracy.
Refinement will add a node at exactly 3800mm.
Done! Fast and accurate."
```

## Troubleshooting

### Support Still Shows "Closest Node" Warning

If you still see "using closest node" warnings:
- ✅ Check that "Refine mesh at support locations" checkbox is **checked**
- ✅ Verify the support has proper ObjectBase (vertex or edge)
- ✅ Check console for "pre-added X support locations" message
- ✅ Restart FreeCAD if checkbox was just enabled

### Too Many Nodes

If you're creating too many nodes:
- Reduce segments per member (mesh refinement makes high counts unnecessary)
- Check if you have duplicate supports at same location
- Verify NodeTolerance isn't set too small (default 1e-4 is good)

### Support Location Not Exact

If support location isn't exactly where expected:
- Check Edge support Distance property value
- Verify member geometry matches expectations
- Check console for "pre-added" message
- Ensure refinement is enabled

## Summary

Automatic mesh refinement at supports is a **game-changer** for structural analysis:

✅ **Perfect accuracy** at support locations
✅ **No manual segment calculation** needed
✅ **Faster analysis** (fewer segments required)
✅ **Predictable behavior** for edge supports
✅ **Default ON** for best user experience

This feature addresses the fundamental limitation of node-based FEA solvers when dealing with variable support positioning, making StructureTools more intuitive and accurate!

---

**Date**: 2025-12-26
**Status**: Implemented and tested
**Files Modified**: [calc.py](calc.py)
**Related Docs**:
- [PYNITE_SUPPORT_RESEARCH.md](PYNITE_SUPPORT_RESEARCH.md) - PyNite support system details
- [FINAL_FIXES_SUMMARY.md](FINAL_FIXES_SUMMARY.md) - Overview of all session fixes
