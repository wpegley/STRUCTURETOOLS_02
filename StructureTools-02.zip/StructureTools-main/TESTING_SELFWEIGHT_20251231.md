# Testing Self-Weight Feature
## Date: 2025-12-31 Evening

---

## ⚠️ IMPORTANT: Your Console Log Shows File Opening, Not New Analysis!

### What Your Console Shows (19:44:31)
```
OpenGL version: 4.6.0 - Build 32.0.101.5330
diagram: document is restoring, suppressing error dialogs
diagram: filterMembersSelected - segmented match: 'Line_e0_s0'
...
```

**This is DOCUMENT RESTORE** (opening an old file), NOT new analysis!

### Why No Self-Weight Messages?
- Self-weight calculation happens ONLY during NEW analysis execution
- Old saved files were created BEFORE self-weight was added
- Document restore just loads saved data, doesn't re-run analysis

---

## ✅ How to Test Self-Weight Properly

### Step 1: Create NEW Document
```
File → New
(Don't open existing file!)
```

### Step 2: Create Simple Structure
1. **Line**: Structure → Line (draw simple beam)
2. **Material**: Structure → Material → Select S235 steel
3. **Section**: Structure → Section → Select HEB 200
4. **Assign**: Select Line → Structure → Assign Member (choose material and section)
5. **Support**: Structure → Support → Add fixed support at one end
6. **Support**: Structure → Support → Add roller at other end
7. **Load**: Structure → Load → Add 10 kN point load at midpoint

### Step 3: Run Analysis WITH Self-Weight
1. **Select the Line** in tree view
2. **Click "Calc" button** in Structure toolbar
3. **TICK the checkbox**: "Include self-weight (gravity load)" ✅
4. **Click OK**
5. **Wait for analysis** to complete

### Step 4: Check Console Output

You should see these messages in Report View:

```
calc: self-weight property set to True
calc: user confirmed analysis (self-weight: ENABLED)
calc: building model with 8 segments per member
calc: calculating self-weight for 1 members
calc:   Line: A=0.007810 m², ρ=7850 kg/m³
calc:     Self-weight: 0.601 kN/m (downward)
calc: applied self-weight to 8 member segments
calc: self-weight loads applied
calc: analyzing model...
```

### Step 5: Create Diagram
1. **Select the Calc object** in tree view
2. **Click "Diagram" button**
3. **Choose MomentZ or DeflectionY**
4. **Check results** - should show effects of self-weight

---

## 🔍 Expected Self-Weight Calculation

### For HEB 200 Steel Beam:
- **Section Area**: 7810 mm² = 0.007810 m²
- **Steel Density**: 7850 kg/m³
- **Gravity**: 9.81 m/s²
- **Calculation**: 0.007810 × 7850 × 9.81 = 601.3 N/m = 0.601 kN/m
- **Direction**: Downward (-Z)

### Console Should Show:
```
calc:   Line: A=0.007810 m², ρ=7850 kg/m³
calc:     Self-weight: 0.601 kN/m (downward)
```

---

## 🧪 Comparison Test

### Test 1: Without Self-Weight
1. Create structure as above
2. Run Calc WITHOUT ticking checkbox
3. Note deflection/moment values
4. Console: "self-weight: disabled"

### Test 2: With Self-Weight
1. Use SAME structure
2. Run Calc WITH checkbox ticked ✅
3. Note deflection/moment values
4. Console: "self-weight: ENABLED"

### Expected Results:
- **Deflections should INCREASE** (beam sags more under own weight)
- **Moments should INCREASE** (more bending from self-weight)
- **Diagram should show larger values** with self-weight enabled

---

## 📊 Debugging Output Locations

### 1. Property Assignment (calc.py:1789-1791)
```
calc: self-weight property set to True
```
**Confirms**: Checkbox value saved to property ✅

### 2. Analysis Confirmation (calc.py:1461-1463)
```
calc: user confirmed analysis (self-weight: ENABLED)
```
**Confirms**: Property read correctly at analysis start ✅

### 3. Calculation Start (calc.py:1137)
```
calc: calculating self-weight for 1 members
```
**Confirms**: applySelfWeight() method called ✅

### 4. Per-Member Calculation (calc.py:1181-1183)
```
calc:   Line: A=0.007810 m², ρ=7850 kg/m³
calc:     Self-weight: 0.601 kN/m (downward)
```
**Confirms**: Area and density found, weight calculated correctly ✅

### 5. Application Complete (calc.py:1203)
```
calc: applied self-weight to 8 member segments
```
**Confirms**: Distributed loads added to PyNite model ✅

### 6. Final Confirmation (calc.py:1484)
```
calc: self-weight loads applied
```
**Confirms**: applySelfWeight() completed successfully ✅

---

## ⚠️ Common Mistakes

### ❌ Opening Old File
- Old files don't have self-weight
- Opening file = document restore (no analysis)
- Console shows: "diagram: document is restoring"

### ✅ Creating New Structure
- New analysis = fresh calculation
- Console shows: "calc: user confirmed analysis"
- Self-weight calculated and applied

### ❌ Forgetting to Tick Checkbox
- Default is OFF for backward compatibility
- Console shows: "self-weight: disabled"

### ✅ Ticking Checkbox
- Checkbox must be ticked BEFORE clicking OK
- Console shows: "self-weight: ENABLED"

---

## 🔄 If You See No Self-Weight Messages

### Check These:

1. **Did you create NEW structure?**
   - Not open old file? ✅

2. **Did you TICK the checkbox?**
   - "Include self-weight (gravity load)" ✅

3. **Did you run NEW analysis?**
   - Click Calc button after structure changes? ✅

4. **Did you check Report View?**
   - View → Panels → Report View ✅

5. **Is there a material assigned?**
   - Line needs material with density ✅

6. **Is there a section assigned?**
   - Line needs section with area ✅

---

## 📝 Quick Test Checklist

```
[ ] Closed any open documents
[ ] Created NEW document (File → New)
[ ] Created simple beam structure
[ ] Assigned material (S235 steel)
[ ] Assigned section (HEB 200)
[ ] Added supports (fixed + roller)
[ ] Added at least one load
[ ] Selected Line in tree view
[ ] Clicked "Calc" button
[ ] TICKED "Include self-weight" checkbox ✅
[ ] Clicked OK
[ ] Opened Report View (View → Panels → Report View)
[ ] Searched console for "self-weight"
[ ] Found messages: "self-weight: ENABLED"
[ ] Found messages: "Self-weight: 0.601 kN/m"
[ ] Analysis completed successfully
[ ] Created diagram from Calc object
[ ] Diagram shows larger values than without self-weight
```

---

## 🎯 Success Criteria

You'll know self-weight is working when you see ALL of these:

```
✅ calc: self-weight property set to True
✅ calc: user confirmed analysis (self-weight: ENABLED)
✅ calc: calculating self-weight for 1 members
✅ calc:   Line: A=... m², ρ=... kg/m³
✅ calc:     Self-weight: ... kN/m (downward)
✅ calc: applied self-weight to ... member segments
✅ calc: self-weight loads applied
```

If you see "self-weight: disabled" instead, the checkbox wasn't ticked.

---

## 📞 What to Report

If self-weight still doesn't work after following these steps, provide:

1. **Console log from Report View** (copy full output)
2. **Confirmation you created NEW structure** (not opened old file)
3. **Screenshot of dialog** showing checkbox state
4. **Structure details**: material, section, loads, supports

---

**Status**: Implementation complete, awaiting user testing with NEW analysis
**Next**: Follow steps above to test properly
**Expected**: Console shows self-weight calculation messages during NEW analysis
