# Fixes Applied - 2025-12-26 Evening Session

## Issues Fixed

### 1. ✅ Unit Correction Bug (CRITICAL)
**Problem**: After unit correction, loads were being applied with wrong magnitude
**Console evidence**:
```
Converted to: 1000.0 N/mm
But applied: -1.0 to -3.0 N/mm  ← 1000× error!
```

**Root cause**: Direct assignment of raw float values instead of Quantity objects

**Fix applied**: [analysis_review_dialog.py:591-597](analysis_review_dialog.py#L591-L597)
```python
# OLD (wrong):
load.InitialLoading = corrected_initial  # Raw number

# NEW (correct):
force_unit = self.calc_obj.ForceUnit if hasattr(self.calc_obj, 'ForceUnit') else 'N'
length_unit = self.calc_obj.LengthUnit if hasattr(self.calc_obj, 'LengthUnit') else 'mm'
target_unit = f"{force_unit}/{length_unit}"

load.InitialLoading = App.Units.Quantity(corrected_initial, target_unit)
load.FinalLoading = App.Units.Quantity(corrected_final, target_unit)
```

**Result**: FreeCAD now correctly interprets the corrected values with proper units

---

### 2. ✅ Analysis Running Twice (HIGH)
**Problem**: Dialog appeared twice when clicking Run Analysis icon
**Console evidence**:
```
20:00:44  review_dialog: User proceeded despite validation warnings
...
20:01:51  calc: analysis cancelled by user at review dialog  ← Second dialog!
```

**Root cause**: No guard against re-entrant execution

**Fix applied**: [calc.py:1205-1218](calc.py#L1205-L1218)
```python
def execute(self, obj):
    """Run the structural analysis."""
    # Guard against re-entrant execution (prevents dialog appearing twice)
    if self._executing:
        import logging
        logger = logging.getLogger(__name__)
        logger.info("calc: already executing, skipping duplicate call")
        return

    self._executing = True
    try:
        return self._do_execute(obj)
    finally:
        self._executing = False

def _do_execute(self, obj):
    """Internal execute implementation."""
    # ... original execute code moved here
```

**Also added**: Initialization of guard flag in `__init__()` at line 367:
```python
self._executing = False  # Guard flag to prevent re-entrant execution
```

**Result**: Analysis will only run once per button click

---

### 3. ✅ Diagram Scales Unit-Aware (HIGH)
**Problem**: Default scales of 1.0 don't account for unit system
**User report**: "The diagram Scale for deflection needs to be *1000, & the BM /1000"
**Console evidence**: Huge bounding boxes for moment diagrams, tiny deflection diagrams

**Root cause**: Hardcoded default scale = 1.0 regardless of units

**Fix applied**: [diagram.py:369-404](diagram.py#L369-L404)

Added two helper methods:
```python
def _get_default_scale_moment(self, calc_obj):
    """Get default moment scale based on unit system."""
    if calc_obj and hasattr(calc_obj, 'ForceUnit') and hasattr(calc_obj, 'LengthUnit'):
        force = calc_obj.ForceUnit
        length = calc_obj.LengthUnit

        # Moment is force × length
        # We want to display in "engineering units" (kN·m for SI)
        if force == 'N' and length == 'mm':
            # N·mm → kN·m visual scale
            # Divide by 1000 to make it visible in kN·m scale
            return 0.001
        elif force == 'kN' and length == 'm':
            return 1.0  # Already in kN·m
        elif force == 'kN' and length == 'mm':
            # kN·mm → kN·m scale (divide by 1000 for mm→m)
            return 0.001
        elif force == 'N' and length == 'm':
            # N·m → kN·m scale (divide by 1000 for N→kN)
            return 0.001
    return 1.0

def _get_default_scale_deflection(self, calc_obj):
    """Get default deflection scale based on unit system."""
    if calc_obj and hasattr(calc_obj, 'LengthUnit'):
        if calc_obj.LengthUnit == 'mm':
            # mm → m visual scale (multiply to make visible)
            return 1000.0
        elif calc_obj.LengthUnit == 'm':
            return 1.0
        elif calc_obj.LengthUnit == 'in':
            # inches → feet visual scale
            return 12.0
        elif calc_obj.LengthUnit == 'ft':
            return 1.0
    return 1.0
```

**Updated property initialization** (lines 418-420, 434-436):
```python
# Moment scale
moment_scale = self._get_default_scale_moment(obj.ObjectBaseCalc) if hasattr(obj, 'ObjectBaseCalc') else 1.0
self._safe_add(obj, "App::PropertyFloat", "ScaleMoment", "DiagramMoment", "Moment diagram scale", moment_scale)

# Deflection scale
deflection_scale = self._get_default_scale_deflection(obj.ObjectBaseCalc) if hasattr(obj, 'ObjectBaseCalc') else 1.0
self._safe_add(obj, "App::PropertyFloat", "ScaleDeflection", "DiagramDeflection", "Deflection diagram scale", deflection_scale)
```

**Result**:
- For mm/N system: Moment scale = 0.001, Deflection scale = 1000.0
- For m/kN system: Moment scale = 1.0, Deflection scale = 1.0
- Diagrams now display at reasonable scales automatically

---

## Testing Checklist

After restarting FreeCAD, verify:

### Test 1: Unit Correction
- [ ] Create distributed load, enter value (e.g., 1000000)
- [ ] Run analysis → review dialog appears
- [ ] Go to Loads tab, select "kN/m" correction
- [ ] Verify conversion display shows correct value (e.g., "1000.0 N/mm")
- [ ] Click OK
- [ ] **Check console**: Should show "applied distributed load (-1000.0 to -1000.0 N/mm)"
- [ ] NOT: "(-1.0 to -1.0)" or any other scaled value

### Test 2: No Double Execution
- [ ] Click Run Analysis icon
- [ ] Review dialog appears ONCE
- [ ] Click OK
- [ ] Analysis runs
- [ ] **Check console**: Should NOT see "cancelled by user" after "proceeded"
- [ ] Should NOT see review dialog appear again

### Test 3: Diagram Scales
- [ ] Run analysis (mm/N unit system)
- [ ] Create moment diagram
- [ ] **Check properties**: ScaleMoment should be 0.001 (not 1.0)
- [ ] Diagram should be visible and reasonable size (not huge)
- [ ] Create deflection diagram
- [ ] **Check properties**: ScaleDeflection should be 1000.0 (not 1.0)
- [ ] Diagram should be visible and reasonable size (not tiny)

---

## Console Output Expected

### Successful Unit Correction
```
review_dialog: Correcting load 'Load_Distributed'
review_dialog:   Old value: 1000000.0 (stored as wrong unit)
review_dialog:   Actual units: kN/m
review_dialog:   Converted to: 1000.0 N/mm
calc: user applied unit corrections to 1 load(s)
calc:   - Load_Distributed: corrected to kN/m
calc: applied distributed load (-1000.0 to -1000.0 N/mm) to 9 segments on Line_e0
```

**Key**: The value applied should match "Converted to" value!

### No Double Execution
```
calc: starting analysis with 8 segments per member...
review_dialog: User proceeded despite validation warnings
calc: building model with 8 segments per member
calc: applied distributed load...
calc: running analysis...
calc: analysis complete
```

**Should NOT see**: "calc: already executing, skipping duplicate call" or "analysis cancelled by user"

### Unit-Aware Scales
```
diagram: creating moment diagram...
diagram: ScaleMoment = 0.001 (unit-aware default for mm/N)
diagram: creating deflection diagram...
diagram: ScaleDeflection = 1000.0 (unit-aware default for mm/N)
```

---

## Files Modified

1. **[analysis_review_dialog.py](analysis_review_dialog.py)**
   - Lines 591-597: Unit correction with Quantity objects

2. **[calc.py](calc.py)**
   - Line 367: Added `_executing` guard flag
   - Lines 1205-1220: Added execution guard and refactored to `_do_execute()`

3. **[diagram.py](diagram.py)**
   - Lines 369-404: Added `_get_default_scale_moment()` and `_get_default_scale_deflection()`
   - Lines 418-420: Use unit-aware moment scale
   - Lines 434-436: Use unit-aware deflection scale

---

## Known Limitations

### 1. Existing Diagram Objects
**Issue**: Diagrams created before this fix will still have ScaleMoment = 1.0 and ScaleDeflection = 1.0

**Workaround**:
- Delete old diagram objects
- Create new ones (will have correct default scales)
- OR manually adjust scale properties

### 2. Self-Weight Checkbox
**Status**: Still showing False in review dialog even when ticked
**Cause**: Property value IS actually False - checkbox isn't persisting
**Not fixed in this session**: Requires investigation of property persistence
**Workaround**: Verify SelfWeight checkbox is ticked BEFORE running analysis

---

## Impact Assessment

### Fix 1: Unit Correction (CRITICAL) ✅
**Before**: Corrected loads applied with 1000× error
**After**: Corrected loads applied with exact values
**Safety impact**: **MAJOR** - prevents structural analysis errors

### Fix 2: Double Execution (HIGH) ✅
**Before**: Dialog appears multiple times, confusing user
**After**: Dialog appears once, clean workflow
**UX impact**: **SIGNIFICANT** - much smoother experience

### Fix 3: Diagram Scales (HIGH) ✅
**Before**: BM diagrams huge, deflection diagrams invisible
**After**: Both display at reasonable scales automatically
**UX impact**: **SIGNIFICANT** - diagrams immediately usable

---

## Summary

**What was broken**:
- Unit corrections not being applied correctly (1000× error)
- Analysis running twice (dialog appearing multiple times)
- Diagram scales wrong for unit system (BM too large, deflection too small)

**What is now fixed**:
- ✅ Unit corrections use Quantity objects with explicit units
- ✅ Execution guard prevents re-entrant calls
- ✅ Diagram scales automatically set based on unit system

**What remains**:
- Self-weight checkbox persistence (separate issue, not critical)
- Unit continuity audit findings (gravity constant, density conversion, etc.)

---

**Session Date**: 2025-12-26 Evening
**Priority**: 1 (Critical) and 2 (High) fixes implemented
**Status**: ✅ Ready for testing
**Restart Required**: Yes - restart FreeCAD to load new code
