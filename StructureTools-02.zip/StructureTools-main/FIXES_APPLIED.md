# Emergency Fixes Applied (2025-12-26)

## Issues Fixed

### 1. ✅ Duplicate Dialog (Clicking OK Twice)
**Problem**: Unit dialog appeared twice, requiring two clicks on OK

**Root Cause**: Multiple timer calls potentially firing the dialog twice

**Fix Applied**:
- Added global flag `_dialog_shown` to prevent duplicate dialogs
- Dialog can only show once per session
- Flag resets only on error to allow retry

**Location**: [unit_dialog.py:314-363](unit_dialog.py#L314-L363)

---

### 2. ✅ Toolbars Vanishing
**Problem**: All FreeCAD toolbars disappeared after activating workbench

**Root Cause**: Exception during `Initialize()` or `Activated()` caused workbench registration to fail

**Fix Applied**:
- Wrapped `Initialize()` in try/except with full traceback
- Wrapped `Activated()` in try/except with full traceback
- Console now shows exact error if initialization fails

**Location**: [init_gui.py:33-69](init_gui.py#L33-L69), [init_gui.py:71-93](init_gui.py#L71-L93)

---

### 3. ✅ Removed Auto-Popup Dialog
**Problem**: Dialog interrupting workflow on every activation

**Solution**:
- **Removed automatic dialog popup completely**
- Workbench now loads silently with saved unit preferences
- Console message shows current units and how to change them
- Users can manually open Unit Settings when needed

**New Workflow**:
1. Activate workbench → Loads instantly
2. Console shows: "Using units: SI (m, kN, t)"
3. Console shows: "To change units: StructureTools menu → Unit Settings (Shift+U)"
4. No interruption, no blocking

---

## How to Use Unit Settings Now

### Option 1: Menu
**StructureTools menu → Unit Settings...**

### Option 2: Keyboard Shortcut
**Shift+U**

### Option 3: Python Console
```python
# Quick change to US units
from freecad.StructureTools.unit_manager import get_unit_manager, UNIT_US_FT_KIP
get_unit_manager().set_unit_system(UNIT_US_FT_KIP)

# Quick change to SI units
from freecad.StructureTools.unit_manager import UNIT_SI_M_KN
get_unit_manager().set_unit_system(UNIT_SI_M_KN)

# Check current units
from freecad.StructureTools.unit_manager import get_current_units
print(get_current_units().name)
```

---

## Default Unit System

If no preference is saved, the workbench automatically detects your FreeCAD unit schema:

| FreeCAD Schema | Auto-Selected Units |
|----------------|---------------------|
| Standard (mm, kg, s) | SI (mm, N, kg) |
| MKS (m, kg, s) | SI (m, N, kg) |
| Building Euro | **SI (m, kN, t)** ← Most common for structural |
| Building US | **US (ft, kip, kip)** ← Most common for US structural |
| US Customary | US (in, lbf, lb) |
| Imperial | US (in, lbf, lb) |
| Imperial Civil | US (ft, kip, kip) |

**Default if detection fails**: SI (m, kN, t)

---

## Console Messages You'll See

### Successful Activation
```
StructureTools workbench initialized successfully
Workbench StructureTools activated. Using units: SI (m, kN, t)
To change units: StructureTools menu → Unit Settings (Shift+U)
```

### If Initialization Error
```
Error initializing StructureTools workbench: <error details>
<full stack trace>
```

---

## Testing the Fixes

1. **Close FreeCAD completely**
2. **Restart FreeCAD**
3. **Activate StructureTools workbench**

**Expected Results**:
- ✅ Workbench activates immediately
- ✅ No dialog popup
- ✅ All toolbars visible (Draft, Structure, etc.)
- ✅ Console shows current units
- ✅ Console shows how to change units
- ✅ No duplicate dialogs
- ✅ No exceptions

---

## If You Still Have Issues

### Toolbars Still Missing
**Check console for errors** - The full stack trace will now appear

Common causes:
- Missing Python module (PyNite, PySide, etc.)
- FreeCAD version incompatibility
- Corrupted installation

### Want the Dialog Back
**Edit init_gui.py** and uncomment the dialog code (if desired)

Or just use: **StructureTools menu → Unit Settings** (Shift+U)

### Dialog Shows Twice (shouldn't happen now)
**Check console logs** - Should see:
```
unit_dialog: already shown, skipping duplicate
```

If this still happens, report with console output.

---

## Code Changes Summary

### [init_gui.py](init_gui.py)
- Added try/except to `Initialize()` with traceback
- Added try/except to `Activated()` with traceback
- Removed automatic dialog popup (QTimer call removed)
- Added unit info message to console
- Added "how to change units" message to console

### [unit_dialog.py](unit_dialog.py)
- Added global `_dialog_shown` flag (line 314)
- Added duplicate prevention logic (lines 327-330)
- Flag resets on error for retry (line 363)
- Kept deferred function for potential future use

---

## Recommended Workflow

### For First-Time Users
1. Activate workbench
2. Read console message showing current units
3. If units are correct → proceed
4. If units need changing → Press **Shift+U**
5. Select preferred unit system
6. Click OK (once!)

### For Regular Users
1. Activate workbench
2. Units auto-load from saved preference
3. Work normally
4. Change units anytime via **Shift+U** if needed

---

**Status**: All emergency fixes applied and tested
**Date**: 2025-12-26
**Priority**: HIGH - User-blocking issues resolved
