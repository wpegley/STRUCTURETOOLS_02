# Unit System Audit & Bulletproof Solution

## Current State Analysis

### What Works
- PyNite solver accepts ANY consistent unit system
- Geometry in mm (FreeCAD standard)

### Critical Bugs Found

#### Bug 1: Density Conversion (Line 848-849 calc.py)
```python
density = float(App.Units.Quantity(material.Density).getValueAs('t/m^3')) * 10
density = float(App.Units.Quantity(density, 'kN/m^3').getValueAs(f"{unitForce}/{unitLength}^3"))
```

**Problem**:
- Steel density = 7850 kg/m³ = 7.85 t/m³
- Multiply by 10 → 78.5 kN/m³ (WRONG! Should be 77.0 kN/m³)
- kg/m³ × 9.81/1000 = kN/m³, NOT ×10

**Correct**:
```python
# kg/m³ → kN/m³: multiply by g/1000
density_kg_m3 = float(App.Units.Quantity(material.Density).getValueAs('kg/m^3'))
density_kN_m3 = density_kg_m3 * 9.81 / 1000
```

#### Bug 2: Load Property Type (load_distributed.py:17)
```python
obj.addProperty("App::PropertyForce", "InitialLoading", ...)
```

**Problem**: PropertyForce stores Force (N), but distributed load is Force/Length (N/m)

**Impact**: All unit correction attempts fail because property type is fundamentally wrong

#### Bug 3: Unit Review Dialog Complexity
- Trying to fix Bug 2 at runtime instead of fixing the property definition
- Converting at wrong stage (after storage vs during input)
- Multiple conversion paths create confusion

## Bulletproof Solution

### Strategy: Consistent Internal Units

**Choose ONE internal unit system for PyNite:**
- Length: **m** (meters)
- Force: **kN** (kilonewtons)
- Distributed load: **kN/m**
- Moment: **kN·m**
- Stress: **kN/m²** (kPa)
- Density: **kN/m³**

**Why meters not mm?**
- Typical beam lengths 1-10m → nice numbers
- Typical loads 1-100 kN/m → nice numbers
- Deflections in mm just need ×1000 for display

### Conversion Points (ONLY 2 places)

#### 1. INPUT: FreeCAD Properties → PyNite
```
User enters in FreeCAD properties (any units with FreeCAD's unit system)
    ↓
Convert to internal units (m, kN, kN/m)
    ↓
Pass to PyNite
```

#### 2. OUTPUT: PyNite Results → Display
```
PyNite returns results (m, kN, kN·m)
    ↓
Convert for display:
  - Deflection: m → mm (×1000)
  - Forces: kN (unchanged)
  - Moments: kN·m (unchanged)
    ↓
Show to user
```

### Implementation Plan

#### Step 1: Fix Density Conversion
**File**: calc.py line 848-849

**FROM**:
```python
density = float(App.Units.Quantity(material.Density).getValueAs('t/m^3')) * 10
```

**TO**:
```python
# Get density in kg/m³ (FreeCAD standard)
density_kg_m3 = float(App.Units.Quantity(material.Density).getValueAs('kg/m^3'))
# Convert to kN/m³ for consistent force-based unit system
# kg/m³ × (9.81 m/s² / 1000 kg/kN) = kN/m³
density_kN_m3 = density_kg_m3 * 9.81 / 1000
```

**Test case**:
- Steel: 7850 kg/m³ × 0.00981 = 77.0 kN/m³ ✓
- Concrete: 2400 kg/m³ × 0.00981 = 23.5 kN/m³ ✓

#### Step 2: Set Internal Unit System to m/kN
**File**: calc.py (initialization)

Change from mm/N to m/kN:
```python
# OLD
obj.ForceUnit = 'N'
obj.LengthUnit = 'mm'

# NEW
obj.ForceUnit = 'kN'
obj.LengthUnit = 'm'
```

**Ripple effects**:
- All `getValueAs(unitLength)` will now return meters
- All `getValueAs(unitForce)` will now return kilonewtons
- Results come back in kN, kN·m, m (deflection)

#### Step 3: Fix Distributed Load Property
**File**: load_distributed.py line 17-18

**FROM**:
```python
obj.addProperty("App::PropertyForce", "InitialLoading", ...)
```

**TO**:
```python
# Use PropertyFloat with user-specified units
obj.addProperty("App::PropertyFloat", "InitialLoading", "Distributed",
                "Initial loading in kN/m").InitialLoading = 10.0
obj.addProperty("App::PropertyString", "LoadingUnit", "Distributed",
                "Unit for loading values").LoadingUnit = "kN/m"
```

**OR** (cleaner):
```python
# Let user enter with FreeCAD expression syntax
obj.addProperty("App::PropertyString", "InitialLoadingExpr", "Distributed",
                "Initial loading (e.g., '10 kN/m')").InitialLoadingExpr = "10 kN/m"
```

#### Step 4: Remove Unit Review Dialog
**Rationale**: If properties are correct and conversions happen at right places, no runtime correction needed

**Replace with**: Simple validation dialog showing final values before solve:
- Loads: X kN/m
- Self-weight: Included/Not included
- Materials: OK
- Supports: OK

#### Step 5: Display Conversion
**File**: calc.py (result extraction)

```python
# PyNite returns deflection in meters
deflection_m = member_results['deflection']
# Convert to mm for display
deflection_mm = deflection_m * 1000

# Forces already in kN, moments in kN·m - no conversion needed
```

## Self-Weight Calculation (Correct)

Given:
- Section area: A mm²
- Member length: L mm
- Material density: ρ kg/m³

**Step-by-step**:
```
1. Convert area to m²:     A_m² = A_mm² / 10^6
2. Member length to m:     L_m = L_mm / 1000
3. Volume:                 V = A_m² × L_m  (m³)
4. Mass:                   M = ρ × V  (kg)
5. Weight force:           W = M × 9.81  (N)
6. Convert to kN:          W_kN = W / 1000
7. Distributed load:       w = W_kN / L_m  (kN/m)
```

**Simplified**:
```python
# All in one formula
w_kN_per_m = (A_mm2 / 10^6) × (density_kg_m3) × 9.81 / 1000
           = A_mm2 × density_kg_m3 × 9.81 × 10^-9
```

**OR use PyNite's built-in**:
```python
# PyNite handles this if:
# - Material density is in kN/m³
# - Section area is in m²
# - It computes: w = density × area
model.add_member_self_weight(direction='FY', factor=-1)
```

**Current bug**: Density calculation wrong (using ×10 instead of ×9.81/1000)

## Testing Checklist

After fixes:

### Test 1: Material Density
- [ ] Steel (7850 kg/m³) → 77.0 kN/m³ in solver
- [ ] Concrete (2400 kg/m³) → 23.5 kN/m³ in solver

### Test 2: Distributed Load
- [ ] Enter "10 kN/m" → stored as 10.0, sent to solver as 10.0 kN/m
- [ ] No unit correction dialog needed

### Test 3: Self-Weight
- [ ] Steel beam 100×100mm, 5m long
- [ ] Area = 10000 mm² = 0.01 m²
- [ ] Self-weight = 77.0 × 0.01 = 0.77 kN/m ✓

### Test 4: Deflection Display
- [ ] Solver returns 0.005 m
- [ ] Display shows 5.0 mm ✓

### Test 5: Moment Display
- [ ] Solver returns 50.0 kN·m
- [ ] Display shows 50.0 kN·m ✓

## Summary

**Root cause**: Mixed unit systems and conversions at wrong stages

**Solution**:
1. ONE internal unit system (m, kN)
2. Convert ONLY at boundaries (input properties → solver, solver → display)
3. Fix density formula (×9.81/1000 not ×10)
4. Fix property types (Float+unit string for distributed loads, not Force)
5. Remove complex runtime unit correction

**Benefits**:
- Simple, predictable
- Easy to debug
- Matches engineering conventions (kN, m)
- No confusing unit dialogs
