# Unit Dialog Troubleshooting

## Issue: Dialog not showing or checkbox not working

### Quick Fixes

#### 1. Reset the "Don't Show Again" preference

If you checked the "remember" checkbox and want to see the dialog again:

```python
# In FreeCAD Python console:
from freecad.StructureTools.unit_dialog import reset_unit_dialog_preference
reset_unit_dialog_preference()
```

Then restart the workbench or restart FreeCAD.

#### 2. Check current unit settings

```python
# In FreeCAD Python console:
from freecad.StructureTools.unit_manager import get_current_units
units = get_current_units()
print(f"Current units: {units.name}")
print(f"Length: {units.length}, Force: {units.force}, Mass: {units.mass}")
```

#### 3. Manually change units

```python
# In FreeCAD Python console:
from freecad.StructureTools.unit_manager import get_unit_manager, UNIT_US_FT_KIP, UNIT_SI_M_KN

# Change to US units
manager = get_unit_manager()
manager.set_unit_system(UNIT_US_FT_KIP)

# Or change to SI units
manager.set_unit_system(UNIT_SI_M_KN)
```

#### 4. Open Unit Settings Dialog manually

Go to: **StructureTools menu → Unit Settings...**

Or use keyboard shortcut: **Shift+U**

---

## Changes Made (2025-12-26)

### Fixed: Blocking Workbench Activation

**Problem**: Dialog was modal and blocked workbench from loading

**Solution**:
- Dialog now shows 100ms after workbench activation using `QTimer.singleShot()`
- Workbench loads immediately, dialog appears shortly after
- Non-blocking approach allows FreeCAD to complete initialization

### Improved: Checkbox Visibility

**Problem**: Checkbox was hard to see and unclear

**Solution**:
- Checkbox now in a dedicated group box
- Bold font for better visibility
- Added hint text: "You can change units later via: StructureTools menu → Unit Settings"
- Better styling with padding

### Added: Debug Logging

The dialog now logs:
- Checkbox state when clicked
- Whether preference is being saved
- Confirmation message in console when saved

---

## Technical Details

### Dialog Flow

1. **Workbench activates** → Prints "Workbench StructureTools activated"
2. **100ms delay** → Allows GUI to complete setup
3. **Check preference** → Reads `DontShowUnitDialog` from FreeCAD parameters
4. **If first time** → Shows dialog
5. **User selects units** → Unit manager updates
6. **If checkbox checked** → Saves `DontShowUnitDialog = True`
7. **Next activation** → Dialog skipped, previous units loaded

### FreeCAD Parameter Location

```
User parameter:BaseApp/Preferences/Mod/StructureTools
  - UnitSystemName: "SI (m, kN, t)"
  - LengthUnit: "m"
  - ForceUnit: "kN"
  - MassUnit: "t"
  - DontShowUnitDialog: true/false
```

### Code Changes

**[init_gui.py:63-82](init_gui.py#L63-L82)**: Non-blocking activation
```python
def Activated(self):
    App.Console.PrintMessage("Workbench StructureTools activated.\n")

    # Deferred dialog (non-blocking)
    from PySide import QtCore
    from .unit_dialog import show_unit_dialog_deferred
    QtCore.QTimer.singleShot(100, show_unit_dialog_deferred)
```

**[unit_dialog.py:292-324](unit_dialog.py#L292-L324)**: Deferred show function
```python
def show_unit_dialog_deferred():
    """Non-blocking dialog show with preference checking."""
    param = App.ParamGet("User parameter:BaseApp/Preferences/Mod/StructureTools")
    dont_show = param.GetBool("DontShowUnitDialog", False)

    if dont_show:
        # Load saved units silently
        units = get_current_units()
        App.Console.PrintMessage(f"Using unit system: {units.name}\n")
    else:
        # Show dialog
        dialog = UnitSelectionDialog()
        dialog.exec_()
```

**[unit_dialog.py:173-193](unit_dialog.py#L173-L193)**: Improved checkbox UI
```python
remember_group = QtWidgets.QGroupBox()
self.remember_checkbox = QtWidgets.QCheckBox(
    "Remember this choice and don't show this dialog again"
)
self.remember_checkbox.setStyleSheet("QCheckBox { font-weight: bold; padding: 5px; }")
remember_hint = QtWidgets.QLabel(
    "<i>You can change units later via: StructureTools menu → Unit Settings</i>"
)
```

---

## Verification

After the fix, you should see:

1. **Workbench activates immediately** - no blocking
2. **Dialog appears 100ms later** - if not hidden
3. **Checkbox is bold and clear** - easy to see
4. **Hint text below checkbox** - explains how to change later
5. **Console messages** - show what's happening
6. **Preference saved** - dialog won't show next time if checked

---

## Still Having Issues?

If the checkbox still doesn't work:

1. Check the FreeCAD console for error messages
2. Try resetting the preference (see above)
3. Try manually setting units via Python console
4. Check FreeCAD version compatibility (requires PySide)
5. Report issue with console output

---

**Date**: 2025-12-26
**Fixed**: Blocking dialog, checkbox visibility, debug logging
**Tested**: Ready for user testing
