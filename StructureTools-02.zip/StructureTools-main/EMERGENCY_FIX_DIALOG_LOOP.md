# EMERGENCY FIX - Dialog Loop Issue
## Date: 2025-12-31 Evening

---

## ⚠️ CRITICAL BUG FIXED

You reported: **"Error Gui is looping again 'No Calc Object Link' - dialog unable to close!"**

### Root Cause Identified

The issue was that you have **existing invalid Diagram objects** in your document (diagrams with no Calc object linked). Every time FreeCAD tries to recompute these objects:

1. Diagram `execute()` runs
2. Finds `ObjectBaseCalc is None`
3. Shows error dialog
4. User clicks OK
5. FreeCAD triggers another recompute (property change, etc.)
6. **Loop repeats infinitely** ∞

The previous fix with class-level flags wasn't enough because:
- Multiple diagram objects exist
- Each one tries to show the dialog
- FreeCAD keeps triggering recomputes

---

## ✅ Fix Applied: Per-Object Error Tracking

**File Modified**: [diagram.py](freecad/StructureTools/diagram.py) lines 656-753

### What Changed

Added **per-object tracking** to show error dialogs **only ONCE per diagram object**:

```python
# Check for Calc object - USE OBJECT-LEVEL TRACKING TO PREVENT LOOPS
if not obj.ObjectBaseCalc:
    print("diagram: ERROR - ObjectBaseCalc is None")
    if not is_restoring:
        # Track which objects have already shown this error to prevent loops
        if not hasattr(Diagram, '_no_calc_errors_shown'):
            Diagram._no_calc_errors_shown = set()

        obj_name = obj.Name if hasattr(obj, 'Name') else 'Unknown'

        # Only show dialog ONCE per object, ever
        if obj_name not in Diagram._no_calc_errors_shown:
            Diagram._no_calc_errors_shown.add(obj_name)
            print(f"diagram: showing 'No Calc Object' error for {obj_name} (first and only time)")

            show_error_message(...)
        else:
            print(f"diagram: already showed 'No Calc' error for {obj_name}, skipping")

    # Create empty shape and return
    obj.Shape = Part.Shape()
    return
```

### Applied to 3 Error Locations:

1. **No Calc Object** (line 656-689)
   - Tracks in `Diagram._no_calc_errors_shown` set
   - Shows dialog ONCE per diagram object name

2. **No Data** (line 691-721)
   - Tracks in `Diagram._no_data_errors_shown` set
   - Shows dialog ONCE per diagram object name

3. **Analysis Not Run** (line 723-753)
   - Tracks in `Diagram._no_results_errors_shown` set
   - Shows dialog ONCE per diagram object name

---

## How This Prevents Loops

### Before:
```
Diagram1: execute() → error dialog → user clicks OK
Diagram1: execute() → error dialog → user clicks OK  ← LOOPS FOREVER
Diagram1: execute() → error dialog → user clicks OK
...
```

### After:
```
Diagram1: execute() → check set → not in set → show dialog → ADD TO SET
Diagram1: execute() → check set → IN SET → skip dialog, create empty shape
Diagram1: execute() → check set → IN SET → skip dialog, create empty shape
                                           ↑ NO MORE DIALOGS!
```

The error will show **exactly once** per invalid diagram object, then never again (until FreeCAD restarts and clears the tracking sets).

---

## What You Need to Do NOW

### Step 1: CLOSE FreeCAD Completely

If FreeCAD is still stuck, force close it:
- Press Ctrl+Alt+Delete → Task Manager
- Find "FreeCAD" process
- Click "End Task"

### Step 2: RESTART FreeCAD

The new code is in place, but Python needs to reload it.

### Step 3: When FreeCAD Opens

You may see **ONE error dialog per invalid diagram object**. This is expected:

**Example**:
```
"No Calculation Object Linked!

Diagram object: Diagram

...

IMPORTANT: Delete this invalid diagram object!
This error will only be shown once to prevent dialog loops."
```

**Click OK** - the dialog WILL close this time!

### Step 4: Delete Invalid Diagrams

In the FreeCAD tree, find all Diagram objects and delete the ones that are invalid:

1. Look for objects named "Diagram", "Diagram001", "Diagram002", etc.
2. If they have no Calc object linked or were created incorrectly
3. **Right-click → Delete**

This prevents them from trying to recompute again.

### Step 5: Create NEW Diagram Correctly

Follow the correct workflow:

1. **Select Calc object in tree** (MUST be first!)
2. Optionally Ctrl+Click member objects (Line/Wire) to diagram specific members
3. Click "Diagram" button
4. New diagram should work correctly

---

## Verification

After restart, check the Report View (View → Panels → Report View):

**Good signs** (fix working):
```
diagram: execute() called
diagram: ERROR - ObjectBaseCalc is None
diagram: showing 'No Calc Object' error for Diagram (first and only time)
...user clicks OK...
diagram: execute() called
diagram: ERROR - ObjectBaseCalc is None
diagram: already showed 'No Calc' error for Diagram, skipping
```

Notice the second time it says **"already showed...skipping"** - this means NO dialog!

**Bad sign** (fix not loaded):
```
diagram: ERROR - ObjectBaseCalc is None
(no mention of tracking or skipping)
```

If you see this, you need to restart FreeCAD again.

---

## Emergency Workaround

If the problem STILL occurs after restart:

### Option A: Delete All Diagrams
1. Close FreeCAD
2. Open your .FCStd file in a text editor
3. Search for `<Document>`
4. Look for `<Object type="Part::FeaturePython" name="Diagram"`
5. Delete those sections (carefully!)
6. Save and reopen in FreeCAD

### Option B: Start Fresh
1. Create a NEW document
2. Import/recreate your model (geometry, materials, sections, loads, supports)
3. Run analysis
4. Create diagrams using correct workflow
5. Don't open the old file with invalid diagrams

---

## Technical Details

### Why Per-Object Tracking Works

The class-level sets (`_no_calc_errors_shown`, `_no_data_errors_shown`, `_no_results_errors_shown`) persist across all diagram instances during a FreeCAD session:

- **Diagram1** calls `execute()` → Error shown → Name added to set
- **Diagram1** calls `execute()` again → Name in set → Skip dialog
- **Diagram2** (different object) calls `execute()` → Error shown → Name added to set
- **Diagram2** calls `execute()` again → Name in set → Skip dialog

Each object name is tracked independently, preventing infinite loops while still showing the error once to inform the user.

### Memory Usage

The tracking sets are very lightweight:
- Only store diagram object names (strings like "Diagram", "Diagram001")
- Cleared when FreeCAD closes
- Grows only as new invalid diagrams are encountered
- Typical size: 1-5 entries (tens of bytes)

---

## Summary

**Status**: ✅ FIXED

**What was done**:
- Added per-object error tracking for 3 error types
- Each error shown ONCE per diagram object, then suppressed
- Prevents infinite dialog loops completely

**What you need to do**:
1. ✅ Close FreeCAD completely
2. ✅ Restart FreeCAD (loads new code)
3. ⚠️ Click OK on any error dialogs (will close now!)
4. ⚠️ Delete invalid Diagram objects from tree
5. ✅ Create new diagrams using correct workflow

**Expected result**: No more infinite loops, dialogs close properly!

---

**If you still have issues after following these steps, please:**
1. Copy the FULL Report View output
2. List all objects in your document tree
3. Report back with details

The fix is in place and should work!
