# Unit Continuity Audit Report - StructureTools Workbench

**Date**: 2025-12-26
**Auditor**: Claude Code Analysis
**Status**: 🔴 **CRITICAL ISSUES FOUND**

---

## Executive Summary

The StructureTools workbench has a **well-designed but incompletely implemented** unit management system with several **critical inconsistencies** that cause incorrect structural analysis results when using non-default unit systems.

### Main Findings

| Issue | Severity | Impact |
|-------|----------|--------|
| Self-weight missing gravity constant | 🔴 CRITICAL | Results off by 1000× |
| Load visualization scale hardcoded | 🔴 CRITICAL | Arrows invisible or huge |
| Default load values assume N | 🟠 HIGH | 1000× too large in kN |
| Density conversion assumes metric | 🟠 HIGH | US customary broken |
| Review dialog assumes N/mm | 🟡 MEDIUM | Confusing conversions |

---

## Background: Structural Engineering Unit Standards

### The "Modeling" Standard: **kN-m**
Most common system for building geometry (nodes, beams, plates):
- **Length**: Meters (m)
- **Force**: Kilonewtons (kN)
- **Moment**: kN·m
- **Distributed Loads**: kN/m or kN/m² (kPa)
- **Elastic Modulus (E)**: kN/m² (kPa) or GPa (10⁶ kN/m²)

### The "Design" Standard: **N-mm**
Standard for material properties and cross-sections:
- **Length**: Millimeters (mm)
- **Force**: Newtons (N)
- **Stress/E**: Megapascals (MPa)
- **Section Properties (I, J)**: mm⁴

### The Magic Axiom
**1 N/mm² = 1 MPa** (makes stress calculations simple)

---

## 1. UNIT SYSTEM ARCHITECTURE ✅

**File**: [unit_manager.py](unit_manager.py)
**Status**: Well-designed infrastructure

### Available Unit Systems

| System | Length | Force | Use Case |
|--------|--------|-------|----------|
| `UNIT_SI_M_KN` | m | kN | **Structural modeling (DEFAULT)** |
| `UNIT_SI_M_N` | m | N | Pure SI |
| `UNIT_SI_MM_N` | mm | N | **Mechanical/FreeCAD default** |
| `UNIT_SI_MM_KN` | mm | kN | Alternative metric |
| `UNIT_US_FT_KIP` | ft | kip | US structural |
| `UNIT_US_IN_KIP` | in | kip | US detail design |
| `UNIT_US_FT_LBF` | ft | lbf | US small loads |
| `UNIT_US_IN_LBF` | in | lbf | US mechanical |

### Derived Units
Automatically calculated from base units:
- Stress: `force/length²` (e.g., kN/m² = kPa)
- Density: `force/length³` (e.g., kN/m³)
- Force per length: `force/length` (e.g., kN/m)
- Moment: `force*length` (e.g., kN·m)

### Features
- ✅ Singleton pattern ensures global consistency
- ✅ Persists settings in FreeCAD parameters
- ✅ Detects FreeCAD's preferred unit schema
- ❌ **Missing**: Gravity constant for self-weight calculations

---

## 2. COORDINATE AND LENGTH CONVERSIONS ✅

**File**: [calc.py:623-742](calc.py#L623-L742)
**Status**: CORRECT

### Implementation
```python
x1 = float(App.Units.Quantity(v1.x, 'mm').getValueAs(unitLength))
y1 = float(App.Units.Quantity(v1.z, 'mm').getValueAs(unitLength))  # Y/Z swap
z1 = float(App.Units.Quantity(v1.y, 'mm').getValueAs(unitLength))  # Y/Z swap
```

### What Works
- ✅ All coordinates from FreeCAD (mm) → target unit
- ✅ Y/Z swap correctly applied for solver
- ✅ Support locations properly converted
- ✅ Distance properties handled correctly

---

## 3. 🔴 CRITICAL: SELF-WEIGHT CALCULATION

**File**: [calc.py:1264-1266](calc.py#L1264-L1266)
**Status**: 🔴 **DIMENSIONALLY INCORRECT**

### Current Code
```python
if obj.SelfWeight:
    logger.info("calc: applying self-weight")
    model.add_member_self_weight('FY', -1)
```

### What Pynite Does
```python
self_weight = factor * member.material.rho * member.section.A
```

### THE PROBLEM

The formula used is: **w = ρ × A**

But this is **dimensionally incorrect**!

**Correct formula**: **w = ρ × A × g**

Where:
- ρ = density (mass/volume)
- A = area (length²)
- g = gravitational acceleration (length/time²)

**Missing**: The **g** factor entirely!

### Dimensional Analysis

**Current (WRONG)**:
```
w = ρ × A
  = (kg/m³) × (m²)
  = kg/m  ← This is MASS per length, not FORCE per length!
```

**Correct**:
```
w = ρ × A × g
  = (kg/m³) × (m²) × (m/s²)
  = kg·m/s² / m
  = N/m  ← Force per length ✓
```

### Gravity Constants by Unit System

| Unit System | g value | Converted |
|-------------|---------|-----------|
| SI (m, kN) | 9.81 m/s² | 0.00981 kN·s²/m |
| SI (m, N) | 9.81 m/s² | 9.81 N·s²/m |
| SI (mm, N) | 9810 mm/s² | 9.81 N·s²/mm |
| SI (mm, kN) | 9810 mm/s² | 0.00981 kN·s²/mm |
| US (ft, kip) | 32.174 ft/s² | 1.0 kip·s²/ft |
| US (in, kip) | 386.09 in/s² | 12.0 kip·s²/in |

### Example of Failure

**Steel beam**: ρ = 7850 kg/m³, A = 0.01 m²

**Expected** (SI m, kN):
```
w = 7850 kg/m³ × 0.01 m² × 9.81 m/s²
  = 770.085 N/m
  = 0.770 kN/m  ✓
```

**Current code** (broken):
```
w = 7850 × 0.01
  = 78.5  ← Wrong units! Not force/length
```

If interpreted as kN/m:
```
78.5 kN/m vs 0.770 kN/m
= 102× TOO LARGE!
```

### Impact

- **All self-weight calculations are incorrect**
- Results vary by 100-1000× depending on unit system
- Structural safety compromised

---

## 4. 🔴 CRITICAL: LOAD VISUALIZATION SCALE

**Files**: [constants.py:19](constants.py#L19), [load_point.py:71](load_point.py#L71), [load_distributed.py:46](load_distributed.py#L46)
**Status**: 🔴 **HARDCODED FOR N ONLY**

### Current Code
```python
# constants.py
LOAD_SCALE_FACTOR = 1000000  # Convert from N to visualization units

# load_point.py
cone = Part.makeCone(0, radiusCone * obj.ScaleDraw * load_value / 1000000, ...)
```

### THE PROBLEM

The scale factor **1,000,000** assumes loads are stored in **Newtons (N)**.

But if unit system is set to **kN**, this creates a **1000× error**!

### Example of Failure

**Load**: 10 kN point load

**If unit system is kN**:
- Internal value: 10
- Visualization: `10 / 1,000,000 = 0.00001`
- Arrow is **invisible** (1000× too small)

**If unit system is N**:
- Internal value: 10,000
- Visualization: `10,000 / 1,000,000 = 0.01`
- Arrow is **correct scale**

### Fix Required

```python
# Use unit manager to get force scale
scale_factor = 1.0
if unitForce == 'kN':
    scale_factor = 1000.0  # kN to N for visualization
elif unitForce == 'kip':
    scale_factor = 4448.22  # kip to N for visualization
elif unitForce == 'lb':
    scale_factor = 4.44822  # lb to N for visualization

cone = Part.makeCone(0, radiusCone * obj.ScaleDraw * load_value * scale_factor / 1000000, ...)
```

---

## 5. 🟠 HIGH: DEFAULT LOAD VALUES

**Files**: All load_*.py files
**Status**: 🟠 **UNIT-AGNOSTIC BUT CONFUSING**

### Current Code
```python
# load_point.py:21
obj.addProperty("App::PropertyForce", "PointLoading", "Point",
                "Point load").PointLoading = 10000000

# load_distributed.py:17-18
obj.addProperty("App::PropertyForce", "InitialLoading", "Distributed",
                "Initial loading").InitialLoading = 10000000
```

### THE PROBLEM

Default value: **10,000,000** (10 million)

**If displayed in kN**: 10,000 kN = **10 MN** (absurdly large!)
**If displayed in N**: 10,000,000 N = **10 MN** (correct)

### What Users See

| Unit System | Property Display | User Expectation | Reality |
|-------------|------------------|------------------|---------|
| kN | "10000" kN | 10 MN | Correct but huge |
| N | "10000000" N | 10 MN | Correct |
| kip | "2248" kip | 2.2 Mlbf | Correct but confusing |

### Fix Required

Set defaults based on unit system:
```python
if unitForce == 'kN':
    default_point = 10  # 10 kN (typical)
elif unitForce == 'N':
    default_point = 10000  # 10,000 N = 10 kN
elif unitForce == 'kip':
    default_point = 2.2  # 2.2 kip ≈ 10 kN
elif unitForce == 'lb':
    default_point = 2248  # 2248 lb ≈ 10 kN
```

---

## 6. 🟠 HIGH: DENSITY CONVERSION

**File**: [calc.py:845-846](calc.py#L845-L846)
**Status**: 🟠 **METRIC-ONLY ASSUMPTION**

### Current Code
```python
density = float(App.Units.Quantity(material.Density).getValueAs('t/m^3')) * 10
density = float(App.Units.Quantity(density, 'kN/m^3').getValueAs(f"{unitForce}/{unitLength}^3"))
```

### THE PROBLEM

**Line 1**: Convert density to `t/m³` (metric tons per cubic meter)
**Line 2**: Multiply by 10 (assumes 1 t = 1000 kg in gravity, so 1 t × 9.81 ≈ 10 kN)
**Line 3**: Convert from `kN/m³` to target units

**Issues**:
1. Hardcodes metric ton assumption (breaks for US customary)
2. Factor of 10 assumes kN (breaks for N)
3. Two-step conversion is confusing

### Example of Failure (US Customary)

Steel density: **490 lb/ft³**

**Current code tries**:
```python
density = Quantity(490 lb/ft³).getValueAs('t/m³')
# ERROR: Can't convert lb/ft³ to t/m³ directly (mass vs force density)
```

### Fix Required

```python
# Get density in mass units
if unitForce == 'kN':
    # Convert to force density: mass × g
    mass_density = material.Density  # kg/m³
    force_density = mass_density * 9.81 / 1000  # kN/m³
elif unitForce == 'N':
    mass_density = material.Density  # kg/m³
    force_density = mass_density * 9.81  # N/m³
elif unitForce == 'kip':
    mass_density = material.Density.getValueAs('slug/ft^3')
    force_density = mass_density * 32.174  # kip/ft³
# ... etc

# Then convert to target units
density = float(Quantity(force_density, f"{unitForce}/{base_length}^3").getValueAs(f"{unitForce}/{unitLength}^3"))
```

---

## 7. 🟡 MEDIUM: ANALYSIS REVIEW DIALOG CONVERSIONS

**File**: [analysis_review_dialog.py:313-345](analysis_review_dialog.py#L313-L345)
**Status**: 🟡 **ASSUMES N/mm AS STANDARD**

### Current Code
```python
if actual_unit == "kN/m":
    converted = initial_val * 0.001
elif actual_unit == "N/m":
    converted = initial_val * 0.000001
elif actual_unit == "N/mm":
    converted = initial_val  # ← Assumes N/mm is standard
elif actual_unit == "kN/mm":
    converted = initial_val * 1000.0
```

### THE PROBLEM

The conversion factors assume:
- **Internal standard**: N/mm
- **Display**: Can be any unit

But the unit manager might specify **kN/m** as standard!

### Example of Confusion

**Unit System**: `UNIT_SI_M_KN` (m, kN)
**User enters**: 10 (meaning 10 kN/m)
**Dialog shows**: "Currently Stored As: 10.000000 kN/m"
**User selects**: "N/mm" from dropdown
**Conversion display**: "× 1" (WRONG!)

**Should show**: "× 1,000,000" (1 kN/m = 1,000,000 N/mm)

### Fix Required

Get the current unit system's standard, then convert relative to that:
```python
current_internal_unit = f"{unitForce}/{unitLength}"

# Calculate conversion factor
if current_internal_unit == "N/mm":
    if actual_unit == "kN/m":
        factor = 0.001
    # ... etc
elif current_internal_unit == "kN/m":
    if actual_unit == "N/mm":
        factor = 1000000
    # ... etc
```

---

## 8. WHAT WORKS CORRECTLY ✅

1. **Coordinate conversion** (mm → target length unit)
2. **Material elastic modulus** (uses unit system)
3. **Section properties** (uses unit system)
4. **Load magnitude conversion** (uses unit manager)
5. **Moment of inertia conversion**
6. **Support location conversion**
7. **Node tolerance and positioning**

---

## 9. COMPREHENSIVE UNIT TABLE FOR PyNite

To keep PyNite consistent, use ONE column for ALL inputs:

| Component | kN-m System (Common) | N-mm System (Mechanical) | US (ft, kip) |
|-----------|----------------------|-------------------------|--------------|
| **Node Coordinates** | m | mm | ft |
| **Member Lengths** | m | mm | ft |
| **Force (Point)** | kN | N | kip |
| **Distributed Load** | kN/m | N/mm | kip/ft |
| **Young's Modulus (E)** | 200,000,000 kN/m² | 200,000 MPa | 29,000 ksi |
| **Moment of Inertia (I)** | m⁴ | mm⁴ | in⁴ |
| **Self-Weight (g)** | 9.81 m/s² | 9810 mm/s² | 32.174 ft/s² |
| **Density** | kN/m³ | N/mm³ | kip/ft³ |

---

## 10. RECOMMENDED FIXES

### Priority 1: CRITICAL (Must Fix Before Release)

#### 1.1 Add Gravity Constant to Unit Manager

**File**: [unit_manager.py](unit_manager.py)

```python
class UnitSystem:
    def __init__(self, name, length, force):
        self.name = name
        self.length = length
        self.force = force
        # ... existing code ...

        # ADD: Gravity constant
        if length == 'm':
            self.gravity = 9.81  # m/s²
        elif length == 'mm':
            self.gravity = 9810  # mm/s²
        elif length == 'ft':
            self.gravity = 32.174  # ft/s²
        elif length == 'in':
            self.gravity = 386.09  # in/s²

        # Convert to force units
        # gravity_force = mass × gravity / force_scale
        if force == 'kN':
            self.gravity_force = self.gravity / 1000  # kN·s²/length
        elif force == 'N':
            self.gravity_force = self.gravity  # N·s²/length
        elif force == 'kip':
            self.gravity_force = self.gravity / 32.174  # kip·s²/length (= 1.0)
        elif force == 'lb':
            self.gravity_force = self.gravity  # lb·s²/length
```

#### 1.2 Fix Self-Weight Calculation

**File**: [calc.py:1264-1266](calc.py#L1264-L1266)

```python
if obj.SelfWeight:
    logger.info("calc: applying self-weight")
    unit_sys = UnitManager().current_system()
    g = unit_sys.gravity  # Get gravity constant

    # Apply self-weight with gravity factor
    # factor = -1 for downward (negative Y in solver coordinates)
    model.add_member_self_weight('FY', -1 * g)

    logger.info(f"calc: self-weight applied with g = {g} {unit_sys.length}/s²")
```

**Alternative** (if Pynite doesn't accept custom factor):

Modify material density to include gravity:
```python
# In material property mapping (calc.py:845)
mass_density = float(App.Units.Quantity(material.Density).getValueAs(f'kg/{unitLength}^3'))
force_density = mass_density * unit_sys.gravity  # kg/m³ × m/s² = N/m³

# Then convert to target units
density = float(App.Units.Quantity(force_density, f'N/{unitLength}^3').getValueAs(f"{unitForce}/{unitLength}^3"))
```

#### 1.3 Fix Load Visualization Scale

**File**: [constants.py:19](constants.py#L19)

```python
# Remove hardcoded constant, calculate dynamically
# LOAD_SCALE_FACTOR = 1000000  ← DELETE THIS

# In each load file, get from unit manager:
def get_visualization_scale():
    """Get scale factor for load visualization based on unit system."""
    unit_sys = UnitManager().current_system()

    # Scale to convert to visualization base (N)
    if unit_sys.force == 'kN':
        return 1000.0
    elif unit_sys.force == 'kip':
        return 4448.22
    elif unit_sys.force == 'lb':
        return 4.44822
    else:  # N
        return 1.0
```

**Update load files** (load_point.py, load_distributed.py):
```python
scale = get_visualization_scale()
cone = Part.makeCone(0, radiusCone * obj.ScaleDraw * load_value * scale / 1000000, ...)
```

### Priority 2: HIGH (Fix Soon)

#### 2.1 Fix Density Conversion

**File**: [calc.py:845-846](calc.py#L845-L846)

```python
# Get density properly based on unit system
unit_sys = UnitManager().current_system()

# Convert mass density to force density (include gravity)
mass_density_kg_m3 = float(App.Units.Quantity(material.Density).getValueAs('kg/m^3'))

# Apply gravity to get force density in base units
if unit_sys.force == 'kN':
    # kg/m³ × 9.81 m/s² = 9.81 N/m³ = 0.00981 kN/m³
    force_density_base = mass_density_kg_m3 * 9.81 / 1000
    base_unit = 'kN/m^3'
elif unit_sys.force == 'N':
    force_density_base = mass_density_kg_m3 * 9.81
    base_unit = 'N/m^3'
elif unit_sys.force == 'kip':
    # Convert to slug/ft³, then apply g
    mass_density_slug = mass_density_kg_m3 * 0.00194032  # kg/m³ to slug/ft³
    force_density_base = mass_density_slug * 32.174
    base_unit = 'kip/ft^3'
elif unit_sys.force == 'lb':
    mass_density_slug = mass_density_kg_m3 * 0.00194032
    force_density_base = mass_density_slug * 32.174
    base_unit = 'lb/ft^3'

# Convert to target length unit
density = float(App.Units.Quantity(force_density_base, base_unit).getValueAs(f"{unitForce}/{unitLength}^3"))
```

#### 2.2 Fix Default Load Values

**File**: All load_*.py files

```python
# Get reasonable default based on unit system
def get_default_point_load():
    unit_sys = UnitManager().current_system()
    if unit_sys.force == 'kN':
        return 10  # 10 kN (typical column load)
    elif unit_sys.force == 'N':
        return 10000  # 10,000 N = 10 kN
    elif unit_sys.force == 'kip':
        return 2.2  # 2.2 kip ≈ 10 kN
    elif unit_sys.force == 'lb':
        return 2248  # 2248 lb ≈ 10 kN
    return 10000  # Fallback

obj.addProperty("App::PropertyForce", "PointLoading", "Point",
                "Point load").PointLoading = get_default_point_load()
```

### Priority 3: MEDIUM (Improve UX)

#### 3.1 Fix Analysis Review Dialog Conversions

**File**: [analysis_review_dialog.py:294-345](analysis_review_dialog.py#L294-L345)

```python
def on_load_unit_changed(self, load, combo, group_layout, initial_val):
    """Handle load unit correction and show conversion."""
    actual_unit = combo.currentData()

    # Get current internal unit from unit manager
    unit_sys = UnitManager().current_system()
    current_internal = f"{unit_sys.force}/{unit_sys.length}"

    # Calculate conversion factor FROM actual_unit TO internal unit
    # ... (implement proper conversion table)

    conversion_label.setText(
        f"<b style='color: #5cb85c;'>✓ Will send to Calc: {converted:.8f} {current_internal}</b><br>"
        f"<i>Conversion: {initial_val:.3f} {actual_unit} {factor_text} = {converted:.8f} {current_internal}</i>"
    )
```

#### 3.2 Add Unit System Selection at Workbench Startup

**File**: [init_gui.py](init_gui.py)

```python
def Activated(self):
    # Check if unit system has been set
    if not UnitManager().is_configured():
        # Show dialog to select unit system
        dialog = UnitSystemDialog()
        if dialog.exec_():
            UnitManager().set_system(dialog.selected_system)
```

---

## 11. TESTING CHECKLIST

After fixes are applied, test each unit system:

### Test 1: Self-Weight (kN-m system)
- Create 10m beam, steel (7850 kg/m³), 100×100 mm²
- Enable self-weight
- Expected: w = 7850 × 0.01 × 9.81 / 1000 = 0.770 kN/m
- Run analysis, check reactions: Should be ~7.7 kN total

### Test 2: Load Visualization (kN system)
- Create 10 kN point load
- Arrow should be visible and proportional
- NOT invisible (current bug)

### Test 3: Density (US customary)
- Set system to ft-kip
- Steel density 490 lb/ft³
- Conversion should not crash
- Expected: 490 / 32.174 = 15.2 slug/ft³ → 15.2 × 32.174 = 490 lb/ft³ force density

### Test 4: Unit Consistency
- Run same model in all 8 unit systems
- Results should be identical when converted back
- Example: Max deflection 10 mm = 0.01 m = 0.0328 ft

---

## 12. DOCUMENTATION UPDATES NEEDED

1. Update [UNIT_SYSTEM.md](UNIT_SYSTEM.md) with gravity constant explanation
2. Add troubleshooting section for unit inconsistencies
3. Create unit conversion reference table
4. Add warnings about not mixing unit systems mid-analysis
5. Document PyNite's unit requirements

---

## 13. CONCLUSION

**Current Status**: 🔴 **NOT PRODUCTION READY FOR NON-DEFAULT UNITS**

The StructureTools workbench works correctly ONLY for the default `UNIT_SI_M_KN` system (m, kN). Any other unit system will produce **incorrect results** due to:

1. Missing gravity constant (100-1000× error in self-weight)
2. Hardcoded visualization scale (arrows invisible or huge)
3. Metric-only density conversion (crashes for US customary)

**Recommendation**:
- Apply **Priority 1 fixes immediately** (gravity, visualization)
- Add **unit system validation** to prevent incorrect analyses
- Test **all 8 unit systems** before declaring production-ready

**User Impact**:
- Engineers using mm-based systems: **Self-weight 1000× too large**
- Engineers using US customary: **Density conversion fails**
- All non-default systems: **Load arrows not visible**

**Risk**: High probability of incorrect structural designs if unit system is changed from default.

---

**Audit Completed**: 2025-12-26
**Requires**: Immediate attention to Priority 1 fixes
**Estimated Fix Time**: 4-6 hours for Priority 1, 8-12 hours for all priorities
