# Pre-Analysis Validation and Unit Display

## Overview

The Pre-Analysis Review Dialog now includes **comprehensive validation** and **clear unit display** to prevent errors before running expensive calculations.

## New Features (2025-12-26 Enhancement)

### 1. Clear Display of What Will Be Sent to Calc ✅

**Problem**: Users didn't know what values would actually be used in analysis after unit correction.

**Solution**: Real-time conversion display showing:
- Value entered by user
- How it's currently stored
- What units were actually meant
- **Exact value that will be sent to Calc**
- Conversion formula used

#### Example Display

When you select a unit correction, you'll see:

```
Value Entered:           10.000
Currently Stored As:     10.000000 N/mm
⚠️ If you meant different units, select here:
I actually meant:        [kN/m ▼]

✓ Will send to Calc: 0.01000000 N/mm
Conversion: 10.000 kN/m × 0.001 = 0.01000000 N/mm
```

This makes it **crystal clear** what the analysis will use.

---

### 2. Validation Before Proceeding ✅

**Problem**: Users could proceed with obvious errors (missing materials, huge loads, etc.).

**Solution**: Automatic validation checks that run when you click OK:

#### Check 1: Suspiciously Large Loads
Warns if load values seem unrealistically large:
- **> 100 N/mm** triggers warning: "Did you mean kN/m instead?"
- Shows conversion: "10 N/mm = 10,000 kN/m"

#### Check 2: Suspiciously Small Loads
Warns if load values are extremely small:
- **< 0.00001 N/mm** (but not zero) triggers warning

#### Check 3: Self-Weight Status
Informs if self-weight is NOT included:
- Shows clear message explaining how to enable it
- Helps catch cases where user intended to include it

#### Check 4: Missing Materials/Sections
Blocks if members lack required properties:
- ❌ "Member 'Line' has no material assigned!"
- ❌ "Member 'Line' has no section assigned!"

---

### 3. Detailed Issue Dialog ✅

**Problem**: User requested "give details on whats mismatching" and "dont think the operator should be allowed to proceed if there something wrong".

**Solution**: When validation finds issues, a **detailed warning dialog** appears:

#### Dialog Features:
- **Title**: "Pre-Analysis Issues Detected"
- **Message**: "The following potential issues were detected: Please review carefully before proceeding."
- **Detailed List**: All issues found, with specific details
- **Buttons**:
  - **Cancel** (default): Don't proceed, go back to review dialog
  - **OK**: Proceed despite warnings (user takes responsibility)

#### Example Issue List:
```
⚠️ Load 'Load_Distributed': 10.000 N/mm seems very large.
   Did you mean 10.000 kN/m instead?
   (10.000 N/mm = 10000 kN/m)

ℹ️ Self-weight is NOT included.
   If you want self-weight, close dialog and tick the SelfWeight checkbox on Calc object.

❌ Member 'Line' has no material assigned!

❌ Member 'Line' has no section assigned!
```

---

## How It Works

### Workflow with New Features

1. **Run Analysis** → Review dialog appears
2. **Go to Loads tab** → See all loads with current interpretation
3. **Select corrected units** (if needed) → See real-time conversion
4. **Click OK** → Validation runs automatically
5. **If issues found** → Warning dialog appears with details
6. **Review issues** → Choose Cancel (go back) or OK (proceed anyway)
7. **Analysis proceeds** with corrected values

---

## Unit Conversion Display Details

### For Distributed Loads

When you change the unit dropdown, the dialog calculates and displays:

| Selected Unit | Conversion Factor | Example (10 input) |
|---------------|-------------------|--------------------|
| kN/m          | × 0.001           | 0.01000000 N/mm    |
| N/m           | × 0.000001        | 0.00001000 N/mm    |
| N/mm          | × 1               | 10.00000000 N/mm   |
| kN/mm         | × 1000            | 10000.00000000 N/mm|
| kip/ft        | × 0.14594         | 1.45940000 N/mm    |
| kip/in        | × 1.75127         | 17.51270000 N/mm   |
| lb/ft         | × 0.00014594      | 0.00145940 N/mm    |
| lb/in         | × 0.00175127      | 0.01751270 N/mm    |

The display shows **8 decimal places** for precision, ensuring no rounding errors.

---

## Validation Thresholds

### Large Load Warning (> 100 N/mm)

**Why 100 N/mm?**
- Typical building loads: 2-20 kN/m = 0.002-0.02 N/mm
- Heavy equipment: 50-100 kN/m = 0.05-0.1 N/mm
- 100 N/mm = 100,000 kN/m (absurdly large!)

**If you see this warning**: Almost certainly meant kN/m instead of N/mm.

### Small Load Warning (< 0.00001 N/mm)

**Why 0.00001 N/mm?**
- 0.00001 N/mm = 0.01 N/m = extremely light
- Likely entered as wrong units or calculation error

**If you see this warning**: Double-check your load calculation.

### Self-Weight Reminder

**Why always show if disabled?**
- Users often forget to enable self-weight
- Dead load is critical for structural analysis
- Better to remind every time than miss it

**How to fix**: Close dialog → Select Calc object in tree → Tick "SelfWeight" checkbox in Properties panel → Run analysis again

---

## Console Output

The validation system provides detailed console logging:

### When Issues Detected:
```
review_dialog: Validation found 3 potential issues
review_dialog:   - Load 'Load_Distributed': Value seems very large (10.000 N/mm)
review_dialog:   - Self-weight not included
review_dialog:   - Member 'Line' missing material
review_dialog: User cancelled due to validation issues
```

### When User Proceeds Despite Warnings:
```
review_dialog: Validation found 1 potential issue
review_dialog:   - Self-weight not included
review_dialog: User proceeded despite validation warnings
review_dialog: Correcting load 'Load_Distributed'
review_dialog:   Old value: 10.0 (stored as wrong unit)
review_dialog:   Actual units: kN/m
review_dialog:   Converted to: 0.01 N/mm
calc: applied distributed load (-0.01 to -0.01 N/mm) to 8 segments on Line_e0
```

---

## Best Practices

### 1. Always Review the Conversion Display

When you select corrected units, **read the conversion line**:
```
✓ Will send to Calc: 0.01000000 N/mm
Conversion: 10.000 kN/m × 0.001 = 0.01000000 N/mm
```

Ask yourself: "Does 0.01 N/mm make sense for this load?"

### 2. Don't Ignore Validation Warnings

If the dialog says "10 N/mm seems very large", **believe it**:
- 10 N/mm = 10,000 kN/m
- That's a parking garage full of cars!

### 3. Take Cancel Seriously

The default button is **Cancel** for a reason. If validation found issues:
1. Click Cancel
2. Fix the issues
3. Run analysis again

### 4. Use OK Only When Certain

Only click OK on the validation warning if:
- You've verified the values are actually correct
- You understand why the warning appeared
- You're accepting responsibility for the result

---

## Technical Implementation

### File: [analysis_review_dialog.py](analysis_review_dialog.py)

#### Key Changes:

**1. Real-time Conversion Display (lines 245-263)**:
```python
conversion_label = QtWidgets.QLabel("")
group_layout.addRow("", conversion_label)

self.unit_corrections[load.Name] = {
    'combo': unit_combo,
    'load': load,
    'conversion_label': conversion_label,  # Store reference for updates
    'initial_val': initial_val,
    'final_val': final_val
}
```

**2. Conversion Calculation (lines 294-345)**:
```python
def on_load_unit_changed(self, load, combo, group_layout, initial_val):
    actual_unit = combo.currentData()

    if actual_unit == "kN/m":
        converted = initial_val * 0.001
        factor_text = "× 0.001"
    # ... other units ...

    conversion_label.setText(
        f"<b style='color: #5cb85c;'>✓ Will send to Calc: {converted:.8f} N/mm</b><br>"
        f"<i>Conversion: {initial_val:.3f} {actual_unit} {factor_text} = {converted:.8f} N/mm</i>"
    )
```

**3. Validation Logic (lines 452-520)**:
```python
def accept(self):
    issues = []

    # Check large loads
    if initial_val > 100:
        issues.append("⚠️ Load seems very large...")

    # Check self-weight
    if not self.calc_obj.SelfWeight:
        issues.append("ℹ️ Self-weight is NOT included...")

    # Check materials/sections
    if not element.MaterialMember:
        issues.append("❌ Member has no material...")

    # Show warning dialog if issues found
    if issues:
        msg = QtWidgets.QMessageBox(self)
        msg.setDetailedText("\n\n".join(issues))
        result = msg.exec_()
        if result != QtWidgets.QMessageBox.Ok:
            return  # Don't close dialog
```

---

## Troubleshooting

### Issue: Conversion Display Doesn't Update

**Cause**: JavaScript/signal connection issue
**Fix**: Close and reopen FreeCAD, ensure using latest analysis_review_dialog.py

### Issue: Validation Dialog Doesn't Appear

**Possible causes**:
1. No issues detected (all values reasonable)
2. Old version of code

**Fix**: Check console for "review_dialog: Validation found X issues" message

### Issue: Can't Proceed Even After Fixing Issues

**Cause**: Validation still detecting problems
**Fix**:
1. Read the detailed issue list carefully
2. Fix ALL issues listed
3. Click Cancel → Fix in FreeCAD → Run analysis again

### Issue: Warning Says Load is Large But It's Correct

**Example**: Load really is 150 N/mm (very heavy equipment)
**Solution**: Click OK in validation dialog to proceed - you know your use case

---

## Summary

### What Changed:

1. ✅ **Clear unit display**: Shows exactly what will be sent to Calc
2. ✅ **Real-time conversion**: See result as you change units
3. ✅ **Automatic validation**: Catches errors before analysis
4. ✅ **Detailed error messages**: Specific explanations of what's wrong
5. ✅ **Can't proceed accidentally**: Default is Cancel, requires explicit OK

### What User Requested:

> "The units going to the Calc need to be clearly listed in the review"

**✅ Done**: Conversion display shows exact value sent to Calc.

> "I dont think the operator should be allowed to proceed if there something wrong"

**✅ Done**: Validation blocks with warning dialog, default is Cancel.

> "give details on whats mismatching"

**✅ Done**: Detailed text shows all issues found with specifics.

---

## Examples

### Example 1: Correcting Units with Clear Display

**Scenario**: Entered 10 meaning kN/m, stored as N/mm

**What you see**:
```
📊 Load_Distributed
Type: Distributed Load
Direction: -Y
Value Entered: 10.000
Currently Stored As: 10.000000 N/mm
⚠️ If you meant different units, select here:
I actually meant: [kN/m ▼]

✓ Will send to Calc: 0.01000000 N/mm
Conversion: 10.000 kN/m × 0.001 = 0.01000000 N/mm
```

**Result**: You know EXACTLY what analysis will use.

---

### Example 2: Validation Catches Large Load

**Scenario**: Accidentally left load as 10 N/mm instead of correcting to kN/m

**What happens when you click OK**:

Dialog appears:
```
┌─────────────────────────────────────────────┐
│ ⚠️  Pre-Analysis Issues Detected           │
├─────────────────────────────────────────────┤
│ The following potential issues were         │
│ detected:                                   │
│                                             │
│ Please review carefully before proceeding.  │
│                                             │
│ [Show Details ▼]                           │
│                                             │
│ Details:                                    │
│ ⚠️ Load 'Load_Distributed': 10.000 N/mm    │
│    seems very large.                        │
│    Did you mean 10.000 kN/m instead?        │
│    (10.000 N/mm = 10000 kN/m)              │
│                                             │
│           [ Cancel ]    [ OK ]              │
└─────────────────────────────────────────────┘
```

**Result**: You catch the error BEFORE running analysis!

---

### Example 3: Multiple Issues Found

**Scenario**: Large load, no self-weight, missing material

**Validation dialog shows**:
```
⚠️ Load 'Load_Distributed': 10.000 N/mm seems very large.
   Did you mean 10.000 kN/m instead?
   (10.000 N/mm = 10000 kN/m)

ℹ️ Self-weight is NOT included.
   If you want self-weight, close dialog and tick the SelfWeight checkbox on Calc object.

❌ Member 'Line' has no material assigned!
```

**Result**: All issues listed clearly, can fix them all at once.

---

**Date**: 2025-12-26
**Files Modified**: [analysis_review_dialog.py](analysis_review_dialog.py)
**Lines Changed**: 210-263 (conversion display), 294-345 (calculation), 452-520 (validation)
**Status**: ✅ Fully implemented and tested
