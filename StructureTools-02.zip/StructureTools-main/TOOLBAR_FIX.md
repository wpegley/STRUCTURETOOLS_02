# Toolbar Fix - Command Registration Issue

## Problem Identified

From your console log:
```
Unknown command 'calc'
Unknown command 'calc'
```

This error appeared **twice** and caused all toolbars to fail initialization.

## Root Cause

**Command name mismatch**:
- **Registered as**: `"structuretools_calc"` in [calc.py:1178](calc.py#L1178)
- **Toolbar expected**: `"calc"` in [init_gui.py:61](init_gui.py#L61)

When FreeCAD tried to add the toolbar button for "calc", it couldn't find the command because it was registered under a different name.

## Fix Applied

Changed [calc.py:1178](calc.py#L1178):
```python
# BEFORE (incorrect):
Gui.addCommand("structuretools_calc", CommandCalc())

# AFTER (fixed):
Gui.addCommand("calc", CommandCalc())
```

Now matches the pattern used by all other commands:
- `"diagram"` → diagram.py
- `"member"` → member.py
- `"material"` → material.py
- `"calc"` → calc.py ✅

## Why Toolbars Vanished

When `appendToolbar()` encounters an unknown command:
1. FreeCAD logs: `Unknown command 'calc'`
2. Toolbar creation **fails**
3. Exception occurs in `Initialize()`
4. **All subsequent toolbars are not created**
5. Result: No toolbars visible

Our new exception handling in `Initialize()` prevented a complete crash, but the toolbars still failed to appear because the exception happened during toolbar creation.

## Test Now

1. **Close FreeCAD completely**
2. **Delete any cached .pyc files** (optional but recommended):
   ```bash
   # In the StructureTools directory:
   del /S /Q __pycache__
   del /S /Q *.pyc
   ```
3. **Restart FreeCAD**
4. **Activate StructureTools workbench**

## Expected Console Output

**Before Fix** (error):
```
StructureTools workbench initialized successfully
Unknown command 'calc'  ← ERROR
Unknown command 'calc'  ← ERROR AGAIN
Workbench StructureTools activated...
```

**After Fix** (success):
```
StructureTools workbench initialized successfully
Workbench StructureTools activated. Using units: SI (mm, N, kg)
To change units: StructureTools menu → Unit Settings (Shift+U)
```

**No "Unknown command" errors!**

## What Should Work Now

### Toolbars Visible:
- ✅ **StructureLoad**: load_distributed, load_nodal, load_point
- ✅ **StructureTools**: member, suport, support_edge, section, material
- ✅ **StructureResults**: **calc**, diagram ← Fixed!
- ✅ **DraftDraw**: Sketch, Line, Wire, Arc, etc.
- ✅ **DraftEdit**: Move, Rotate, Clone, etc.
- ✅ **DraftSnap**: All snap tools
- ✅ **DraftTools**: Select Plane, Set Style

### Menu Working:
- ✅ **StructureTools menu** with all commands including "Run Analysis"

### Commands Accessible:
- ✅ Click "Run Analysis" button (calc command)
- ✅ Press **Shift+C** (calc keyboard shortcut)
- ✅ Menu: StructureTools → Run Analysis

## Additional Notes

### Why It Appeared Twice
The error appeared twice because:
1. First call: Creating the **toolbar** with calc button
2. Second call: Creating the **menu** with calc menu item

Both failed because the command wasn't registered.

### Console Logs Explained

From your log:
```
15:33:25  StructureTools workbench initialized successfully
15:33:25  Unknown command 'calc'  ← Toolbar creation
15:33:25  Unknown command 'calc'  ← Menu creation
15:33:25  UnitManager: detected FreeCAD schema 0 -> SI (mm, N, kg)
15:33:25  UnitManager: initialized with SI (mm, N, kg)
15:33:25  Workbench StructureTools activated. Using units: SI (mm, N, kg)
15:33:25  To change units: StructureTools menu → Unit Settings (Shift+U)
```

Everything else worked - only the calc command failed.

### Detected Units

Your FreeCAD is using:
- **Schema 0**: Standard (mm, kg, s)
- **Auto-selected**: SI (mm, N, kg)

To change to structural engineering units:
- Press **Shift+U**
- Select **SI (m, kN, t)** (recommended for structural)

## Verification Commands

After restart, test in Python console:

```python
# Verify command exists
import FreeCADGui as Gui
print("calc" in Gui.listCommands())  # Should print: True

# Verify all StructureTools commands
st_commands = [c for c in Gui.listCommands() if 'calc' in c or 'diagram' in c or 'member' in c]
print(st_commands)
```

Should see: `['calc', 'diagram', 'member', ...]`

---

**Status**: Command registration fixed
**File changed**: [calc.py:1178](calc.py#L1178)
**Expected result**: All toolbars visible, no "Unknown command" errors
**Test**: Restart FreeCAD now
