import os
import FreeCADGui as Gui
import FreeCAD as App


translate = App.Qt.translate
QT_TRANSLATE_NOOP = App.Qt.QT_TRANSLATE_NOOP

ICONPATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))
TRANSLATIONSPATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources", "translations"))

# Add translations path
Gui.addLanguagePath(TRANSLATIONSPATH)
Gui.updateLocale()



from .Pynite_main.FEModel3D import FEModel3D


class StructureTools(Gui.Workbench):
	"""
	class which gets initiated at startup of the gui
	"""
	MenuText = translate("Workbench", "StructureTools")
	ToolTip = translate("Workbench", "a simple StructureTools")
	Icon = os.path.join(ICONPATH, "icone.svg")
	toolbox = []

	def GetClassName(self):
		return "Gui::PythonWorkbench"

	def Initialize(self):
		"""
		This function is called at the first activation of the workbench.
		here is the place to import all the commands
		"""
		try:
			from freecad.StructureTools import load_distributed
			from freecad.StructureTools import load_nodal
			from freecad.StructureTools import load_point
			from freecad.StructureTools import suport
			from freecad.StructureTools import support_edge
			from freecad.StructureTools import section
			from freecad.StructureTools import material
			from freecad.StructureTools import member
			from freecad.StructureTools import calc
			from freecad.StructureTools import diagram
			from freecad.StructureTools import unit_settings_command

			import DraftTools, SketcherGui

			# NOTE: Context for this commands must be "Workbench"
			self.appendToolbar('DraftDraw', ["Sketcher_NewSketch","Draft_Line", "Draft_Wire", "Draft_ArcTools", "Draft_BSpline", "Draft_Dimension"])
			self.appendToolbar('DraftEdit', ["Draft_Move", "Draft_Rotate", "Draft_Clone", "Draft_Offset", "Draft_Trimex", "Draft_Join", "Draft_Split","Draft_Stretch","Draft_Draft2Sketch"])
			self.appendToolbar('DraftSnap', ["Draft_Snap_Lock", "Draft_Snap_Endpoint", "Draft_Snap_Midpoint", "Draft_Snap_Center", "Draft_Snap_Angle", "Draft_Snap_Intersection", "Draft_Snap_Perpendicular", "Draft_Snap_Extension", "Draft_Snap_Parallel", "Draft_Snap_Special", "Draft_Snap_Near", "Draft_Snap_Ortho", "Draft_Snap_Grid", "Draft_Snap_WorkingPlane", "Draft_Snap_Dimensions", "Draft_ToggleGrid"])
			self.appendToolbar('DraftTools', ["Draft_SelectPlane", "Draft_SetStyle"])

			self.appendToolbar('StructureLoad', ["load_distributed","load_nodal","load_point"])
			self.appendToolbar('StructureTools', ["member", "suport", "support_edge", "section", "material"])
			self.appendToolbar('StructureResults', ["calc","diagram"])
			self.appendMenu('StructureTools',["load_distributed", "load_nodal","load_point","member" ,"suport", "support_edge", "section", "material", "calc", "diagram", "unit_settings"])

			App.Console.PrintMessage("StructureTools workbench initialized successfully\n")

		except Exception as exc:
			App.Console.PrintError(f"Error initializing StructureTools workbench: {exc}\n")
			import traceback
			App.Console.PrintError(traceback.format_exc())

	def Activated(self):
		'''
		Code which should be computed when a user switches to this workbench.
		'''
		try:
			from .unit_manager import get_current_units

			# Load unit system (silently, no dialog)
			units = get_current_units()

			App.Console.PrintMessage(translate(
				"Log",
				f"Workbench StructureTools activated. Using units: {units.name}\n"
			))
			App.Console.PrintMessage(translate(
				"Log",
				"To change units: StructureTools menu → Unit Settings (Shift+U)\n"
			))

		except Exception as exc:
			App.Console.PrintError(f"Error in workbench activation: {exc}\n")
			import traceback
			App.Console.PrintError(traceback.format_exc())

	def Deactivated(self):
		'''
		code which should be computed when this workbench is deactivated
		'''
		App.Console.PrintMessage(translate(
			"Log",
			"Workbench StructureTools de-activated.") + "\n")


Gui.addWorkbench(StructureTools())


