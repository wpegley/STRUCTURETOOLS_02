import FreeCAD, App, FreeCADGui, Part, os
from PySide import QtWidgets, QtCore

ICONPATH = os.path.join(os.path.dirname(__file__), "resources")
LOAD_POINT_COLOR = (0.00, 0.80, 0.00)


def show_error_message(msg):
    msg_box = QtWidgets.QMessageBox()
    msg_box.setIcon(QtWidgets.QMessageBox.Critical)
    msg_box.setWindowTitle("Error")
    msg_box.setText(msg)
    msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
    msg_box.exec_()


class LoadPoint:
    def __init__(self, obj, selection):
        obj.Proxy = self
        obj.addProperty("App::PropertyLinkSubList", "ObjectBase", "Base", "Object base")
        obj.addProperty("App::PropertyForce", "PointLoading", "Point", "Point load").PointLoading = 10000000
        obj.addProperty("App::PropertyLength", "Distance", "Point", "Distance from start").Distance = 0
        obj.addProperty("App::PropertyFloat", "ScaleDraw", "Load", "Scale from drawing").ScaleDraw = 1

        obj.addProperty("App::PropertyEnumeration", "GlobalDirection", "Load", "Global direction load")
        obj.GlobalDirection = ['+X', '-X', '+Y', '-Y', '+Z', '-Z']
        obj.GlobalDirection = '-Z'

        obj.ObjectBase = [(selection[0], (selection[1],))]

        try:
            subelement = self.getSubelement(obj, selection[1])
            if hasattr(subelement, "Length"):
                obj.Distance = subelement.Length / 2
        except Exception:
            pass

    def getSubelement(self, obj, nameSubElement):
        if not hasattr(obj, "ObjectBase") or not obj.ObjectBase or not obj.ObjectBase[0]:
            return None
        base_obj = obj.ObjectBase[0][0]
        shape = getattr(base_obj, "Shape", None)
        if not shape:
            return None

        if "Edge" in nameSubElement:
            try:
                index = int(nameSubElement.split("Edge")[1]) - 1
            except Exception:
                return None
            if index < 0 or index >= len(shape.Edges):
                return None
            return shape.Edges[index]

        try:
            index = int(nameSubElement.split("Vertex")[1]) - 1
        except Exception:
            return None
        if index < 0 or index >= len(shape.Vertexes):
            return None
        return shape.Vertexes[index]

    def makeArrow(self, obj, load):
        radiusCone = 5
        heightCone = 20
        heightCylinder = 30
        radiusCylinder = 2

        load_value = max(abs(float(load)), 1e-6)

        cone = Part.makeCone(0, radiusCone * obj.ScaleDraw * load_value / 1000000, heightCone * obj.ScaleDraw * load_value / 1000000)
        cylinder = Part.makeCylinder(radiusCylinder * obj.ScaleDraw * load_value / 1000000, heightCylinder * obj.ScaleDraw * load_value / 1000000)
        cylinder.translate(FreeCAD.Vector(0, 0, heightCone * obj.ScaleDraw * load_value / 1000000))
        return Part.makeCompound([cone, cylinder])

    def getPointOnEdge(self, edge, distance_mm):
        start = edge.Vertexes[0].Point
        end = edge.Vertexes[1].Point
        direction = end.sub(start)
        length = direction.Length
        if length <= 1e-6:
            return start
        distance_mm = max(0.0, min(distance_mm, length))
        direction = direction.multiply(distance_mm / length)
        return start.add(direction)

    def execute(self, obj):
        shape = Part.Shape()
        if not obj.ObjectBase:
            obj.Shape = shape
            return

        subname = obj.ObjectBase[0][1][0]
        subelement = self.getSubelement(obj, subname)
        if not subelement:
            obj.Shape = shape
            return

        # Determine point location based on selection type
        point = None
        if 'Vertex' in subname:
            # Direct vertex selection - use vertex point directly
            point = subelement.Point
        elif 'Edge' in subname:
            # Edge selection - calculate point along edge using Distance
            distance_mm = float(obj.Distance.getValueAs("mm"))
            point = self.getPointOnEdge(subelement, distance_mm)

        if point is not None:
            shape = self.makeArrow(obj, obj.PointLoading)

            match obj.GlobalDirection:
                case '+X':
                    shape.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), -90)
                case '-X':
                    shape.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), 90)
                case '+Y':
                    shape.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), 90)
                case '-Y':
                    shape.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), -90)
                case '+Z':
                    shape.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), 180)
                case '-Z':
                    shape.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), 0)

            shape.translate(point)
            obj.ViewObject.ShapeAppearance = (
                FreeCAD.Material(
                    DiffuseColor=LOAD_POINT_COLOR,
                    AmbientColor=(0.33, 0.33, 0.33),
                    SpecularColor=(0.53, 0.53, 0.53),
                    EmissiveColor=(0.00, 0.00, 0.00),
                    Shininess=(0.90),
                    Transparency=(0.00),
                )
            )
            obj.Label = 'point load'

        if not shape.isNull():
            obj.Placement = shape.Placement
        obj.Shape = shape
        if hasattr(obj, 'ViewObject') and obj.ViewObject and obj.ViewObject.DisplayMode:
            if 'Shaded' in obj.ViewObject.DisplayMode:
                obj.ViewObject.DisplayMode = 'Shaded'

    def onChanged(self, obj, Parameter):
        if Parameter in ('PointLoading', 'Distance', 'ScaleDraw', 'GlobalDirection', 'ObjectBase'):
            self.execute(obj)


class PointLoadTaskPanel:
    def __init__(self, obj):
        self.obj = obj
        self.form = QtWidgets.QWidget()
        self.form.setWindowTitle("Point Load")

        layout = QtWidgets.QVBoxLayout(self.form)
        layout.setContentsMargins(8, 8, 8, 8)

        self.force_spin = QtWidgets.QDoubleSpinBox()
        self.force_spin.setRange(-1e12, 1e12)
        self.force_spin.setDecimals(6)
        self.force_spin.setSingleStep(1000)
        self.force_spin.setValue(float(obj.PointLoading.getValueAs("N")))
        layout.addWidget(QtWidgets.QLabel("Force (N)"))
        layout.addWidget(self.force_spin)

        self.distance_spin = QtWidgets.QDoubleSpinBox()
        self.distance_spin.setRange(0.0, 1e9)
        self.distance_spin.setDecimals(6)
        self.distance_spin.setSingleStep(10)
        self.distance_spin.setValue(float(obj.Distance.getValueAs("mm")))
        layout.addWidget(QtWidgets.QLabel("Distance from start (mm)"))
        layout.addWidget(self.distance_spin)

        self.scale_spin = QtWidgets.QDoubleSpinBox()
        self.scale_spin.setRange(1e-6, 1e6)
        self.scale_spin.setDecimals(6)
        self.scale_spin.setSingleStep(0.1)
        self.scale_spin.setValue(float(obj.ScaleDraw))
        layout.addWidget(QtWidgets.QLabel("Draw scale"))
        layout.addWidget(self.scale_spin)

        self.dir_combo = QtWidgets.QComboBox()
        self.dir_combo.addItems(['+X', '-X', '+Y', '-Y', '+Z', '-Z'])
        try:
            current_index = self.dir_combo.findText(obj.GlobalDirection)
            if current_index >= 0:
                self.dir_combo.setCurrentIndex(current_index)
        except Exception:
            pass
        layout.addWidget(QtWidgets.QLabel("Global direction"))
        layout.addWidget(self.dir_combo)

        btn_row = QtWidgets.QHBoxLayout()
        self.mid_btn = QtWidgets.QPushButton("Midspan")
        btn_row.addWidget(self.mid_btn)
        btn_row.addStretch(1)
        layout.addLayout(btn_row)

        self._connecting = False
        self.force_spin.valueChanged.connect(self._on_force_changed)
        self.distance_spin.valueChanged.connect(self._on_distance_changed)
        self.scale_spin.valueChanged.connect(self._on_scale_changed)
        self.dir_combo.currentTextChanged.connect(self._on_direction_changed)
        self.mid_btn.clicked.connect(self._set_midspan)

    def getStandardButtons(self):
        return QtWidgets.QDialogButtonBox.Close

    def accept(self):
        FreeCADGui.Control.closeDialog()
        return True

    def reject(self):
        FreeCADGui.Control.closeDialog()
        return True

    def _recompute(self):
        try:
            FreeCAD.ActiveDocument.recompute()
        except Exception:
            pass

    def _on_force_changed(self, value):
        if self._connecting:
            return
        self.obj.PointLoading = FreeCAD.Units.Quantity(value, "N")
        self._recompute()

    def _on_distance_changed(self, value):
        if self._connecting:
            return
        self.obj.Distance = FreeCAD.Units.Quantity(value, "mm")
        self._recompute()

    def _on_scale_changed(self, value):
        if self._connecting:
            return
        self.obj.ScaleDraw = float(value)
        self._recompute()

    def _on_direction_changed(self, value):
        if self._connecting:
            return
        self.obj.GlobalDirection = value
        self._recompute()

    def _set_midspan(self):
        try:
            subname = self.obj.ObjectBase[0][1][0]
            if 'Edge' not in subname:
                return
            index = int(subname.split('Edge')[1]) - 1
            edge = self.obj.ObjectBase[0][0].Shape.Edges[index]
            self.distance_spin.setValue(edge.Length / 2.0)
        except Exception:
            pass


class ViewProviderLoadPoint:
    def __init__(self, obj):
        obj.Proxy = self

    def getIcon(self):
        return os.path.join(ICONPATH, "icons/load_point.svg")


class CommandLoadPoint():
    def GetResources(self):
        return {
            "Pixmap": os.path.join(ICONPATH, "icons/load_point.svg"),
            "Accel": "Shift+P",
            "MenuText": "Point Load",
            "ToolTip": "Adds a point load along a member",
        }

    def Activated(self):
        selections = list(FreeCADGui.Selection.getSelectionEx())
        if not selections:
            show_error_message("Select a beam edge or a point load to edit.")
            return

        if len(selections) == 1 and not selections[0].HasSubObjects:
            selected_obj = selections[0].Object
            if (
                selected_obj
                and hasattr(selected_obj, "PointLoading")
                and hasattr(selected_obj, "Distance")
                and hasattr(selected_obj, "GlobalDirection")
            ):
                panel = PointLoadTaskPanel(selected_obj)
                FreeCADGui.Control.showDialog(panel)
                return

        created = 0
        last_obj = None
        for selection in selections:
            if selection.HasSubObjects:
                for subSelectionname in selection.SubElementNames:
                    if 'Edge' not in subSelectionname:
                        continue
                    doc = FreeCAD.ActiveDocument
                    obj = doc.addObject("Part::FeaturePython", "Load_Point")
                    LoadPoint(obj, (selection.Object, subSelectionname))
                    ViewProviderLoadPoint(obj.ViewObject)
                    created += 1
                    last_obj = obj
            else:
                line = selection.Object
                edges = line.Shape.Edges
                for i in range(len(edges)):
                    doc = FreeCAD.ActiveDocument
                    obj = doc.addObject("Part::FeaturePython", "Load_Point")
                    LoadPoint(obj, (selection.Object, 'Edge' + str(i + 1)))
                    ViewProviderLoadPoint(obj.ViewObject)
                    created += 1
                    last_obj = obj

        if created == 0:
            show_error_message("Select an edge to add a point load.")
            return

        FreeCAD.ActiveDocument.recompute()
        if created == 1 and last_obj:
            panel = PointLoadTaskPanel(last_obj)
            FreeCADGui.Control.showDialog(panel)
        return

    def IsActive(self):
        return True


FreeCADGui.addCommand("load_point", CommandLoadPoint())
