# -*- coding: utf-8 -*-
"""
StructureTools - Calculation Module with Segmentation Control GUI

Main FEA analysis using PyNite solver with operator-controlled mesh refinement.
"""

import os
import math
from typing import List, Dict, Tuple, Optional, Any
import FreeCAD as App
import FreeCADGui as Gui
import Part
from PySide import QtWidgets, QtCore, QtGui

from . import logger
from .ui_helpers import show_error_message, show_success_message
from .unit_manager import get_current_units, get_length_unit, get_force_unit
from .simple_review_dialog import SimpleReviewDialog

ICONPATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))

# Import bundled PyNite solver
try:
    from .Pynite_main.FEModel3D import FEModel3D
except ImportError:
    logger.error("calc: PyNite solver not found in Pynite_main folder")
    FEModel3D = None


# ============================================================
# SEGMENTATION CONTROL GUI
# ============================================================

class SegmentationDialog(QtWidgets.QDialog):
    """
    Pre-analysis dialog for controlling member segmentation.
    Allows operator to choose accuracy level with visual feedback.
    """
    
    def __init__(self, num_members, parent=None):
        super().__init__(parent)
        self.num_members = num_members
        self.segments_per_member = 4  # Default
        self.selfweight_enabled = False  # Default OFF for backward compatibility
        self.refine_at_supports = True  # Default ON for better accuracy

        self.setWindowTitle("Analysis Settings")
        self.setMinimumWidth(500)
        self.setup_ui()
        
    def setup_ui(self):
        """Build the dialog UI."""
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QLabel("Configure Analysis Accuracy")
        header.setStyleSheet("font-size: 14pt; font-weight: bold; color: #2c3e50;")
        layout.addWidget(header)

        # Display current unit system
        try:
            current_units = get_current_units()
            unit_info = QtWidgets.QLabel(
                f"📏 <b>Unit System:</b> {current_units.name}<br>"
                f"<i>Length: {current_units.length}, Force: {current_units.force}</i>"
            )
            unit_info.setStyleSheet("""
                QLabel {
                    background-color: #e3f2fd;
                    border: 1px solid #2196f3;
                    border-radius: 3px;
                    padding: 8px;
                    color: #1565c0;
                }
            """)
            layout.addWidget(unit_info)
        except Exception as exc:
            logger.warn(f"calc: could not display unit info: {exc}")

        layout.addSpacing(10)
        
        # Info panel
        info_group = QtWidgets.QGroupBox("Model Information")
        info_layout = QtWidgets.QFormLayout()
        
        self.members_label = QtWidgets.QLabel(f"{self.num_members}")
        self.members_label.setStyleSheet("font-weight: bold;")
        info_layout.addRow("Members in model:", self.members_label)
        
        self.elements_label = QtWidgets.QLabel(f"{self.num_members * self.segments_per_member}")
        self.elements_label.setStyleSheet("font-weight: bold; color: #27ae60;")
        info_layout.addRow("Total elements:", self.elements_label)
        
        self.accuracy_label = QtWidgets.QLabel("Intermediate")
        self.accuracy_label.setStyleSheet("font-weight: bold; color: #f39c12;")
        info_layout.addRow("Accuracy level:", self.accuracy_label)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        layout.addSpacing(10)
        
        # Preset buttons
        preset_group = QtWidgets.QGroupBox("Accuracy Presets")
        preset_layout = QtWidgets.QVBoxLayout()
        
        # Quick Calc
        quick_btn = QtWidgets.QPushButton("⚡ Quick Calc (2 segments)")
        quick_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        quick_btn.clicked.connect(lambda: self.set_preset(2))
        preset_layout.addWidget(quick_btn)
        
        quick_desc = QtWidgets.QLabel("• Fast analysis for preliminary design\n• Suitable for simple loading\n• ±10-15% accuracy")
        quick_desc.setStyleSheet("color: #7f8c8d; margin-left: 20px; font-size: 9pt;")
        preset_layout.addWidget(quick_desc)
        
        preset_layout.addSpacing(5)
        
        # Intermediate
        inter_btn = QtWidgets.QPushButton("📊 Intermediate (4 segments)")
        inter_btn.setStyleSheet("""
            QPushButton {
                background-color: #f39c12;
                color: white;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #e67e22;
            }
        """)
        inter_btn.clicked.connect(lambda: self.set_preset(4))
        preset_layout.addWidget(inter_btn)
        
        inter_desc = QtWidgets.QLabel("• Balanced speed and accuracy\n• Good for most applications\n• ±3-5% accuracy")
        inter_desc.setStyleSheet("color: #7f8c8d; margin-left: 20px; font-size: 9pt;")
        preset_layout.addWidget(inter_desc)
        
        preset_layout.addSpacing(5)
        
        # High Accuracy
        high_btn = QtWidgets.QPushButton("🎯 High Accuracy (8 segments)")
        high_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #229954;
            }
        """)
        high_btn.clicked.connect(lambda: self.set_preset(8))
        preset_layout.addWidget(high_btn)
        
        high_desc = QtWidgets.QLabel("• Detailed analysis for final design\n• Complex loading patterns\n• ±1-2% accuracy (slower)")
        high_desc.setStyleSheet("color: #7f8c8d; margin-left: 20px; font-size: 9pt;")
        preset_layout.addWidget(high_desc)
        
        preset_layout.addSpacing(5)
        
        # Ultra High
        ultra_btn = QtWidgets.QPushButton("🔬 Ultra High (16 segments)")
        ultra_btn.setStyleSheet("""
            QPushButton {
                background-color: #8e44ad;
                color: white;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #6c3483;
            }
        """)
        ultra_btn.clicked.connect(lambda: self.set_preset(16))
        preset_layout.addWidget(ultra_btn)
        
        ultra_desc = QtWidgets.QLabel("• Research-grade accuracy\n• Stress concentrations\n• <1% accuracy (very slow)")
        ultra_desc.setStyleSheet("color: #7f8c8d; margin-left: 20px; font-size: 9pt;")
        preset_layout.addWidget(ultra_desc)
        
        preset_group.setLayout(preset_layout)
        layout.addWidget(preset_group)
        
        layout.addSpacing(10)
        
        # Custom control
        custom_group = QtWidgets.QGroupBox("Custom Settings")
        custom_layout = QtWidgets.QFormLayout()
        
        self.segment_spin = QtWidgets.QSpinBox()
        self.segment_spin.setRange(1, 100)
        self.segment_spin.setValue(4)
        self.segment_spin.valueChanged.connect(self.update_info)
        custom_layout.addRow("Segments per member:", self.segment_spin)

        # Self-weight checkbox - RE-IMPLEMENTED with proper persistence fix
        self.selfweight_check = QtWidgets.QCheckBox("Include self-weight (gravity load)")
        self.selfweight_check.setChecked(False)  # Default OFF for backward compatibility
        self.selfweight_check.setToolTip(
            "Automatically calculate and apply self-weight based on:\n"
            "• Section area (from section properties)\n"
            "• Material density (e.g., 7850 kg/m³ for steel)\n"
            "• Gravity (9.81 m/s²)\n\n"
            "Applied as distributed load in -Z direction."
        )
        self.selfweight_check.stateChanged.connect(self.on_selfweight_changed)
        custom_layout.addRow("", self.selfweight_check)

        # Auto-refine mesh at supports checkbox
        self.refine_at_supports_check = QtWidgets.QCheckBox("Refine mesh at support locations")
        self.refine_at_supports_check.setChecked(True)  # Default ON for better accuracy
        self.refine_at_supports_check.setToolTip(
            "Automatically add nodes at exact support locations for perfect accuracy.\n"
            "Recommended: ON (ensures supports are exactly where you placed them)"
        )
        self.refine_at_supports_check.stateChanged.connect(self.on_refine_changed)
        custom_layout.addRow("", self.refine_at_supports_check)

        custom_group.setLayout(custom_layout)
        layout.addWidget(custom_group)
        
        layout.addSpacing(10)
        
        # Warning for large models
        self.warning_label = QtWidgets.QLabel("")
        self.warning_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
        self.warning_label.setWordWrap(True)
        layout.addWidget(self.warning_label)
        
        layout.addSpacing(10)
        
        # Buttons
        button_box = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Initialize display
        self.update_info()
    
    def set_preset(self, segments):
        """Set preset segmentation level."""
        self.segment_spin.setValue(segments)

    def on_refine_changed(self, state):
        """Handle refine at supports checkbox change."""
        self.refine_at_supports = (state == QtCore.Qt.Checked)

    def on_selfweight_changed(self, state):
        """Handle self-weight checkbox change - PERSISTENCE FIX."""
        # CRITICAL FIX: Qt returns CheckState enum (value 2 for Checked), not boolean
        # Must compare integer value, not enum object
        self.selfweight_enabled = (int(state) == 2)  # 2 = Qt.CheckState.Checked
        logger.info(f"DEBUG calc_dialog: self-weight checkbox state={state} (int={int(state)})")
        logger.info(f"DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled={self.selfweight_enabled}")

    def update_info(self):
        """Update information display based on current settings."""
        segments = self.segment_spin.value()
        total_elements = self.num_members * segments
        
        self.elements_label.setText(f"{total_elements}")
        
        # Determine accuracy level
        if segments <= 2:
            level = "Quick"
            color = "#3498db"
        elif segments <= 4:
            level = "Intermediate"
            color = "#f39c12"
        elif segments <= 8:
            level = "High"
            color = "#27ae60"
        else:
            level = "Ultra High"
            color = "#8e44ad"
        
        self.accuracy_label.setText(level)
        self.accuracy_label.setStyleSheet(f"font-weight: bold; color: {color};")
        
        # Warning for large models
        if total_elements > 500:
            self.warning_label.setText(
                f"⚠ Warning: {total_elements} elements may take significant time to analyze.\n"
                f"Consider reducing segments for large models."
            )
        elif total_elements > 1000:
            self.warning_label.setText(
                f"⚠ WARNING: {total_elements} elements will take a LONG time!\n"
                f"Strongly recommend reducing segments or splitting model."
            )
        else:
            self.warning_label.setText("")
    
    def get_values(self):
        """Return chosen settings - PERSISTENCE FIX: includes selfweight."""
        return {
            'segments': self.segment_spin.value(),
            'selfweight': self.selfweight_enabled,  # PERSISTENCE FIX: return checkbox value
            'refine_at_supports': self.refine_at_supports
        }


# ============================================================
# DIRECTION MAPPING
# ============================================================

def get_axis_and_direction(global_direction: str):
    """Convert global direction string to solver axis and sign."""
    if global_direction == '+X':
        return 'FX', 1
    elif global_direction == '-X':
        return 'FX', -1
    elif global_direction == '+Y':
        return 'FZ', 1  # Y/Z swap for solver coordinates
    elif global_direction == '-Y':
        return 'FZ', -1
    elif global_direction == '+Z':
        return 'FY', 1  # Y/Z swap for solver coordinates
    elif global_direction == '-Z':
        return 'FY', -1
    else:
        logger.warn(f"calc: unknown load direction: {global_direction}")
        return None, None


# Coordinate helpers (FreeCAD uses X,Y,Z; solver uses X,Z,Y)
def freecad_to_solver(point: App.Vector) -> App.Vector:
    return App.Vector(point.x, point.z, point.y)


def solver_to_freecad(point: App.Vector) -> App.Vector:
    return App.Vector(point.x, point.z, point.y)


# ============================================================
# CALC OBJECT
# ============================================================

class Calc:
    """
    FeaturePython object that runs structural analysis.
    
    Collects all members, loads, supports, materials, and sections
    then runs the PyNite FEA solver with operator-controlled segmentation.
    """
    
    def __init__(self, obj, elements=None, segments_per_member=4, refine_at_supports=True, selfweight_enabled=False):
        """
        Initialize Calc object.

        Args:
            obj: FreeCAD DocumentObject to extend
            elements: List of elements to include in analysis
            segments_per_member: Number of segments to subdivide each member
            refine_at_supports: Automatically add nodes at support locations for exact placement
            selfweight_enabled: Include self-weight in analysis (from dialog checkbox)
        """
        self.Type = "StructureTools::Calc"
        self._executing = False  # Guard flag to prevent re-entrant execution
        obj.Proxy = self
        
        # Input properties
        obj.addProperty(
            "App::PropertyLinkList", "ListElements", "Calc",
            "Elements to include in analysis"
        )
        if elements:
            obj.ListElements = elements
        
        obj.addProperty(
            "App::PropertyInteger", "SegmentsPerMember", "Calc",
            "Number of segments per member for accuracy"
        )
        obj.SegmentsPerMember = segments_per_member
        
        # Get units from unit manager
        current_units = get_current_units()

        obj.addProperty(
            "App::PropertyString", "LengthUnit", "Calc",
            "Length unit for calculation (from unit manager)"
        )
        obj.LengthUnit = current_units.length

        obj.addProperty(
            "App::PropertyString", "ForceUnit", "Calc",
            "Force unit for calculation (from unit manager)"
        )
        obj.ForceUnit = current_units.force

        obj.addProperty(
            "App::PropertyString", "UnitSystemName", "Calc",
            "Unit system name"
        )
        obj.UnitSystemName = current_units.name
        
        obj.addProperty(
            "App::PropertyFloat", "NodeTolerance", "Calc",
            "Tolerance for node matching"
        )
        obj.NodeTolerance = 1e-4

        # SelfWeight property - RE-IMPLEMENTED with proper persistence fix
        obj.addProperty(
            "App::PropertyBool", "SelfWeight", "Calc",
            "Include self-weight in analysis (gravity load based on section area and material density)"
        )
        obj.SelfWeight = selfweight_enabled  # Set from dialog checkbox (passed to constructor)
        logger.info(f"calc: SelfWeight property initialized to {obj.SelfWeight} (from constructor parameter)")

        obj.addProperty(
            "App::PropertyBool", "RefineAtSupports", "Calc",
            "Automatically add nodes at exact support locations"
        )
        obj.RefineAtSupports = refine_at_supports

        # Output properties
        obj.addProperty("App::PropertyStringList", "NameMembers", "Output", "Member names")
        obj.addProperty("App::PropertyVectorList", "Nodes", "Output", "Node coordinates")
        
        # Moment results
        obj.addProperty("App::PropertyStringList", "MomentY", "ResultMoment", "Moment about Y")
        obj.addProperty("App::PropertyStringList", "MomentZ", "ResultMoment", "Moment about Z")
        obj.addProperty("App::PropertyFloatList", "MinMomentY", "ResultMoment", "Min moment Y")
        obj.addProperty("App::PropertyFloatList", "MinMomentZ", "ResultMoment", "Min moment Z")
        obj.addProperty("App::PropertyFloatList", "MaxMomentY", "ResultMoment", "Max moment Y")
        obj.addProperty("App::PropertyFloatList", "MaxMomentZ", "ResultMoment", "Max moment Z")
        obj.addProperty("App::PropertyInteger", "NumPointsMoment", "NumPoints", "Sampling points").NumPointsMoment = 11
        
        # Axial results
        obj.addProperty("App::PropertyStringList", "AxialForce", "ResultAxial", "Axial force")
        obj.addProperty("App::PropertyInteger", "NumPointsAxial", "NumPoints", "Sampling points").NumPointsAxial = 5
        
        # Torque results
        obj.addProperty("App::PropertyStringList", "Torque", "ResultTorque", "Torque")
        obj.addProperty("App::PropertyFloatList", "MinTorque", "ResultTorque", "Min torque")
        obj.addProperty("App::PropertyFloatList", "MaxTorque", "ResultTorque", "Max torque")
        obj.addProperty("App::PropertyInteger", "NumPointsTorque", "NumPoints", "Sampling points").NumPointsTorque = 5
        
        # Shear results
        obj.addProperty("App::PropertyStringList", "ShearY", "ResultShear", "Shear in Y")
        obj.addProperty("App::PropertyStringList", "ShearZ", "ResultShear", "Shear in Z")
        obj.addProperty("App::PropertyFloatList", "MinShearY", "ResultShear", "Min shear Y")
        obj.addProperty("App::PropertyFloatList", "MinShearZ", "ResultShear", "Min shear Z")
        obj.addProperty("App::PropertyFloatList", "MaxShearY", "ResultShear", "Max shear Y")
        obj.addProperty("App::PropertyFloatList", "MaxShearZ", "ResultShear", "Max shear Z")
        obj.addProperty("App::PropertyInteger", "NumPointsShear", "NumPoints", "Sampling points").NumPointsShear = 11
        
        # Deflection results
        obj.addProperty("App::PropertyStringList", "DeflectionY", "ResultDeflection", "Deflection Y")
        obj.addProperty("App::PropertyStringList", "DeflectionZ", "ResultDeflection", "Deflection Z")
        obj.addProperty("App::PropertyFloatList", "MinDeflectionY", "ResultDeflection", "Min deflection Y")
        obj.addProperty("App::PropertyFloatList", "MinDeflectionZ", "ResultDeflection", "Min deflection Z")
        obj.addProperty("App::PropertyFloatList", "MaxDeflectionY", "ResultDeflection", "Max deflection Y")
        obj.addProperty("App::PropertyFloatList", "MaxDeflectionZ", "ResultDeflection", "Max deflection Z")
        obj.addProperty("App::PropertyInteger", "NumPointsDeflection", "NumPoints", "Sampling points").NumPointsDeflection = 11
    
    def onDocumentRestored(self, obj):
        """Handle document restore."""
        self.Type = "StructureTools::Calc"
    
    def onChanged(self, obj, prop):
        """Handle property changes."""
        pass
    
    # =========================================================
    # NODE MAPPING WITH SEGMENTATION
    # =========================================================

    def extract_support_locations(
        self,
        supports: List[Any],
        unitLength: str
    ) -> List[List[float]]:
        """
        Extract support locations in solver coordinates for mesh refinement.

        Args:
            supports: List of support objects
            unitLength: Target length unit

        Returns:
            List of support coordinates [x, y, z] in solver system
        """
        support_locs = []

        def _mm_to_len(val_mm):
            """Convert millimeters to target unit."""
            return float(App.Units.Quantity(val_mm, 'mm').getValueAs(unitLength))

        for support in supports:
            loc = None

            # Try ObjectBase parsing (vertex or edge)
            if hasattr(support, "ObjectBase") and support.ObjectBase:
                obj_base = support.ObjectBase

                # Extract first element if it's a list
                if isinstance(obj_base, list) and len(obj_base) > 0:
                    obj_base = obj_base[0]

                if isinstance(obj_base, (tuple, list)) and len(obj_base) == 2:
                    base_obj, sub_names = obj_base
                elif isinstance(obj_base, (tuple, list)) and len(obj_base) == 1:
                    base_obj = obj_base[0]
                    sub_names = []
                else:
                    base_obj = obj_base
                    sub_names = []

                sub_name = None
                if isinstance(sub_names, (list, tuple)) and len(sub_names) > 0:
                    sub_name = sub_names[0]

                # Handle vertex support
                if sub_name and "Vertex" in sub_name and hasattr(base_obj, "Shape"):
                    try:
                        idx = int(sub_name.replace("Vertex", "")) - 1
                        verts = getattr(base_obj.Shape, "Vertexes", [])
                        if 0 <= idx < len(verts):
                            vtx = verts[idx].Point
                            loc = [_mm_to_len(vtx.x), _mm_to_len(vtx.z), _mm_to_len(vtx.y)]
                    except Exception:
                        pass

                # Handle edge support
                elif sub_name and "Edge" in sub_name and hasattr(base_obj, "Shape"):
                    try:
                        idx = int(sub_name.replace("Edge", "")) - 1
                        edges = getattr(base_obj.Shape, "Edges", [])
                        if 0 <= idx < len(edges):
                            edge = edges[idx]
                            distance_mm = 0.0
                            if hasattr(support, "Distance"):
                                distance_mm = float(support.Distance.getValueAs("mm"))
                            else:
                                distance_mm = edge.Length / 2.0

                            start = edge.Vertexes[0].Point
                            end = edge.Vertexes[1].Point
                            direction = end.sub(start)
                            length = direction.Length

                            if length > 1e-6:
                                distance_mm = max(0.0, min(distance_mm, length))
                                t = distance_mm / length
                                point = start.add(direction.multiply(t))
                                loc = [_mm_to_len(point.x), _mm_to_len(point.z), _mm_to_len(point.y)]
                    except Exception:
                        pass

            if loc:
                support_locs.append(loc)

        return support_locs

    def mapNodes(
        self,
        elements: List[Any],
        unitLength: str,
        segments_per_member: int,
        tol: float = 1e-4,
        support_locations: List[List[float]] = None
    ) -> List[List[float]]:
        """
        Map nodes from FreeCAD geometry with member segmentation.

        Args:
            elements: List of line/wire elements
            unitLength: Target length unit (e.g., 'm', 'mm')
            segments_per_member: Number of segments to divide each member (must be >= 1, max 100)
            tol: Tolerance for matching existing nodes (must be > 0)
            support_locations: Optional list of support coords [x,y,z] to add as nodes

        Returns:
            List of node coordinates [x, y, z] in solver system

        Raises:
            ValueError: If input parameters are invalid
        """
        # Input validation
        if segments_per_member < 1:
            raise ValueError(f"segments_per_member must be >= 1, got {segments_per_member}")
        if segments_per_member > 100:
            raise ValueError(f"segments_per_member too large (max 100), got {segments_per_member}")
        if tol <= 0:
            raise ValueError(f"tolerance must be positive, got {tol}")
        if not elements:
            raise ValueError("elements list cannot be empty")

        listNodes = []

        def add_node_if_new(x, y, z):
            """Add node if it doesn't already exist within tolerance."""
            node = [x, y, z]
            for idx, n in enumerate(listNodes):
                if abs(n[0] - node[0]) < tol and abs(n[1] - node[1]) < tol and abs(n[2] - node[2]) < tol:
                    return idx
            listNodes.append(node)
            return len(listNodes) - 1

        # Pre-add support locations if mesh refinement is enabled
        if support_locations:
            for sup_loc in support_locations:
                add_node_if_new(sup_loc[0], sup_loc[1], sup_loc[2])
            logger.info(f"calc: pre-added {len(support_locations)} support locations as nodes for exact placement")

        for element in elements:
            if not hasattr(element, 'Shape') or not element.Shape:
                continue
            
            for edge in element.Shape.Edges:
                # Get edge endpoints
                v1 = edge.Vertexes[0].Point
                v2 = edge.Vertexes[1].Point
                
                # Convert to solver coordinates and units
                x1 = float(App.Units.Quantity(v1.x, 'mm').getValueAs(unitLength))
                y1 = float(App.Units.Quantity(v1.z, 'mm').getValueAs(unitLength))  # Swap
                z1 = float(App.Units.Quantity(v1.y, 'mm').getValueAs(unitLength))  # Swap
                
                x2 = float(App.Units.Quantity(v2.x, 'mm').getValueAs(unitLength))
                y2 = float(App.Units.Quantity(v2.z, 'mm').getValueAs(unitLength))
                z2 = float(App.Units.Quantity(v2.y, 'mm').getValueAs(unitLength))
                
                # Add endpoint nodes
                add_node_if_new(x1, y1, z1)
                add_node_if_new(x2, y2, z2)
                
                # Add intermediate nodes for segmentation
                if segments_per_member > 1:
                    for i in range(1, segments_per_member):
                        t = i / segments_per_member
                        xi = x1 + t * (x2 - x1)
                        yi = y1 + t * (y2 - y1)
                        zi = z1 + t * (z2 - z1)
                        add_node_if_new(xi, yi, zi)
        
        return listNodes
    
    # =========================================================
    # MEMBER MAPPING WITH SEGMENTATION
    # =========================================================
    
    def mapMembers(
        self,
        elements: List[Any],
        listNodes: List[List[float]],
        unitLength: str,
        segments_per_member: int,
        tol: float = 1e-4
    ) -> Dict[str, Dict[str, Any]]:
        """
        Map members from FreeCAD geometry with automatic segmentation.

        This function creates FEA members by connecting consecutive nodes along each edge.
        It respects existing nodes (including those added by mesh refinement at supports),
        ensuring that members are created between all nodes on the edge, not just uniform segments.

        Args:
            elements: List of line/wire elements
            listNodes: Existing node list (may include pre-added nodes from mesh refinement)
            unitLength: Target length unit
            segments_per_member: Ignored - kept for API compatibility (members created between all existing nodes)
            tol: Node matching tolerance (must be > 0)

        Returns:
            Dictionary of member definitions

        Raises:
            ValueError: If input parameters are invalid
        """
        # Input validation
        if segments_per_member < 1:
            raise ValueError(f"segments_per_member must be >= 1, got {segments_per_member}")
        if segments_per_member > 100:
            raise ValueError(f"segments_per_member too large (max 100), got {segments_per_member}")
        if tol <= 0:
            raise ValueError(f"tolerance must be positive, got {tol}")
        if not elements:
            raise ValueError("elements list cannot be empty")
        if not listNodes:
            raise ValueError("listNodes cannot be empty")

        listMembers = {}

        def point_on_line_segment(p, v1, v2, tol):
            """Check if point p lies on line segment from v1 to v2, return parametric position if true."""
            # Vector from v1 to v2
            dx = v2[0] - v1[0]
            dy = v2[1] - v1[1]
            dz = v2[2] - v1[2]
            length_sq = dx*dx + dy*dy + dz*dz

            if length_sq < 1e-10:  # Degenerate edge
                return None

            # Vector from v1 to p
            px = p[0] - v1[0]
            py = p[1] - v1[1]
            pz = p[2] - v1[2]

            # Parametric position along line
            t = (px*dx + py*dy + pz*dz) / length_sq

            # Check if t is within [0, 1] with some tolerance
            if t < -tol or t > 1.0 + tol:
                return None

            # Check perpendicular distance
            proj_x = v1[0] + t * dx
            proj_y = v1[1] + t * dy
            proj_z = v1[2] + t * dz

            dist_sq = (p[0] - proj_x)**2 + (p[1] - proj_y)**2 + (p[2] - proj_z)**2

            if dist_sq > tol * tol:
                return None

            return max(0.0, min(1.0, t))  # Clamp to [0, 1]

        for element in elements:
            if not hasattr(element, 'Shape') or not element.Shape:
                continue

            for edge_idx, edge in enumerate(element.Shape.Edges):
                # Get edge endpoints in solver coordinates
                v1 = edge.Vertexes[0].Point
                v2 = edge.Vertexes[1].Point

                x1 = float(App.Units.Quantity(v1.x, 'mm').getValueAs(unitLength))
                y1 = float(App.Units.Quantity(v1.z, 'mm').getValueAs(unitLength))
                z1 = float(App.Units.Quantity(v1.y, 'mm').getValueAs(unitLength))

                x2 = float(App.Units.Quantity(v2.x, 'mm').getValueAs(unitLength))
                y2 = float(App.Units.Quantity(v2.z, 'mm').getValueAs(unitLength))
                z2 = float(App.Units.Quantity(v2.y, 'mm').getValueAs(unitLength))

                # Find all nodes that lie on this edge
                nodes_on_edge = []
                for node_idx, node in enumerate(listNodes):
                    t = point_on_line_segment(node, [x1, y1, z1], [x2, y2, z2], tol)
                    if t is not None:
                        nodes_on_edge.append((t, node_idx, node))

                # Sort nodes by parametric position along edge
                nodes_on_edge.sort(key=lambda x: x[0])

                if len(nodes_on_edge) < 2:
                    logger.warning(f"calc: edge {edge_idx} of {element.Name} has fewer than 2 nodes, skipping")
                    continue

                # Get material and section
                material_name = 'default'
                section_name = 'default'

                if hasattr(element, 'MaterialMember') and element.MaterialMember:
                    material_name = element.MaterialMember.Name

                if hasattr(element, 'SectionMember') and element.SectionMember:
                    section_name = element.SectionMember.Name

                # Check for truss member
                is_truss = False
                if hasattr(element, 'TrussMember'):
                    is_truss = element.TrussMember
                elif hasattr(element, 'MemberType'):
                    is_truss = (element.MemberType == 'Truss')

                # Create members between consecutive nodes
                for seg in range(len(nodes_on_edge) - 1):
                    n1_idx = nodes_on_edge[seg][1]
                    n2_idx = nodes_on_edge[seg + 1][1]

                    # Create member name with segment suffix
                    member_name = f"{element.Name}_e{edge_idx}_s{seg}"

                    listMembers[member_name] = {
                        'nodes': [str(n1_idx), str(n2_idx)],
                        'material': material_name,
                        'section': section_name,
                        'trussMember': is_truss,
                        'original_element': element.Name,
                        'segment_number': seg
                    }

        logger.info(f"calc: created {len(listMembers)} members from {len(elements)} elements")
        
        return listMembers
    
    # =========================================================
    # MODEL BUILDING (unchanged from original)
    # =========================================================
    
    def setNodes(self, model, nodes_map):
        """Add nodes to solver model."""
        for i, node in enumerate(nodes_map):
            model.add_node(str(i), node[0], node[1], node[2])
        return model
    
    def setMembers(self, model, members_map):
        """Add members to solver model."""
        for memberName, member_data in members_map.items():
            # DEBUG: Log member properties being added
            mat_name = member_data['material']
            sec_name = member_data['section']

            # Get the actual section and material objects to log their properties
            if mat_name in model.materials:
                mat = model.materials[mat_name]
                logger.info(f"DEBUG MEMBER [{memberName}]: Material={mat_name}, E={mat.E}, nu={mat.nu}, rho={mat.rho}")
            else:
                logger.warning(f"DEBUG MEMBER [{memberName}]: Material={mat_name} NOT FOUND in model!")

            if sec_name in model.sections:
                sec = model.sections[sec_name]
                logger.info(f"DEBUG MEMBER [{memberName}]: Section={sec_name}, A={sec.A}, Iy={sec.Iy}, Iz={sec.Iz}, J={sec.J}")
            else:
                logger.warning(f"DEBUG MEMBER [{memberName}]: Section={sec_name} NOT FOUND in model!")

            # Get node coordinates to calculate member length
            node1_idx = member_data['nodes'][0]
            node2_idx = member_data['nodes'][1]
            if node1_idx in model.nodes and node2_idx in model.nodes:
                n1 = model.nodes[node1_idx]
                n2 = model.nodes[node2_idx]
                import math
                length = math.sqrt((n2.X-n1.X)**2 + (n2.Y-n1.Y)**2 + (n2.Z-n1.Z)**2)
                logger.info(f"DEBUG MEMBER [{memberName}]: Length={length:.6f} m (nodes {node1_idx} to {node2_idx})")

            model.add_member(
                memberName,
                member_data['nodes'][0],
                member_data['nodes'][1],
                member_data['material'],
                member_data['section']
            )

            # Release rotations for truss members
            if member_data['trussMember']:
                model.def_releases(
                    memberName,
                    Dxi=False, Dyi=False, Dzi=False,
                    Rxi=False, Ryi=True, Rzi=True,
                    Dxj=False, Dyj=False, Dzj=False,
                    Rxj=False, Ryj=True, Rzj=True
                )
        
        return model
    
    def setMaterialAndSections(self, model, lines, unitLength, unitForce):
        """Add materials and sections to solver model."""
        materials_added = []
        sections_added = []
        
        for line in lines:
            if not hasattr(line, 'MaterialMember') or not line.MaterialMember:
                continue
            if not hasattr(line, 'SectionMember') or not line.SectionMember:
                continue
            
            material = line.MaterialMember
            section = line.SectionMember
            
            # Add material
            if material.Name not in materials_added:
                # CORRECTED: kg/m³ → kN/m³ using g=9.81 m/s²
                # density [kN/m³] = density [kg/m³] × 9.81/1000
                density_kg_m3 = float(App.Units.Quantity(material.Density).getValueAs('kg/m^3'))
                density_kN_m3 = density_kg_m3 * 9.81 / 1000
                # Convert to target unit system
                density = float(App.Units.Quantity(density_kN_m3, 'kN/m^3').getValueAs(f"{unitForce}/{unitLength}^3"))
                
                # Young's modulus conversion
                # FreeCAD stores in Pa (base SI unit for pressure/stress)
                # Convert: Pa → MPa → GPa → kN/m²
                # 1 Pa = 1 N/m² = 0.001 kN/m²
                E_pa = float(material.ModulusElasticity.getValueAs('Pa'))
                E = E_pa / 1000.0  # Pa → kN/m² (1 Pa = 0.001 kN/m²)
                nu = float(material.PoissonRatio) if hasattr(material, 'PoissonRatio') else 0.3

                logger.info(f"DEBUG MATERIAL [{material.Name}]: Raw E = {E_pa} Pa = {E_pa/1e9:.1f} GPa")
                logger.info(f"DEBUG MATERIAL [{material.Name}]: Converted E = {E} kN/m² (for solver)")
                logger.info(f"DEBUG MATERIAL [{material.Name}]: Density = {density} kN/m³ (from {density_kg_m3} kg/m³)")
                logger.info(f"DEBUG MATERIAL [{material.Name}]: Poisson ratio = {nu}")

                # Validate material properties
                if E <= 0:
                    raise ValueError(f"Material '{material.Name}' has invalid elastic modulus: {E} (must be > 0)")
                if nu < -1.0 or nu > 0.5:
                    raise ValueError(f"Material '{material.Name}' has invalid Poisson ratio: {nu} (must be between -1 and 0.5)")
                if density <= 0:
                    raise ValueError(f"Material '{material.Name}' has invalid density: {density} (must be > 0)")

                G = E / (2 * (1 + nu))

                model.add_material(material.Name, E, G, nu, density)
                materials_added.append(material.Name)
                logger.info(f"✅ Material '{material.Name}' added to solver")
            
            # Add section
            if section.Name not in sections_added:
                # DEBUG: Show raw area value from FreeCAD
                A_raw_str = str(section.AreaSection)
                logger.info(f"DEBUG SECTION [{section.Name}]: Raw AreaSection from FreeCAD = {A_raw_str}")

                # Try getting area in different units to verify conversion
                A_cm2 = float(section.AreaSection.getValueAs('cm^2')) if hasattr(section.AreaSection, 'getValueAs') else 0
                A_mm2 = float(section.AreaSection.getValueAs('mm^2')) if hasattr(section.AreaSection, 'getValueAs') else 0
                A = float(section.AreaSection.getValueAs(f"{unitLength}^2"))

                logger.info(f"DEBUG SECTION [{section.Name}]: Area conversions: {A_cm2} cm², {A_mm2} mm², {A} {unitLength}²")

                # Handle different inertia property names
                if hasattr(section, 'MomentInertiaY'):
                    Iy_mm4 = float(App.Units.Quantity(section.MomentInertiaY, 'mm^4').getValueAs('mm^4'))
                    Iy = float(App.Units.Quantity(section.MomentInertiaY, 'mm^4').getValueAs(f"{unitLength}^4"))
                elif hasattr(section, 'Iy'):
                    Iy_mm4 = float(App.Units.Quantity(section.Iy, 'mm^4').getValueAs('mm^4'))
                    Iy = float(App.Units.Quantity(section.Iy, 'mm^4').getValueAs(f"{unitLength}^4"))
                else:
                    Iy_mm4 = 0
                    Iy = 0

                if hasattr(section, 'MomentInertiaZ'):
                    Iz_mm4 = float(App.Units.Quantity(section.MomentInertiaZ, 'mm^4').getValueAs('mm^4'))
                    Iz = float(App.Units.Quantity(section.MomentInertiaZ, 'mm^4').getValueAs(f"{unitLength}^4"))
                elif hasattr(section, 'Iz'):
                    Iz_mm4 = float(App.Units.Quantity(section.Iz, 'mm^4').getValueAs('mm^4'))
                    Iz = float(App.Units.Quantity(section.Iz, 'mm^4').getValueAs(f"{unitLength}^4"))
                else:
                    Iz_mm4 = 0
                    Iz = 0

                if hasattr(section, 'TorsionConstant'):
                    J = float(App.Units.Quantity(section.TorsionConstant, 'mm^4').getValueAs(f"{unitLength}^4"))
                elif hasattr(section, 'MomentInertiaPolar'):
                    J = float(App.Units.Quantity(section.MomentInertiaPolar, 'mm^4').getValueAs(f"{unitLength}^4"))
                else:
                    J = Iy + Iz

                logger.info(f"DEBUG SECTION [{section.Name}]: Area = {A} {unitLength}²")
                logger.info(f"DEBUG SECTION [{section.Name}]: Iy = {Iy_mm4:.2e} mm⁴ = {Iy:.6e} {unitLength}⁴")
                logger.info(f"DEBUG SECTION [{section.Name}]: Iz = {Iz_mm4:.2e} mm⁴ = {Iz:.6e} {unitLength}⁴")

                # Validate section properties
                if A <= 0:
                    raise ValueError(f"Section '{section.Name}' has invalid area: {A} (must be > 0)")
                if Iy < 0:
                    raise ValueError(f"Section '{section.Name}' has invalid moment of inertia Iy: {Iy} (must be >= 0)")
                if Iz < 0:
                    raise ValueError(f"Section '{section.Name}' has invalid moment of inertia Iz: {Iz} (must be >= 0)")
                if J < 0:
                    raise ValueError(f"Section '{section.Name}' has invalid torsion constant J: {J} (must be >= 0)")

                ang = 0
                if hasattr(line, 'RotationSection'):
                    ang = float(line.RotationSection.getValueAs('rad'))
                
                Iyz = 0
                if hasattr(section, 'ProductInertiaYZ'):
                    Iyz = float(App.Units.Quantity(section.ProductInertiaYZ, 'mm^4').getValueAs(f"{unitLength}^4"))
                elif hasattr(section, 'ProductInertia'):
                    Iyz = float(App.Units.Quantity(section.ProductInertia, 'mm^4').getValueAs(f"{unitLength}^4"))
                
                if abs(ang) > 1e-6:
                    RIy = ((Iz + Iy) / 2) - ((Iz - Iy) / 2) * math.cos(2 * ang) + Iyz * math.sin(2 * ang)
                    RIz = ((Iz + Iy) / 2) + ((Iz - Iy) / 2) * math.cos(2 * ang) - Iyz * math.sin(2 * ang)
                else:
                    RIy = Iy
                    RIz = Iz

                # PyNite coordinate system (NO SWAP NEEDED - original was correct!)
                # Load in FY direction → deflection dz → bending Mz → uses Iz
                # FreeCAD: Iy=minor (4.94e-7), Iz=major (6.42e-6)
                # PyNite Iz parameter controls FY→dz bending → needs the LARGE value
                model.add_section(section.Name, A, RIy, RIz, J)  # ORIGINAL: Iy goes to Iy, Iz goes to Iz

                logger.info(f"DEBUG SECTION [{section.Name}]: PyNite receives: A={A:.6e}, Iy={RIy:.6e}, Iz={RIz:.6e} (Iz should be LARGER for vertical loads)")
                sections_added.append(section.Name)
        
        return model
    
    def setSupports(self, model, supports, nodes_map, unitLength):
        """Add supports to solver model."""
        tol = 1e-2

        def _mm_to_len(val_mm):
            return float(App.Units.Quantity(val_mm, "mm").getValueAs(unitLength))

        for support in supports:
            loc = None

            if hasattr(support, "AnchorPoint"):
                ap = support.AnchorPoint
                try:
                    if ap and (abs(ap.x) + abs(ap.y) + abs(ap.z)) > 0:
                        loc = [_mm_to_len(ap.x), _mm_to_len(ap.z), _mm_to_len(ap.y)]
                except Exception:
                    loc = None

            if loc is None and hasattr(support, "ObjectBase") and support.ObjectBase:
                try:
                    obj_base = support.ObjectBase

                    # ObjectBase is typically a list of tuples: [(object, (subname,))]
                    # Extract the first element if it's a list
                    if isinstance(obj_base, list) and len(obj_base) > 0:
                        obj_base = obj_base[0]

                    # Now handle tuple (object, subnames) or single object
                    if isinstance(obj_base, (tuple, list)) and len(obj_base) == 2:
                        base_obj, sub_names = obj_base
                    elif isinstance(obj_base, (tuple, list)) and len(obj_base) == 1:
                        base_obj = obj_base[0]
                        sub_names = []
                    else:
                        base_obj = obj_base
                        sub_names = []

                    sub_name = None
                    if isinstance(sub_names, (list, tuple)) and len(sub_names) > 0:
                        sub_name = sub_names[0]

                    if sub_name and "Vertex" in sub_name and hasattr(base_obj, "Shape"):
                        idx = int(sub_name.replace("Vertex", "")) - 1
                        verts = getattr(base_obj.Shape, "Vertexes", [])
                        if 0 <= idx < len(verts):
                            vtx = verts[idx].Point
                            loc = [_mm_to_len(vtx.x), _mm_to_len(vtx.z), _mm_to_len(vtx.y)]
                            logger.info(f"calc: mapped support '{support.Name}' from ObjectBase Vertex{idx+1}")

                    # Handle edge-based supports (Support_Edge with Distance property)
                    elif sub_name and "Edge" in sub_name and hasattr(base_obj, "Shape"):
                        try:
                            idx = int(sub_name.replace("Edge", "")) - 1
                            edges = getattr(base_obj.Shape, "Edges", [])
                            if 0 <= idx < len(edges):
                                edge = edges[idx]
                                # Get distance along edge (default to midpoint if no Distance property)
                                distance_mm = 0.0
                                if hasattr(support, "Distance"):
                                    distance_mm = float(support.Distance.getValueAs("mm"))
                                else:
                                    # Default to midpoint of edge
                                    distance_mm = edge.Length / 2.0

                                # Calculate point on edge
                                start = edge.Vertexes[0].Point
                                end = edge.Vertexes[1].Point
                                direction = end.sub(start)
                                length = direction.Length

                                if length > 1e-6:
                                    distance_mm = max(0.0, min(distance_mm, length))
                                    t = distance_mm / length
                                    point = start.add(direction.multiply(t))

                                    loc = [_mm_to_len(point.x), _mm_to_len(point.z), _mm_to_len(point.y)]
                                    logger.info(f"calc: mapped support '{support.Name}' from ObjectBase Edge{idx+1} at distance {distance_mm:.1f}mm")
                        except Exception as edge_exc:
                            logger.warn(f"calc: failed to parse Edge for support '{support.Name}': {edge_exc}")

                except Exception as exc:
                    logger.exception(f"calc: failed to parse ObjectBase for support '{support.Name}': {exc}")

            if loc is None and hasattr(support, "NodeLocation"):
                nl = support.NodeLocation
                try:
                    if nl and (abs(nl.x) + abs(nl.y) + abs(nl.z)) > 0:
                        loc = [_mm_to_len(nl.x), _mm_to_len(nl.z), _mm_to_len(nl.y)]
                except Exception:
                    loc = None

            if loc is None:
                logger.error(f"calc: could not determine location for support '{support.Name}'")
                continue

            node_idx = None
            min_dist = float("inf")
            closest_idx = None
            for i, node in enumerate(nodes_map):
                dist = math.sqrt((loc[0] - node[0]) ** 2 + (loc[1] - node[1]) ** 2 + (loc[2] - node[2]) ** 2)
                if dist < min_dist:
                    min_dist = dist
                    closest_idx = i
                if dist <= tol:
                    node_idx = i
                    break

            if node_idx is None:
                # No node within tolerance, use closest node as fallback
                if closest_idx is not None:
                    node_idx = closest_idx
                    logger.warn(f"calc: no node within tolerance for support '{support.Name}' at {loc}, using closest node {closest_idx} at distance {min_dist:.3f}")
                else:
                    logger.error(f"calc: no node found for support '{support.Name}' at {loc}")
                    continue

            # CRITICAL FIX: Read rotation fixities (they were defaulting to False!)
            # FreeCAD coordinate system: X, Y, Z
            # PyNite coordinate system: X, Y, Z (but Y/Z swapped relative to FreeCAD)
            fx = getattr(support, "FixTranslationX", True)
            fy = getattr(support, "FixTranslationY", True)
            fz = getattr(support, "FixTranslationZ", True)
            rx = getattr(support, "FixRotationX", True)  # FIXED: was False
            ry = getattr(support, "FixRotationY", True)  # FIXED: was False
            rz = getattr(support, "FixRotationZ", True)  # FIXED: was False

            # DEBUG: Log what we're actually sending to PyNite
            logger.info(f"DEBUG SUPPORT [{support.Name}] -> node {node_idx}:")
            logger.info(f"  FreeCAD properties: FixX={fx}, FixY={fy}, FixZ={fz}, RotX={rx}, RotY={ry}, RotZ={rz}")

            # PyNite expects: (node, DX, DY, DZ, RX, RY, RZ)
            # With coordinate swap: DX=fx, DY=fz, DZ=fy, RX=rx, RY=rz, RZ=ry
            model.def_support(str(node_idx), fx, fz, fy, rx, rz, ry)
            logger.info(f"  PyNite call: def_support(node={node_idx}, DX={fx}, DY={fz}, DZ={fy}, RX={rx}, RY={rz}, RZ={ry})")

        return model

    def applySelfWeight(self, model, lines, members_map, unitForce, unitLength):
        """Calculate and apply self-weight loads to all members.

        Self-weight = Area × Density × Gravity
        Applied as distributed load in -Z direction (downward).
        """
        logger.info(f"calc: applying self-weight to model (members={len(members_map)})")
        try:
            # Use PyNite's built-in self-weight based on member material rho and section area.
            # Our material density is already converted to force density (unitForce/unitLength^3).
            # Use default load case to match other loads when no combos are defined
            model.add_member_self_weight('FY', -1, case='Case 1')
            logger.info("calc: self-weight applied via model.add_member_self_weight (FY, -1, Case 1)")
        except Exception as exc:
            logger.warning(f"calc: failed to apply self-weight via PyNite: {exc}")
        return model

    def setLoads(self, model, loads, nodes_map, unitForce, unitLength, members_map=None):
        """Add loads to solver model."""
        def _len_mm_to_unit(val_mm):
            return float(App.Units.Quantity(val_mm, 'mm').getValueAs(unitLength))

        def _force_to_unit(force_val):
            """Convert force to unit system."""
            if hasattr(force_val, 'getValueAs'):
                return float(force_val.getValueAs(unitForce))
            return float(force_val)

        def _force_per_length_to_unit(force_val, load_name="unknown"):
            """Convert PropertyForce (stored as force in N) to force/length for distributed loads.

            The PropertyForce stores force in N. We need to interpret this as kN/m.
            Since the property value represents the UDL intensity:
            - User enters 10 expecting 10 kN/m
            - FreeCAD stores as 10000 N (PropertyForce converts kN→N)
            - We need: 10 kN/m for solver

            Conversion: N → kN/m = (N / 1000) / (mm / 1000) = N / mm (numerically equal!)
            Then convert from N/mm to target unitForce/unitLength.
            """
            if hasattr(force_val, 'getValueAs'):
                # Get value in N (base unit)
                force_n = float(force_val.getValueAs('N'))
                logger.info(f"DEBUG [{load_name}]: Raw property value = {force_n} N")

                # Interpret as kN/m: N → kN/m requires ÷1000
                force_kn_per_m = force_n / 1000.0
                logger.info(f"DEBUG [{load_name}]: Converted to kN/m = {force_kn_per_m} kN/m")

                # Now convert to target unit system
                udl_quantity = App.Units.Quantity(force_kn_per_m, 'kN/m')
                final_value = float(udl_quantity.getValueAs(f'{unitForce}/{unitLength}'))
                logger.info(f"DEBUG [{load_name}]: Final solver value = {final_value} {unitForce}/{unitLength}")

                # Warn if suspiciously large (old load)
                if force_n > 100000:
                    logger.warning(f"⚠️  [{load_name}]: VERY LARGE VALUE ({force_n} N) - likely an OLD LOAD! Results will be wrong!")
                    logger.warning(f"⚠️  [{load_name}]: DELETE this load and create a new one with correct value")

                return final_value
            return float(force_val)

        def get_axis_and_direction(global_dir):
            """Convert global direction string to PyNite axis and sign."""
            direction_map = {
                '+X': ('FX', 1), '-X': ('FX', -1),
                '+Y': ('FZ', 1), '-Y': ('FZ', -1),  # Y/Z swap for solver
                '+Z': ('FY', 1), '-Z': ('FY', -1),
            }
            return direction_map.get(global_dir, (None, 1))

        for load in loads:
            # Handle ObjectBase-based loads (loads created directly on geometry)
            if hasattr(load, 'ObjectBase') and load.ObjectBase and not hasattr(load, 'Member'):
                try:
                    base_obj, sub_names = load.ObjectBase[0]
                    sub_name = sub_names[0] if sub_names else None

                    if sub_name and 'Edge' in sub_name:
                        # Distributed or point load on an edge
                        edge_idx = int(sub_name.split('Edge')[1]) - 1
                        element_name = base_obj.Name

                        # Distributed load
                        if hasattr(load, 'InitialLoading') and hasattr(load, 'FinalLoading'):
                            logger.info(f"DEBUG: Processing distributed load '{load.Label}'")
                            w1 = _force_per_length_to_unit(load.InitialLoading, f"{load.Label} InitialLoading")
                            w2 = _force_per_length_to_unit(load.FinalLoading, f"{load.Label} FinalLoading")

                            axis, sign = get_axis_and_direction(load.GlobalDirection)
                            logger.info(f"DEBUG [{load.Label}]: Direction={load.GlobalDirection} → axis={axis}, sign={sign}")
                            if axis:
                                w1 *= sign
                                w2 *= sign
                                logger.info(f"DEBUG [{load.Label}]: After applying direction: w1={w1}, w2={w2} {unitForce}/{unitLength}")

                                # Apply to all segment members of this edge
                                applied_count = 0
                                # Use members_map if provided, otherwise fall back to model.Members
                                member_names = list(model.Members.keys()) if hasattr(model, 'Members') and hasattr(model.Members, 'keys') else (members_map.keys() if members_map else [])
                                for member_name in member_names:
                                    if member_name.startswith(f"{element_name}_e{edge_idx}_s"):
                                        logger.info(f"DEBUG [{load.Label}]: Applying load to member '{member_name}': w1={w1}, w2={w2} {unitForce}/{unitLength}")
                                        model.add_member_dist_load(member_name, axis, w1, w2, 0, None)
                                        applied_count += 1

                                if applied_count > 0:
                                    logger.info(f"✅ calc: applied distributed load ({w1:.3f} to {w2:.3f} {unitForce}/{unitLength}) to {applied_count} segments on {element_name}_e{edge_idx}")
                                else:
                                    logger.warning(f"calc: no members found for distributed load on {element_name}_e{edge_idx}")

                        # Point load on edge
                        elif hasattr(load, 'PointLoading'):
                            logger.info(f"DEBUG: Processing point load '{load.Label}'")
                            force_raw = float(load.PointLoading.getValueAs('N')) if hasattr(load.PointLoading, 'getValueAs') else float(load.PointLoading)
                            logger.info(f"DEBUG [{load.Label}]: Raw property value = {force_raw} N")

                            force = _force_to_unit(load.PointLoading)
                            logger.info(f"DEBUG [{load.Label}]: Converted to {force} {unitForce}")

                            axis, sign = get_axis_and_direction(load.GlobalDirection)
                            logger.info(f"DEBUG [{load.Label}]: Direction={load.GlobalDirection} → axis={axis}, sign={sign}")
                            if axis:
                                force *= sign
                                distance_mm = float(load.Distance.getValueAs('mm')) if hasattr(load, 'Distance') else 0.0
                                logger.info(f"DEBUG [{load.Label}]: Distance={distance_mm} mm, Final force={force} {unitForce}")

                                # Get edge and calculate relative position along entire edge
                                edge = base_obj.Shape.Edges[edge_idx]
                                edge_length_mm = edge.Length

                                if edge_length_mm > 0:
                                    rel_pos_global = distance_mm / edge_length_mm  # Position along entire edge (0 to 1)
                                    logger.info(f"DEBUG [{load.Label}]: Edge length={edge_length_mm} mm, Global position={rel_pos_global:.3f}")

                                    # Find all segment members for this edge
                                    member_names = list(model.Members.keys()) if hasattr(model, 'Members') and hasattr(model.Members, 'keys') else (members_map.keys() if members_map else [])
                                    # Sort numerically by segment number, not alphabetically
                                    segment_members = sorted(
                                        [name for name in member_names if name.startswith(f"{element_name}_e{edge_idx}_s")],
                                        key=lambda x: int(x.split('_s')[1])
                                    )

                                    if not segment_members:
                                        logger.warning(f"calc: no segment members found for point load on {element_name}_e{edge_idx}")
                                        continue

                                    num_segments = len(segment_members)
                                    # Determine which segment contains this point
                                    segment_idx = int(rel_pos_global * num_segments)
                                    if segment_idx >= num_segments:
                                        segment_idx = num_segments - 1  # Clamp to last segment

                                    # Calculate relative position within that segment
                                    segment_start = segment_idx / num_segments
                                    segment_end = (segment_idx + 1) / num_segments
                                    rel_pos_in_segment = (rel_pos_global - segment_start) / (segment_end - segment_start)

                                    logger.info(f"DEBUG [{load.Label}]: Applying to segment {segment_idx}/{num_segments}, position in segment={rel_pos_in_segment:.3f}")

                                    # Apply to the correct segment
                                    target_member = segment_members[segment_idx]
                                    model.add_member_pt_load(target_member, axis, force, rel_pos_in_segment)
                                    logger.info(f"✅ calc: applied point load ({force:.3f} {unitForce}) to {target_member} at position {rel_pos_in_segment:.3f} (global position {rel_pos_global:.3f})")

                        continue
                except Exception as e:
                    logger.error(f"calc: failed to process ObjectBase load '{load.Name}': {e}")
                    import traceback
                    traceback.print_exc()
                    continue

            # Original Member-based load handling
            if hasattr(load, 'Member') and getattr(load, 'Member', None):
                member_name = load.Member.Name
                start = _len_mm_to_unit(getattr(load, "StartPosition", 0.0))
                end = _len_mm_to_unit(getattr(load, "EndPosition", 0.0))

                if hasattr(load, 'LoadMagnitudeX') or hasattr(load, 'LoadMagnitudeY') or hasattr(load, 'LoadMagnitudeZ'):
                    fx = float(getattr(load, "LoadMagnitudeX", 0.0))
                    fy = float(getattr(load, "LoadMagnitudeY", 0.0))
                    fz = float(getattr(load, "LoadMagnitudeZ", 0.0))
                    if fx != 0.0:
                        model.add_member_dist_load(member_name, 'FX', fx, fx, start, end)
                    if fy != 0.0:
                        model.add_member_dist_load(member_name, 'FZ', fy, fy, start, end)
                    if fz != 0.0:
                        model.add_member_dist_load(member_name, 'FY', fz, fz, start, end)
                    continue

                if hasattr(load, "GlobalDirection") and hasattr(load, "Magnitude"):
                    axis, sign = get_axis_and_direction(load.GlobalDirection)
                    if axis:
                        mag = float(getattr(load, "Magnitude", 0.0)) * sign
                        model.add_member_dist_load(member_name, axis, mag, mag, start, end)
                    continue

            if hasattr(load, "Member") and getattr(load, "Member", None) and hasattr(load, "Position"):
                member_name = load.Member.Name
                pos = _len_mm_to_unit(getattr(load, "Position", 0.0))
                fx = float(getattr(load, "ForceX", 0.0))
                fy = float(getattr(load, "ForceY", 0.0))
                fz = float(getattr(load, "ForceZ", 0.0))
                if fx != 0.0:
                    model.add_member_pt_load(member_name, 'FX', fx, pos)
                if fy != 0.0:
                    model.add_member_pt_load(member_name, 'FZ', fy, pos)
                if fz != 0.0:
                    model.add_member_pt_load(member_name, 'FY', fz, pos)
                continue

            if hasattr(load, 'NodeLocation'):
                loc = getattr(load, 'NodeLocation', None)
                if loc:
                    target = [
                        _len_mm_to_unit(loc.x),
                        _len_mm_to_unit(loc.z),
                        _len_mm_to_unit(loc.y),
                    ]

                    node_idx = None
                    for i, n in enumerate(nodes_map):
                        if abs(n[0] - target[0]) < 1e-4 and abs(n[1] - target[1]) < 1e-4 and abs(n[2] - target[2]) < 1e-4:
                            node_idx = i
                            break

                    if node_idx is not None:
                        if getattr(load, "ForceX", 0.0) != 0.0:
                            model.add_node_load(str(node_idx), 'FX', load.ForceX)
                        if getattr(load, "ForceY", 0.0) != 0.0:
                            model.add_node_load(str(node_idx), 'FZ', load.ForceY)
                        if getattr(load, "ForceZ", 0.0) != 0.0:
                            model.add_node_load(str(node_idx), 'FY', load.ForceZ)

        return model
    
    # =========================================================
    # EXECUTE ANALYSIS
    # =========================================================
    
    def execute(self, obj):
        """Run the structural analysis."""
        # Guard against re-entrant execution (prevents dialog appearing twice)
        if self._executing:
            import logging
            logger = logging.getLogger(__name__)
            logger.info("calc: already executing, skipping duplicate call")
            return

        self._executing = True
        try:
            return self._do_execute(obj)
        except Exception as e:
            import logging
            import traceback
            logger = logging.getLogger(__name__)
            logger.error(f"calc: EXCEPTION in execute(): {e}")
            logger.error(f"calc: Traceback:\n{traceback.format_exc()}")
            raise  # Re-raise so FreeCAD shows error dialog
        finally:
            self._executing = False

    def _do_execute(self, obj):
        """Internal execute implementation."""
        if FEModel3D is None:
            show_error_message("PyNite solver not available. Check Pynite_main folder.")
            return

        model = FEModel3D()
        
        # Filter elements by type
        lines = [e for e in obj.ListElements if 'Line' in e.Name or 'Wire' in e.Name or hasattr(e, 'SectionMember')]
        loads = [e for e in obj.ListElements if 'Load' in e.Name or hasattr(e, 'ForceZ')]
        supports = [e for e in obj.ListElements if 'Support' in e.Name or 'Suport' in e.Name or hasattr(e, 'FixTranslationX')]
        
        # Validation
        if not lines:
            show_error_message("No structural members found in selection.")
            return
        
        missing = [ln.Name for ln in lines if not getattr(ln, 'MaterialMember', None) or not getattr(ln, 'SectionMember', None)]
        if missing:
            show_error_message(f"Members missing material or section:\n{', '.join(missing)}")
            return
        
        if not supports:
            show_error_message("No supports defined. Add at least one support.")
            return
        
        if not loads and not obj.SelfWeight:
            show_error_message("No loads defined. Please add distributed or point loads.")
            return

        # AUTO-MIGRATE OLD LOADS: Fix loads created before unit system fix
        logger.info("calc: checking for old loads that need migration...")
        migrated_count = 0
        for load in loads:
            if hasattr(load, 'InitialLoading') and hasattr(load, 'FinalLoading'):
                # Distributed load - check if value is suspiciously large
                initial_n = float(load.InitialLoading.getValueAs('N')) if hasattr(load.InitialLoading, 'getValueAs') else float(load.InitialLoading)
                final_n = float(load.FinalLoading.getValueAs('N')) if hasattr(load.FinalLoading, 'getValueAs') else float(load.FinalLoading)

                # OLD SYSTEM: Values like 3000000 N (meant to be 3 kN/m)
                # NEW SYSTEM: Values like 3000 N (representing 3 kN/m)
                # Threshold: if > 100000 N, it's likely old
                if initial_n > 100000 or final_n > 100000:
                    # Calculate correct new value: old_value / 1000
                    # Old: 3000000 N → New: 3000 N (both represent 3 kN/m after conversion)
                    new_initial = initial_n / 1000.0
                    new_final = final_n / 1000.0

                    logger.warning(f"⚠️  AUTO-MIGRATE: '{load.Label}' has OLD load values")
                    logger.warning(f"    Old: {initial_n} N → New: {new_initial} N (÷1000)")
                    logger.warning(f"    This represents {new_initial/1000:.1f} kN/m distributed load")

                    # Update the property values
                    load.InitialLoading = new_initial
                    load.FinalLoading = new_final
                    migrated_count += 1

                    logger.info(f"✅ AUTO-MIGRATED: '{load.Label}' corrected to {new_initial} N")

            elif hasattr(load, 'PointLoading'):
                # Point load - typically these are OK but check anyway
                force_n = float(load.PointLoading.getValueAs('N')) if hasattr(load.PointLoading, 'getValueAs') else float(load.PointLoading)

                # For point loads, very large values might also be old (though less common)
                # Threshold: if > 1000000 N (1000 kN), probably old
                if force_n > 1000000:
                    new_force = force_n / 1000.0
                    logger.warning(f"⚠️  AUTO-MIGRATE: Point load '{load.Label}' has OLD value")
                    logger.warning(f"    Old: {force_n} N → New: {new_force} N (÷1000)")
                    load.PointLoading = new_force
                    migrated_count += 1
                    logger.info(f"✅ AUTO-MIGRATED: Point load '{load.Label}' corrected to {new_force} N")

        if migrated_count > 0:
            logger.info(f"✅ AUTO-MIGRATION COMPLETE: Fixed {migrated_count} old load(s)")
            logger.info(f"   Your load values have been automatically corrected for the new unit system")
            App.ActiveDocument.recompute()
        else:
            logger.info("✅ No old loads detected - all loads are using correct values")

        # Show simple analysis review dialog
        review_dialog = SimpleReviewDialog(obj)
        if review_dialog.exec_() != QtWidgets.QDialog.Accepted:
            logger.info("calc: analysis cancelled by user")
            return

        # Log self-weight status
        selfweight_status = "ENABLED" if obj.SelfWeight else "disabled"
        logger.info(f"calc: user confirmed analysis (self-weight: {selfweight_status})")

        # Build model with segmentation
        segments = obj.SegmentsPerMember
        logger.info(f"calc: building model with {segments} segments per member")

        # Extract support locations for mesh refinement if enabled
        support_locs = None
        if obj.RefineAtSupports:
            support_locs = self.extract_support_locations(supports, obj.LengthUnit)

        nodes_map = self.mapNodes(lines, obj.LengthUnit, segments, obj.NodeTolerance, support_locs)
        members_map = self.mapMembers(lines, nodes_map, obj.LengthUnit, segments, obj.NodeTolerance)

        try:
            model = self.setMaterialAndSections(model, lines, obj.LengthUnit, obj.ForceUnit)
            model = self.setNodes(model, nodes_map)
            model = self.setMembers(model, members_map)

            # Apply self-weight if enabled
            if obj.SelfWeight:
                model = self.applySelfWeight(model, lines, members_map, obj.ForceUnit, obj.LengthUnit)
                logger.info("calc: self-weight loads applied")
            else:
                logger.info("calc: self-weight disabled")

            model = self.setLoads(model, loads, nodes_map, obj.ForceUnit, obj.LengthUnit, members_map)
            model = self.setSupports(model, supports, nodes_map, obj.LengthUnit)

            logger.info("calc: running analysis...")

            # DEBUG: Verify PyNite model properties before analysis
            logger.info("=" * 80)
            logger.info("DEBUG: PYNITE MODEL VERIFICATION (what solver will use)")
            logger.info("=" * 80)

            # Check members in PyNite
            if hasattr(model, 'members') and model.members:
                sample_member_name = list(model.members.keys())[0]
                sample_member = model.members[sample_member_name]
                logger.info(f"DEBUG PYNITE MEMBER [{sample_member_name}]:")
                logger.info(f"  Length: {sample_member.L():.6f} m")

                # Get E from material
                if hasattr(sample_member, 'mat') and sample_member.mat:
                    mat = model.materials[sample_member.mat]
                    logger.info(f"  Material: {sample_member.mat}")
                    logger.info(f"  E (Young's modulus): {mat.E:.3e} kN/m² (should be ~210e6)")
                    logger.info(f"  G (Shear modulus): {mat.G:.3e} kN/m²")
                    logger.info(f"  rho (density): {mat.rho:.3f} kN/m³")

                # Get section properties
                if hasattr(sample_member, 'sect') and sample_member.sect:
                    sec = model.sections[sample_member.sect]
                    logger.info(f"  Section: {sample_member.sect}")
                    logger.info(f"  A (area): {sec.A:.6e} m²")
                    logger.info(f"  Iy: {sec.Iy:.6e} m⁴")
                    logger.info(f"  Iz: {sec.Iz:.6e} m⁴")
                    logger.info(f"  J: {sec.J:.6e} m⁴")

                # Check if member has distributed loads
                if hasattr(sample_member, 'DistLoads') and sample_member.DistLoads:
                    for dl in sample_member.DistLoads:
                        # PyNite stores as tuple: (Direction, w1, w2, x1, x2, Case)
                        logger.info(f"  Distributed Load: direction={dl[0]}, w1={dl[1]:.3f}, w2={dl[2]:.3f} kN/m")

                # Check if member has point loads
                if hasattr(sample_member, 'PtLoads') and sample_member.PtLoads:
                    for pl in sample_member.PtLoads:
                        # PyNite stores as tuple: (Direction, P, x, Case)
                        logger.info(f"  Point Load: direction={pl[0]}, P={pl[1]:.3f} kN at x={pl[2]:.3f} m")

            # DEBUG: Verify node support conditions in PyNite
            logger.info("=" * 80)
            logger.info("DEBUG: PYNITE NODE SUPPORTS VERIFICATION")
            logger.info("=" * 80)
            if hasattr(model, 'nodes') and model.nodes:
                # Check first and last nodes (should be the supports)
                for node_key in ['0', '1']:
                    if node_key in model.nodes:
                        node = model.nodes[node_key]
                        logger.info(f"DEBUG NODE [{node_key}]:")
                        logger.info(f"  Position: X={node.X:.3f}, Y={node.Y:.3f}, Z={node.Z:.3f}")
                        logger.info(f"  Supports: DX={node.support_DX}, DY={node.support_DY}, DZ={node.support_DZ}")
                        logger.info(f"  Rotations: RX={node.support_RX}, RY={node.support_RY}, RZ={node.support_RZ}")
            logger.info("=" * 80)

            model.analyze()
            logger.info("calc: analysis complete")
        
        except Exception as exc:
            show_error_message(f"Solver error:\n{exc}")
            logger.exception(f"calc: solver failure: {exc}")
            return
        
        # Extract results
        self._extract_results(obj, model, nodes_map, obj.LengthUnit, obj.ForceUnit)
        
        show_success_message(f"Analysis completed successfully!\n\n"
                            f"Original members: {len(lines)}\n"
                            f"Segments per member: {segments}\n"
                            f"Total elements: {len(model.members)}\n"
                            f"Nodes: {len(nodes_map)}\n"
                            f"Supports: {len(supports)}\n"
                            f"Loads: {len(loads)}")
    
    def _extract_results(self, obj, model, nodes_map, unitLength, unitForce):
        """Extract results from solved model.

        Args:
            obj: The calc object to store results in
            model: The solved PyNite model
            nodes_map: List of node coordinates
            unitLength: Length unit string (e.g., 'm', 'mm') for deflection scaling
            unitForce: Force unit string (e.g., 'kN', 'N') for logging
        """
        momenty = []
        momentz = []
        minMomenty = []
        minMomentz = []
        maxMomenty = []
        maxMomentz = []
        axial = []
        torque = []
        minTorque = []
        maxTorque = []
        sheary = []
        shearz = []
        minSheary = []
        maxSheary = []
        minShearz = []
        maxShearz = []
        deflectiony = []
        deflectionz = []
        minDeflectiony = []
        minDeflectionz = []
        maxDeflectiony = []
        maxDeflectionz = []
        
        logger.info(f"DEBUG RESULTS: Extracting results from {len(model.members)} members")

        for name in model.members.keys():
            member = model.members[name]

            # Moments
            xs, my = member.moment_array('My', obj.NumPointsMoment)
            xs_mz, mz = member.moment_array('Mz', obj.NumPointsMoment)
            momenty.append(','.join(str(v) for v in xs) + ';' + ','.join(str(v) for v in my))
            momentz.append(','.join(str(v) for v in xs_mz) + ';' + ','.join(str(v) for v in mz))
            min_my = member.min_moment('My')
            min_mz = member.min_moment('Mz')
            max_my = member.max_moment('My')
            max_mz = member.max_moment('Mz')
            minMomenty.append(min_my)
            minMomentz.append(min_mz)
            maxMomenty.append(max_my)
            maxMomentz.append(max_mz)
            logger.info(f"DEBUG RESULTS [{name}]: Moment My: min={min_my:.3f}, max={max_my:.3f} {unitForce}·{unitLength}")
            logger.info(f"DEBUG RESULTS [{name}]: Moment Mz: min={min_mz:.3f}, max={max_mz:.3f} {unitForce}·{unitLength}")

            # Shear
            xs_sy, sy = member.shear_array('Fy', obj.NumPointsShear)
            xs_sz, sz = member.shear_array('Fz', obj.NumPointsShear)
            sheary.append(','.join(str(v) for v in xs_sy) + ';' + ','.join(str(v) for v in sy))
            shearz.append(','.join(str(v) for v in xs_sz) + ';' + ','.join(str(v) for v in sz))
            min_sy = member.min_shear('Fy')
            min_sz = member.min_shear('Fz')
            max_sy = member.max_shear('Fy')
            max_sz = member.max_shear('Fz')
            minSheary.append(min_sy)
            minShearz.append(min_sz)
            maxSheary.append(max_sy)
            maxShearz.append(max_sz)
            logger.info(f"DEBUG RESULTS [{name}]: Shear Fy: min={min_sy:.3f}, max={max_sy:.3f} {unitForce}")
            logger.info(f"DEBUG RESULTS [{name}]: Shear Fz: min={min_sz:.3f}, max={max_sz:.3f} {unitForce}")
            
            # Axial
            xs_ax, ax = member.axial_array(obj.NumPointsAxial)
            axial.append(','.join(str(v) for v in xs_ax) + ';' + ','.join(str(v) for v in ax))
            
            # Torque
            xs_tq, tq = member.torque_array(obj.NumPointsTorque)
            torque.append(','.join(str(v) for v in xs_tq) + ';' + ','.join(str(v) for v in tq))
            minTorque.append(member.min_torque())
            maxTorque.append(member.max_torque())
            
            # Deflection
            # PyNite returns deflection in solver units (m for our m/kN system)
            # Convert to mm for display (user requirement: deflection in mm)
            deflection_scale = 1000.0 if unitLength == 'm' else 1.0

            xs_dy, dy = member.deflection_array('dy', obj.NumPointsDeflection)
            xs_dz, dz = member.deflection_array('dz', obj.NumPointsDeflection)

            # Scale deflections from m to mm
            dy_mm = [v * deflection_scale for v in dy]
            dz_mm = [v * deflection_scale for v in dz]

            deflectiony.append(','.join(str(v) for v in xs_dy) + ';' + ','.join(str(v) for v in dy_mm))
            deflectionz.append(','.join(str(v) for v in xs_dz) + ';' + ','.join(str(v) for v in dz_mm))

            min_dy_m = member.min_deflection('dy')
            min_dz_m = member.min_deflection('dz')
            max_dy_m = member.max_deflection('dy')
            max_dz_m = member.max_deflection('dz')

            min_dy_mm = min_dy_m * deflection_scale
            min_dz_mm = min_dz_m * deflection_scale
            max_dy_mm = max_dy_m * deflection_scale
            max_dz_mm = max_dz_m * deflection_scale

            minDeflectiony.append(min_dy_mm)
            minDeflectionz.append(min_dz_mm)
            maxDeflectiony.append(max_dy_mm)
            maxDeflectionz.append(max_dz_mm)

            logger.info(f"DEBUG RESULTS [{name}]: Deflection dy: raw={max_dy_m:.6f} {unitLength}, scaled={max_dy_mm:.3f} mm")
            logger.info(f"DEBUG RESULTS [{name}]: Deflection dz: raw={max_dz_m:.6f} {unitLength}, scaled={max_dz_mm:.3f} mm")
            logger.info(f"DEBUG RESULTS [{name}]: Scale factor={deflection_scale} (unitLength={unitLength})")
        
        # Store results
        obj.NameMembers = list(model.members.keys())

        # Convert nodes back to mm for diagram compatibility (nodes_map is in solver units = m)
        # Diagram code expects nodes in mm to match FreeCAD geometry
        node_scale = 1000.0 if unitLength == 'm' else 1.0
        obj.Nodes = [App.Vector(n[0] * node_scale, n[2] * node_scale, n[1] * node_scale) for n in nodes_map]

        logger.info(f"calc: extracted results for {len(model.members)} members")
        logger.info(f"calc: stored {len(nodes_map)} nodes")
        logger.info(f"calc: MomentY has {len(momenty)} entries, first entry: {momenty[0] if momenty else 'EMPTY'}")
        logger.info(f"calc: MomentZ has {len(momentz)} entries")

        obj.MomentY = momenty
        obj.MomentZ = momentz
        obj.MinMomentY = minMomenty
        obj.MinMomentZ = minMomentz
        obj.MaxMomentY = maxMomenty
        obj.MaxMomentZ = maxMomentz
        
        obj.AxialForce = axial
        obj.Torque = torque
        obj.MinTorque = minTorque
        obj.MaxTorque = maxTorque
        
        obj.ShearY = sheary
        obj.ShearZ = shearz
        obj.MinShearY = minSheary
        obj.MinShearZ = minShearz
        obj.MaxShearY = maxSheary
        obj.MaxShearZ = maxShearz
        
        obj.DeflectionY = deflectiony
        obj.DeflectionZ = deflectionz
        obj.MinDeflectionY = minDeflectiony
        obj.MinDeflectionZ = minDeflectionz
        obj.MaxDeflectionY = maxDeflectiony
        obj.MaxDeflectionZ = maxDeflectionz


# ============================================================
# VIEW PROVIDER
# ============================================================

class ViewProviderCalc:
    """View provider for Calc objects."""
    
    def __init__(self, vobj):
        vobj.Proxy = self
    
    def attach(self, vobj):
        self.Object = vobj.Object
    
    def getIcon(self):
        icon_path = os.path.join(ICONPATH, "icons", "calc.svg")
        if os.path.exists(icon_path):
            return icon_path
        return ""
    
    def __getstate__(self):
        return None
    
    def __setstate__(self, state):
        return None


# ============================================================
# COMMAND CLASS WITH GUI
# ============================================================

class CommandCalc:
    """FreeCAD command for running structural analysis with segmentation GUI."""
    
    def GetResources(self):
        icon_path = os.path.join(ICONPATH, "icons", "calc.svg")
        return {
            "Pixmap": icon_path if os.path.exists(icon_path) else "",
            "Accel": "Shift+C",
            "MenuText": "Run Analysis",
            "ToolTip": "Run structural analysis with accuracy control"
        }
    
    def Activated(self):
        """Execute the command with GUI."""
        selection = Gui.Selection.getSelection()
        
        if not selection:
            show_error_message("Please select structural elements (members, loads, supports).")
            return
        
        # Count members
        lines = [e for e in selection if 'Line' in e.Name or 'Wire' in e.Name or hasattr(e, 'SectionMember')]
        
        if not lines:
            show_error_message("No structural members found in selection.")
            return
        
        num_members = sum(len(line.Shape.Edges) if hasattr(line, 'Shape') else 1 for line in lines)
        
        # Show segmentation dialog
        dialog = SegmentationDialog(num_members)
        
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            settings = dialog.get_values()

            # DEBUG: Log what dialog returned
            logger.info(f"DEBUG: dialog.get_values() returned: {settings}")
            logger.info(f"DEBUG: settings['selfweight'] = {settings['selfweight']}")

            # Create calc object with chosen settings (selfweight passed to constructor)
            doc = App.ActiveDocument
            obj = doc.addObject("Part::FeaturePython", "Calc")
            Calc(obj, selection,
                 segments_per_member=settings['segments'],
                 refine_at_supports=settings['refine_at_supports'],
                 selfweight_enabled=settings['selfweight'])  # CRITICAL FIX: Pass to constructor
            ViewProviderCalc(obj.ViewObject)

            # Verify property was set correctly during construction
            logger.info(f"DEBUG: obj.SelfWeight after construction = {obj.SelfWeight}")
            logger.info(f"DEBUG: settings['selfweight'] was = {settings['selfweight']}")

            refine_msg = " with automatic mesh refinement at supports" if settings['refine_at_supports'] else ""
            selfweight_msg = " (self-weight ENABLED)" if settings['selfweight'] else " (self-weight disabled)"
            logger.info(f"calc: starting analysis with {settings['segments']} segments per member{refine_msg}{selfweight_msg}")

            doc.recompute()
        else:
            logger.info("calc: analysis cancelled by user")
    
    def IsActive(self):
        """Command is active if there's a document."""
        return App.ActiveDocument is not None


# Register command
Gui.addCommand("calc", CommandCalc())
