import FreeCAD, FreeCADGui, Part, math, os
from PySide import QtWidgets

ICONPATH = os.path.join(os.path.dirname(__file__), "resources")
pathFont = os.path.join(os.path.dirname(__file__), "resources/fonts/ARIAL.TTF")
# pathFont = os.path.join(os.path.dirname(__file__), "ARIAL.TTF")

def show_error_message(msg):
	msg_box = QtWidgets.QMessageBox()
	msg_box.setIcon(QtWidgets.QMessageBox.Critical)  #Ícone de erro
	msg_box.setWindowTitle("Error")
	msg_box.setText(msg)
	msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
	msg_box.exec_()

class Diagram:
	def __init__(self, obj, objCalc, listSelection):
		obj.Proxy = self
		self.ensure_properties(obj)
		if objCalc:
			obj.ObjectBaseCalc = objCalc
		if listSelection is None:
			listSelection = []
		obj.ObjectBaseElements = self.getMembers(listSelection)

	# Pega os membros que deverão se plotados os seus diagramas
	def getMembers(self, listSelection):
		listMembers = []

		if listSelection != []: # Caso exista selecção de membros
			for selection in listSelection:
				member = (selection.Object, selection.SubElementNames)
				listMembers.append(member)
		
		else: #Caso não exista seleção de membros todos eles serão selecionados automaticamente
			objects = FreeCAD.ActiveDocument.Objects
			lines = list(filter(lambda object: 'Wire' in object.Name or 'Line' in object.Name, objects))
			members = list(filter(lambda line: 'MaterialMember' in line.PropertiesList, lines))

			for member in members:
				listSubObjects = [f'Edge{i+1}' for i in range(len(member.Shape.Edges))]
				listMembers.append((member, listSubObjects))
		
		return listMembers

	# Gera uma matriz baseado em umdos parâmetros do calc
	def getMatrix(self, param, is_restoring=False):
		"""Parse result strings with validation.

		Args:
			param: List of result strings to parse
			is_restoring: True if document is being restored (suppresses error dialogs)

		Expected format: "x1,x2,x3;y1,y2,y3"
		- First part (before ;): X positions along member
		- Second part (after ;): Force/moment/deflection values
		"""
		matriz = []

		for idx, linha in enumerate(param):
			try:
				# Validate for NaN or Inf values
				linha_lower = linha.lower()
				if 'nan' in linha_lower or 'inf' in linha_lower:
					print(f"diagram: ERROR - Invalid numeric values in result string {idx}: {linha[:50]}...")
					if not is_restoring:
						from .ui_helpers import show_error_message
						show_error_message(
						f"Analysis results contain invalid values!\n\n"
						f"Result {idx}: {linha[:50]}...\n\n"
						f"This usually means:\n"
						f"• Analysis failed (singular matrix)\n"
						f"• Structure is unstable\n"
						f"• Missing or insufficient supports\n"
						f"• Check console for 'Matrix is singular' warning\n\n"
						f"Fix by:\n"
						f"• Adding more supports\n"
						f"• Ensuring supports prevent all rigid body motion\n"
						f"• Using at least 3 non-collinear supports"
					)
					return []  # Return empty, will create empty shape

				# Check for semicolon delimiter
				if ';' not in linha:
					print(f"diagram: WARNING - Missing semicolon delimiter in result string {idx}")
					print(f"  String: {linha[:50]}...")
					# Try to parse anyway (might be old format)
					lista = [float(value) for value in linha.split(',')]
					matriz.append(lista)
					continue

				# Split by semicolon
				parts = linha.split(';')

				# Validate format
				if len(parts) != 2:
					print(f"diagram: WARNING - Expected 2 parts (positions;values), got {len(parts)} in result {idx}")
					print(f"  String: {linha[:50]}...")
					# Use first part that looks like values
					if len(parts) >= 2:
						lista = [float(value) for value in parts[1].split(',')]
					else:
						lista = [float(value) for value in parts[0].split(',')]
					matriz.append(lista)
					continue

				# Parse values (second part after semicolon)
				value_string = parts[1]
				lista = [float(value) for value in value_string.split(',')]

				# Validate all values are finite
				for val in lista:
					if not (-1e308 < val < 1e308):  # Check for overflow/underflow
						raise ValueError(f"Value {val} is out of valid range")

				matriz.append(lista)

			except ValueError as e:
				print(f"diagram: ERROR - Failed to parse result string {idx}: {e}")
				print(f"  String: {linha[:80]}...")
				if not is_restoring:
					from .ui_helpers import show_error_message
					show_error_message(
						f"Failed to parse analysis results!\n\n"
						f"Error: {e}\n"
						f"Result string {idx}: {linha[:50]}...\n\n"
						f"This may indicate:\n"
						f"• Corrupted results data\n"
						f"• Analysis did not complete\n"
						f"• Incompatible result format\n\n"
						f"Try re-running the analysis."
					)
				return []  # Return empty on any parse error

			except Exception as e:
				print(f"diagram: UNEXPECTED ERROR parsing result string {idx}: {e}")
				import traceback
				traceback.print_exc()
				return []

		if not matriz:
			print(f"diagram: WARNING - getMatrix produced empty matrix from {len(param)} input strings")

		return matriz


	#  Mapeia os nós da estrutura
	def mapNodes(self, elements):	
		# Varre todos os elementos de linha e adiciona seus vertices à tabela de nodes
		listNodes = []
		for element in elements:
			for edge in element.Shape.Edges:
				for vertex in edge.Vertexes:
					node = [round(vertex.Point.x, 2), round(vertex.Point.y, 2), round(vertex.Point.z, 2)]
					if not node in listNodes:
						listNodes.append(node)

		return listNodes


	# Mapeia os membros da estrutura
	def mapMembers(self, elements, listNodes):
		listMembers = {}
		for element in elements:
			for i, edge in enumerate(element.Shape.Edges):
				listIndexVertex = []
				for vertex in edge.Vertexes:
					node = [round(vertex.Point.x, 2), round(vertex.Point.y, 2), round(vertex.Point.z, 2)]
					index = listNodes.index(node)
					listIndexVertex.append(index)
				# valida se o primeiro nó é mais auto do que o segundo nó, se sim inverte os nós do membro (necessário para manter os diagramas voltados para a posição correta)
				n1 = listIndexVertex[0]
				n2 = listIndexVertex[1]
				if listNodes[n1][2] > listNodes[n2][2]:
					aux = n1
					n1 = n2
					n2 = aux
				listMembers[element.Name + '_' + str(i)] = {
					'nodes': [str(n1), str(n2)],
					'RotationSection': element.RotationSection.getValueAs('rad')
				}
		
		return listMembers
	
	# separa as ordenadas em grupos de valores positivos e negativos
	def separatesOrdinates(self, values):
		loops = []
		loop = [values[0]]
		for i in range(1, len(values)):
			if values[i] * values[i-1] < 0 and abs(values[i]) > 1e-2: #valida  se o valor passa pelo eixo das abssisas comparado com o valor anterior
				loops.append(loop)
				loop = [values[i]]
			else:
				loop.append(values[i])
		
		loops.append(loop)
		
		return loops


	# Função que cria os pares de coordenadas e já cria os valores que cruzam o eixo das absissas
	def generateCoordinates(self, ordinates, dist):
		cont = 0
		loops = []
		loop = []
		for i in range(len(ordinates)):
			for j in range(len(ordinates[i])):
				
				if j == 0 and abs(ordinates[i][j]) > 1e-2 and len(loop) == 0: #Valida se o primeiro valor do loop é maior do que 0
					loop.append([0,0])  

				coordinate = [cont * dist, ordinates[i][j]]
				loop.append(coordinate)
				cont += 1
			
			loops.append(loop)
			loop = []
			if i == len(ordinates) - 1: #valida se foi o ultimo loop a ser processado
				if abs(loops[-1][-1][1]) > 1e-2: #Valida se o valor do ultimo loop é diferente de 0
					loops[-1].append([(cont - 1) * dist,0])
			
			else:
				# calcula o ponto de intersecção com o eixo das abcissas
				o = loops[-1][-1][0]
				a = abs(loops[-1][-1][1])
				b = abs(ordinates[i+1][0])
				x = (a * dist) / (a + b)
				loops[-1].append([o + x, 0]) #Acrecenta o ponto de intersecção no ultimo loop
				loop.append([o + x, 0]) # Acrescenta o ponto de intersecção no inicio do proximo loop
		
		return loops
	

	# Gera as faces
	def generateFaces(self, loops):
		faces = []
		for loop in loops:
			
			loop.append(loop[0])
			loop = [FreeCAD.Vector(value[0], 0, value[1]) for value in loop]

			edges = [Part.LineSegment(loop[i], loop[i+1]).toShape() for i in range(len(loop)-1)]
			wire = Part.Wire(edges)
			face = Part.Face(wire)
			# Valida a face
			if face.Area > 0:
				faces.append(face)
		
		return faces
	
	# Faz a rotação do  diagrama na direção passada como argumento e o posiciona
	def rotate(self, element, dirStart, dirEnd, position = FreeCAD.Vector(0,0,0.1)):
		try:
			dirStart.normalize()
			dirEnd.normalize()

			if dirStart == dirEnd:
				return element.translate(position)       
			
			rotacao = FreeCAD.Rotation(dirStart, dirEnd)
			elementoRotacionado = element.transformGeometry(FreeCAD.Placement(position,rotacao).toMatrix())
			return elementoRotacionado
		except:
			print("Error rotating diagram.")
			return element
	
	# Gero os valores nos diagramas
	def makeText(self, values, listMatrix, dist, fontHeight, precision, show_only_max_min=False):
		listWire = []

		if show_only_max_min:
			# Find max and min indices
			if not listMatrix:
				return listWire

			max_idx = max(range(len(listMatrix)), key=lambda i: listMatrix[i])
			min_idx = min(range(len(listMatrix)), key=lambda i: listMatrix[i])

			# Only show max and min labels
			indices_to_show = []
			if abs(listMatrix[max_idx]) > 1e-9:  # Not zero
				indices_to_show.append(max_idx)
			if abs(listMatrix[min_idx]) > 1e-9 and min_idx != max_idx:  # Not zero and different from max
				indices_to_show.append(min_idx)
		else:
			# Show all values
			indices_to_show = range(len(values))

		for i in indices_to_show:
			offset = 0
			valueString = listMatrix[i] * -1
			string = f"{valueString:.{precision}e}"
			x = dist * i
			y = values[i] + offset if values[i] > 0 else values[i] - offset

			text = Part.makeWireString(string, pathFont, fontHeight)
			for wires in text:
				for wire in wires:
					wire = wire.rotated(FreeCAD.Vector(0,0,0), FreeCAD.Vector(1,0,0), 90)
					wire = wire.translate(FreeCAD.Vector(x, 0, y))
					listWire += [wire]

		return listWire


	# Gera o diagrama da matriz passada como argumento
	def makeDiagram(self, matrix,nodes, members, orderMembers, nPoints, rotacao, escale, fontHeight, precision, drawText, show_only_max_min=False):

		# e = 1e-11
		nPoints = max(int(nPoints), 2)
		listDiagram = []
		for i, nameMember in orderMembers:
			if i >= len(matrix):
				continue
			p1 = nodes[int(members[nameMember]['nodes'][0])]
			p2 = nodes[int(members[nameMember]['nodes'][1])]
			length = ((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2 + (p2[2] - p1[2])**2)**0.5
			if length <= 1e-9:
				continue
			dist = length / (nPoints -1) #Distancia entre os pontos no eixo X
			values = [value * escale for value in matrix[i]]

			# Debug: check if values are valid
			if all(abs(v) < 1e-9 for v in values):
				print(f"diagram: skipping member {nameMember} - all values near zero")
				continue

			ordinates = self.separatesOrdinates(values)
			coordinates = self.generateCoordinates(ordinates, dist)
			faces = self.generateFaces(coordinates)
			texts = self.makeText(values, matrix[i], dist, fontHeight, precision, show_only_max_min)

			# Skip if no faces were generated
			if not faces:
				print(f"diagram: WARNING - no faces generated for member {nameMember}, values={values[:3]}...")
				continue

			# Posiciona o diagrama
			dx = p2[0] - p1[0]
			dy = p2[1] - p1[1]
			dz = p2[2] - p1[2]
			element = Part.makeCompound(faces)
			if drawText and texts:
				element = Part.makeCompound([element] + texts) 

			rot = FreeCAD.Rotation(FreeCAD.Vector(1,0,0), rotacao)
			element.Placement = FreeCAD.Placement(FreeCAD.Vector(0,0,0), rot)
			element = self.rotate(element, FreeCAD.Vector(1,0,0), FreeCAD.Vector(abs(dx), abs(dy), abs(dz)))

			if dx < 0 :
				element = element.mirror(FreeCAD.Vector(0,0,0), FreeCAD.Vector(1,0,0))
			
			if dy < 0 :
				element = element.mirror(FreeCAD.Vector(0,0,0), FreeCAD.Vector(0,1,0))

			
			element = element.translate(FreeCAD.Vector(p1[0], p1[1], p1[2]))
			
			listDiagram.append(element)
			# Part.show(element)
			# Part.show(Part.makeCompound(faces))
			# for face in faces:
			#     Part.show(Part.makeCompound(faces))
		
		return listDiagram

	def filterMembersSelected(self, obj, is_restoring=False):
		"""Filter members with backward compatibility and better error handling.

		Args:
			obj: The diagram object
			is_restoring: True if document is being restored (suppresses error dialogs)

		Handles multiple naming schemes:
		- Old style: "Line", "Line_0"
		- New segmented style: "Line_e0_s0", "Line_e0_s1"
		"""
		# If no selection, return all members
		if not hasattr(obj, "ObjectBaseElements") or not obj.ObjectBaseElements:
			if hasattr(obj, "ObjectBaseCalc") and obj.ObjectBaseCalc and hasattr(obj.ObjectBaseCalc, "NameMembers"):
				all_members = list(enumerate(obj.ObjectBaseCalc.NameMembers))
				print(f"diagram: filterMembersSelected - no selection, returning all {len(all_members)} members")
				return all_members
			return []

		listaNames = []

		for element in obj.ObjectBaseElements:
			if not element or len(element) < 2:
				continue

			element_name = element[0].Name
			sub_elements = element[1]  # List like ['Edge1', 'Edge2'] or []

			# Case 1: No sub-elements selected (user selected the line itself, not edges)
			if not sub_elements:
				print(f"diagram: filterMembersSelected - no sub-elements for '{element_name}', trying name-based matching")

				# Try to match by element name (with backward compatibility)
				for memberIndex, memberName in enumerate(obj.ObjectBaseCalc.NameMembers):
					matched = False

					# Try exact match (old style: "Line")
					if memberName == element_name:
						listaNames.append((memberIndex, memberName))
						print(f"diagram: filterMembersSelected - exact match: '{memberName}'")
						matched = True

					# Try prefix match for segmented members (new style: "Line_e0_s0")
					elif memberName.startswith(f"{element_name}_e"):
						listaNames.append((memberIndex, memberName))
						print(f"diagram: filterMembersSelected - prefix match: '{memberName}'")
						matched = True

					# Try old segmented style (old style: "Line_0", "Line_1")
					elif memberName.startswith(f"{element_name}_") and not "_e" in memberName:
						listaNames.append((memberIndex, memberName))
						print(f"diagram: filterMembersSelected - old format match: '{memberName}'")
						matched = True

				continue

			# Case 2: Sub-elements selected (user selected specific edges)
			# Extract edge indices from sub-element names
			listEdgeIndices = []
			for name in sub_elements:
				if 'Edge' in name:
					try:
						edge_idx = int(name.split('Edge')[1]) - 1
						listEdgeIndices.append(edge_idx)
					except (IndexError, ValueError) as e:
						print(f"diagram: WARNING - could not parse edge index from '{name}': {e}")

			# Match members by element name and edge index
			for edgeIdx in listEdgeIndices:
				for memberIndex, memberName in enumerate(obj.ObjectBaseCalc.NameMembers):
					# Try segmented format: "Line_e0_s0", "Line_e0_s1", etc.
					if memberName.startswith(f"{element_name}_e{edgeIdx}_s"):
						listaNames.append((memberIndex, memberName))
						print(f"diagram: filterMembersSelected - segmented match: '{memberName}'")

					# Try old edge format: "Line_e0" (without segments)
					elif memberName == f"{element_name}_e{edgeIdx}":
						listaNames.append((memberIndex, memberName))
						print(f"diagram: filterMembersSelected - edge match: '{memberName}'")

					# Try very old format: "Line_0" (just edge number)
					elif memberName == f"{element_name}_{edgeIdx}":
						listaNames.append((memberIndex, memberName))
						print(f"diagram: filterMembersSelected - old edge format: '{memberName}'")

		# Check if we matched anything
		if not listaNames:
			print(f"diagram: WARNING - No members matched!")
			print(f"  Selected elements: {[e[0].Name for e in obj.ObjectBaseElements if e]}")
			print(f"  Available members: {obj.ObjectBaseCalc.NameMembers[:5]}...")

			# Show user-friendly error (unless restoring document)
			if not is_restoring:
				from .ui_helpers import show_error_message
				selected_names = ', '.join(e[0].Name for e in obj.ObjectBaseElements if e)
				available_sample = ', '.join(obj.ObjectBaseCalc.NameMembers[:3])
				show_error_message(
					f"No members matched for diagram!\n\n"
					f"You selected: {selected_names}\n"
					f"Available members: {available_sample}...\n\n"
					f"Try:\n"
					f"• Select edges (not the line itself)\n"
					f"• Create diagram without selection (shows all)\n"
					f"• Re-run analysis if names changed"
				)

		print(f"diagram: filterMembersSelected - returning {len(listaNames)} filtered members")
		return listaNames


	def _distance(self, p1, p2):
		"""Calculate Euclidean distance between two points."""
		return ((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2 + (p2[2] - p1[2])**2)**0.5

	def _point_on_line_segment(self, point, line_start, line_end, tol=1.0):
		"""Check if a point lies on a line segment within tolerance."""
		# Vector from start to end
		dx = line_end[0] - line_start[0]
		dy = line_end[1] - line_start[1]
		dz = line_end[2] - line_start[2]
		length = (dx**2 + dy**2 + dz**2)**0.5

		if length < 1e-6:
			return False

		# Vector from start to point
		px = point[0] - line_start[0]
		py = point[1] - line_start[1]
		pz = point[2] - line_start[2]

		# Project point onto line (parameter t along line)
		t = (px * dx + py * dy + pz * dz) / (length * length)

		# Check if projection is within segment bounds
		if t < -0.01 or t > 1.01:  # Small tolerance for rounding
			return False

		# Find closest point on line
		closest_x = line_start[0] + t * dx
		closest_y = line_start[1] + t * dy
		closest_z = line_start[2] + t * dz

		# Check distance from point to line
		dist = ((point[0] - closest_x)**2 + (point[1] - closest_y)**2 + (point[2] - closest_z)**2)**0.5

		return dist <= tol

	def _safe_add(self, obj, prop_type, name, group, doc, default=None):
		try:
			props = obj.PropertiesList
		except Exception:
			props = []
		if name in props:
			return
		try:
			obj.addProperty(prop_type, name, group, doc)
		except Exception:
			return
		if default is not None:
			try:
				setattr(obj, name, default)
			except Exception:
				pass

	def _get_default_scale_moment(self, calc_obj):
		"""Get default moment scale based on unit system."""
		if calc_obj and hasattr(calc_obj, 'ForceUnit') and hasattr(calc_obj, 'LengthUnit'):
			force = calc_obj.ForceUnit
			length = calc_obj.LengthUnit

			# Moment is force × length
			# We want to display in "engineering units" (kN·m for SI)
			if force == 'N' and length == 'mm':
				# N·mm → kN·m visual scale
				# Divide by 1000 to make it visible in kN·m scale
				return 0.001
			elif force == 'kN' and length == 'm':
				return 1.0  # Already in kN·m
			elif force == 'kN' and length == 'mm':
				# kN·mm → kN·m scale (divide by 1000 for mm→m)
				return 0.001
			elif force == 'N' and length == 'm':
				# N·m → kN·m scale (divide by 1000 for N→kN)
				return 0.001
		return 1.0

	def _get_default_scale_deflection(self, calc_obj):
		"""Get default deflection scale based on unit system."""
		if calc_obj and hasattr(calc_obj, 'LengthUnit'):
			if calc_obj.LengthUnit == 'mm':
				# mm → m visual scale (multiply to make visible)
				return 1000.0
			elif calc_obj.LengthUnit == 'm':
				return 1.0
			elif calc_obj.LengthUnit == 'in':
				# inches → feet visual scale
				return 12.0
			elif calc_obj.LengthUnit == 'ft':
				return 1.0
		return 1.0

	def ensure_properties(self, obj):
		self._safe_add(obj, "App::PropertyLink", "ObjectBaseCalc", "Base", "elements for analysis")
		self._safe_add(obj, "App::PropertyLinkSubList", "ObjectBaseElements", "Base", "elements for analysis", [])
		self._safe_add(obj, "App::PropertyColor", "Color", "Diagram", "elements for analysis", (1.0,0.0,0.0,0.0))
		self._safe_add(obj, "App::PropertyInteger", "Transparency", "Diagram", "elements for analysis", 70)
		self._safe_add(obj, "App::PropertyInteger", "FontHeight", "Diagram", "Diagram font size", 100)
		self._safe_add(obj, "App::PropertyInteger", "Precision", "Diagram", "Decimal precision", 2)
		self._safe_add(obj, "App::PropertyBool", "DrawText", "Diagram", "Show value labels", False)
		self._safe_add(obj, "App::PropertyBool", "ShowOnlyMaxMin", "Diagram", "Show only max/min values", True)

		self._safe_add(obj, "App::PropertyBool", "MomentZ", "DiagramMoment", "Show moment diagram in Z", False)
		self._safe_add(obj, "App::PropertyBool", "MomentY", "DiagramMoment", "Show moment diagram in Y", False)
		# Get unit-aware default for moment scale
		moment_scale = self._get_default_scale_moment(obj.ObjectBaseCalc) if hasattr(obj, 'ObjectBaseCalc') else 1.0
		self._safe_add(obj, "App::PropertyFloat", "ScaleMoment", "DiagramMoment", "Moment diagram scale", moment_scale)

		self._safe_add(obj, "App::PropertyBool", "ShearZ", "DiagramShear", "Show shear diagram in Z", False)
		self._safe_add(obj, "App::PropertyBool", "ShearY", "DiagramShear", "Show shear diagram in Y", False)
		self._safe_add(obj, "App::PropertyFloat", "ScaleShear", "DiagramShear", "Shear diagram scale", 1)

		self._safe_add(obj, "App::PropertyBool", "Torque", "DiagramTorque", "Show torque diagram", False)
		self._safe_add(obj, "App::PropertyFloat", "ScaleTorque", "DiagramTorque", "Torque diagram scale", 1)

		self._safe_add(obj, "App::PropertyBool", "AxialForce", "DiagramAxial", "Show axial force diagram", False)
		self._safe_add(obj, "App::PropertyFloat", "ScaleAxial", "DiagramAxial", "Axial force diagram scale", 1)

		self._safe_add(obj, "App::PropertyBool", "DeflectionY", "DiagramDeflection", "Show deflection diagram in Y", False)
		self._safe_add(obj, "App::PropertyBool", "DeflectionZ", "DiagramDeflection", "Show deflection diagram in Z", True)
		# Get unit-aware default for deflection scale
		deflection_scale = self._get_default_scale_deflection(obj.ObjectBaseCalc) if hasattr(obj, 'ObjectBaseCalc') else 1.0
		self._safe_add(obj, "App::PropertyFloat", "ScaleDeflection", "DiagramDeflection", "Deflection diagram scale", deflection_scale)

	def _get_deflection_unit_scale(self, obj):
		unit = 'mm'
		if hasattr(obj, 'ObjectBaseCalc') and obj.ObjectBaseCalc and hasattr(obj.ObjectBaseCalc, 'LengthUnit'):
			unit = obj.ObjectBaseCalc.LengthUnit
		try:
			return float(FreeCAD.Units.Quantity(1, unit).getValueAs('mm'))
		except Exception:
			return 1.0

	def execute(self, obj):
		"""Generate diagram with comprehensive error reporting."""
		print("diagram: execute() called")
		self.ensure_properties(obj)

		# Check if we're restoring from file (don't show error dialogs during restore)
		is_restoring = False
		if hasattr(obj, "Document") and obj.Document:
			# Check Restoring property (all FreeCAD versions)
			is_restoring = obj.Document.Restoring
			# Also check PartialRestore if it exists (newer FreeCAD versions)
			if hasattr(obj.Document, 'PartialRestore'):
				is_restoring = is_restoring or obj.Document.PartialRestore

		if is_restoring:
			print("diagram: document is restoring, suppressing error dialogs")
			# During restore, just create empty shape silently if there are issues
			# User can recompute manually after document loads

		# Check for required properties
		required = [
			"ObjectBaseCalc",
			"ObjectBaseElements",
			"MomentZ",
			"MomentY",
			"ShearY",
			"ShearZ",
			"Torque",
			"AxialForce",
			"DeflectionY",
			"DeflectionZ",
			"ScaleMoment",
			"ScaleShear",
			"ScaleTorque",
			"ScaleAxial",
			"ScaleDeflection",
			"FontHeight",
			"Precision",
			"DrawText",
			"Color",
			"Transparency",
		]
		for name in required:
			if not hasattr(obj, name):
				print(f"diagram: missing required property '{name}', returning early")
				return

		# Check for Calc object - avoid modal dialogs when missing
		if not obj.ObjectBaseCalc:
			print("diagram: ERROR - ObjectBaseCalc is None (skipping modal error dialog)")
			obj.Shape = Part.Shape()
			return

		# Check for analysis results
		if not hasattr(obj.ObjectBaseCalc, "ListElements"):
			print("diagram: ERROR - ObjectBaseCalc has no ListElements")
			if not is_restoring:
				# Track errors per object to prevent loops
				if not hasattr(Diagram, '_no_data_errors_shown'):
					Diagram._no_data_errors_shown = set()

				obj_name = obj.Name if hasattr(obj, 'Name') else 'Unknown'

				if obj_name not in Diagram._no_data_errors_shown:
					Diagram._no_data_errors_shown.add(obj_name)
					print(f"diagram: showing 'No Data' error for {obj_name}")

					from .ui_helpers import show_error_message
					show_error_message(
						"Calc Object Has No Data!\n\n"
						f"Diagram: {obj_name}\n\n"
						"The linked Calc object appears empty or incomplete.\n\n"
						"Please:\n"
						"1. Verify the Calc object has been analyzed\n"
						"2. Check for error messages during analysis\n"
						"3. Try running analysis again\n"
						"4. Delete this invalid diagram object\n\n"
						"This error shown once per object to prevent loops."
					)
				else:
					print(f"diagram: already showed 'No Data' error for {obj_name}, skipping")

			obj.Shape = Part.Shape()
			return

		# Check if analysis has actually been run
		if not hasattr(obj.ObjectBaseCalc, "MomentZ") or not obj.ObjectBaseCalc.MomentZ:
			print("diagram: ERROR - Calc object has no results (MomentZ empty)")
			if not is_restoring:
				# Track errors per object to prevent loops
				if not hasattr(Diagram, '_no_results_errors_shown'):
					Diagram._no_results_errors_shown = set()

				obj_name = obj.Name if hasattr(obj, 'Name') else 'Unknown'

				if obj_name not in Diagram._no_results_errors_shown:
					Diagram._no_results_errors_shown.add(obj_name)
					print(f"diagram: showing 'Analysis Not Run' error for {obj_name}")

					from .ui_helpers import show_error_message
					show_error_message(
						"Analysis Not Run!\n\n"
						f"Diagram: {obj_name}\n\n"
						"The Calc object has no analysis results yet.\n\n"
						"Please:\n"
						"1. Select the Calc object in tree\n"
						"2. Click 'Run Analysis' button\n"
						"3. Wait for 'Analysis complete' message\n"
						"4. Delete this diagram and create new one\n\n"
						"This error shown once per object to prevent loops."
					)
				else:
					print(f"diagram: already showed 'Analysis Not Run' error for {obj_name}, skipping")

			obj.Shape = Part.Shape()
			return

		print(f"diagram: ObjectBaseCalc name: {obj.ObjectBaseCalc.Name}")

		elements = list(filter(lambda element: "Line" in element.Name or "Wire" in element.Name, obj.ObjectBaseCalc.ListElements))
		print(f"diagram: found {len(elements)} line/wire elements")

		# Use nodes from Calc object if available (includes refined support nodes)
		if hasattr(obj.ObjectBaseCalc, "Nodes") and obj.ObjectBaseCalc.Nodes:
			# Convert from App.Vector back to list format
			nodes = [[round(v.x, 2), round(v.y, 2), round(v.z, 2)] for v in obj.ObjectBaseCalc.Nodes]
			print(f"diagram: using {len(nodes)} nodes from Calc object")
		else:
			# Fallback to extracting from element vertices
			nodes = self.mapNodes(elements)
			print(f"diagram: extracted {len(nodes)} nodes from element vertices")

		# Build members dictionary from Calc NameMembers to include segmented members
		# Member names format: "ElementName_eX_sY" where X=edge index, Y=segment index
		members = {}
		if hasattr(obj.ObjectBaseCalc, "NameMembers") and obj.ObjectBaseCalc.NameMembers:
			# Get the actual member node connectivity by matching nodes to element geometry
			for element in elements:
				if not hasattr(element, 'RotationSection'):
					continue
				rotation = element.RotationSection.getValueAs('rad')

				# Get element geometry endpoints
				for edge_idx, edge in enumerate(element.Shape.Edges):
					v1 = edge.Vertexes[0].Point
					v2 = edge.Vertexes[1].Point
					elem_start = [round(v1.x, 2), round(v1.y, 2), round(v1.z, 2)]
					elem_end = [round(v2.x, 2), round(v2.y, 2), round(v2.z, 2)]

					# Find start and end node indices
					try:
						start_node_idx = nodes.index(elem_start)
						end_node_idx = nodes.index(elem_end)
					except ValueError:
						print(f"diagram: WARNING - could not find nodes for {element.Name} edge {edge_idx}")
						continue

					# Find all segmented members for this edge
					segment_members = [name for name in obj.ObjectBaseCalc.NameMembers
									 if name.startswith(f"{element.Name}_e{edge_idx}_s")]

					if not segment_members:
						# No segments, might be single member
						single_name = f"{element.Name}_e{edge_idx}"
						if single_name in obj.ObjectBaseCalc.NameMembers:
							members[single_name] = {
								'nodes': [str(start_node_idx), str(end_node_idx)],
								'RotationSection': rotation
							}
						continue

					# For segmented members, find intermediate nodes along the edge
					num_segments = len(segment_members)
					# Nodes are arranged sequentially along the edge
					# We need to find all nodes that lie on this edge line
					edge_nodes = []
					for node_idx, node in enumerate(nodes):
						# Check if node lies on the edge line (within tolerance)
						# Simple check: node is between start and end
						if self._point_on_line_segment(node, elem_start, elem_end, tol=1.0):
							edge_nodes.append(node_idx)

					# Sort nodes by distance from start
					edge_nodes.sort(key=lambda idx: self._distance(nodes[idx], elem_start))

					print(f"diagram: found {len(edge_nodes)} nodes for {element.Name}_e{edge_idx} ({num_segments} segments)")

					# Assign sequential node pairs to each segment
					for seg_idx in range(num_segments):
						member_name = f"{element.Name}_e{edge_idx}_s{seg_idx}"
						if seg_idx < len(edge_nodes) - 1:
							members[member_name] = {
								'nodes': [str(edge_nodes[seg_idx]), str(edge_nodes[seg_idx + 1])],
								'RotationSection': rotation
							}
						else:
							print(f"diagram: WARNING - not enough nodes for segment {member_name}")
		else:
			# Fallback to old method
			members = self.mapMembers(elements, nodes)

		print(f"diagram: mapped {len(members)} members")

		orderMembers = self.filterMembersSelected(obj, is_restoring)
		print(f"diagram: filtered to {len(orderMembers)} selected members")

		deflection_unit_scale = self._get_deflection_unit_scale(obj)
		print(f"diagram: deflection unit scale: {deflection_unit_scale}")

		# Get ShowOnlyMaxMin setting
		show_only_max_min = obj.ShowOnlyMaxMin if hasattr(obj, 'ShowOnlyMaxMin') else True
		print(f"diagram: ShowOnlyMaxMin={show_only_max_min}, DrawText={obj.DrawText}")

		listDiagram = []

		print(f"diagram: Checking diagram flags...")
		print(f"  MomentZ={obj.MomentZ}, MomentY={obj.MomentY}")
		print(f"  ShearY={obj.ShearY}, ShearZ={obj.ShearZ}")
		print(f"  Torque={obj.Torque}, AxialForce={obj.AxialForce}")
		print(f"  DeflectionY={obj.DeflectionY}, DeflectionZ={obj.DeflectionZ}")

		if obj.MomentZ:
			print("diagram: generating MomentZ diagram")
			try:
				matrix = self.getMatrix(obj.ObjectBaseCalc.MomentZ, is_restoring)
				print(f"  matrix has {len(matrix)} rows")
				diagrams = self.makeDiagram(matrix, nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsMoment, 0, obj.ScaleMoment, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
				print(f"  generated {len(diagrams)} diagram parts")
				listDiagram += diagrams
			except Exception as e:
				print(f"  ERROR generating MomentZ: {e}")

		if obj.MomentY:
			print("diagram: generating MomentY diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.MomentY, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsMoment, 90, obj.ScaleMoment, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating MomentY: {e}")

		if obj.ShearY:
			print("diagram: generating ShearY diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.ShearZ, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsShear, 90, obj.ScaleShear, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating ShearY: {e}")

		if obj.ShearZ:
			print("diagram: generating ShearZ diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.ShearY, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsShear, 0, obj.ScaleShear, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating ShearZ: {e}")

		if obj.Torque:
			print("diagram: generating Torque diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.Torque, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsTorque, 0, obj.ScaleTorque, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating Torque: {e}")

		if obj.AxialForce:
			print("diagram: generating AxialForce diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.AxialForce, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsAxial, 0, obj.ScaleAxial, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating AxialForce: {e}")

		if obj.DeflectionY:
			print("diagram: generating DeflectionY diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.DeflectionZ, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsDeflection, 90, obj.ScaleDeflection * deflection_unit_scale, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating DeflectionY: {e}")

		if obj.DeflectionZ:
			print("diagram: generating DeflectionZ diagram")
			try:
				listDiagram += self.makeDiagram(self.getMatrix(obj.ObjectBaseCalc.DeflectionY, is_restoring),nodes, members, orderMembers, obj.ObjectBaseCalc.NumPointsDeflection, 0, obj.ScaleDeflection * deflection_unit_scale, obj.FontHeight, obj.Precision, obj.DrawText, show_only_max_min)
			except Exception as e:
				print(f"  ERROR generating DeflectionZ: {e}")

		print(f"diagram: total diagram parts generated: {len(listDiagram)}")

		if not listDiagram:
			print("diagram: no diagrams generated, creating empty shape")

			# Determine why no diagrams were generated and show helpful error
			# BUT: Don't show dialogs during document restore (would loop forever)
			if not is_restoring:
				# If only deflection is enabled and values are near zero, skip modal error
				if obj.DeflectionZ and not (obj.MomentZ or obj.MomentY or obj.ShearZ or obj.ShearY or obj.Torque or obj.AxialForce or obj.DeflectionY):
					print("diagram: deflection-only diagram empty; skipping 'No Diagrams Generated' dialog")
					obj.Shape = Part.Shape()
					return
				# Use class-level flag to prevent duplicate dialogs across all instances
				if not hasattr(Diagram, '_error_dialog_shown') or not Diagram._error_dialog_shown:
					Diagram._error_dialog_shown = True  # Prevent duplicate dialogs globally
					print("diagram: showing 'No Diagrams Generated' error dialog")

					reasons = []

					if not orderMembers or len(orderMembers) == 0:
						reasons.append("• No members matched selection")
						reasons.append(f"  (Selected: {len(obj.ObjectBaseElements)} elements)")
						reasons.append(f"  (Available: {len(obj.ObjectBaseCalc.NameMembers)} members)")

					# Check if any diagram types are enabled
					diagram_types_enabled = []
					if obj.MomentZ: diagram_types_enabled.append("MomentZ")
					if obj.MomentY: diagram_types_enabled.append("MomentY")
					if obj.ShearZ: diagram_types_enabled.append("ShearZ")
					if obj.ShearY: diagram_types_enabled.append("ShearY")
					if obj.Torque: diagram_types_enabled.append("Torque")
					if obj.AxialForce: diagram_types_enabled.append("AxialForce")
					if obj.DeflectionY: diagram_types_enabled.append("DeflectionY")
					if obj.DeflectionZ: diagram_types_enabled.append("DeflectionZ")

					if not diagram_types_enabled:
						reasons.append("• No diagram types enabled!")
						reasons.append("  Enable at least one: MomentZ, ShearZ, etc.")

					# Check if all values were filtered out as zero
					if orderMembers and diagram_types_enabled:
						reasons.append("• All result values may be zero or very small")
						reasons.append("  (Check ScaleMoment, ScaleDeflection properties)")

					reason_text = "\n".join(reasons) if reasons else "• Unknown reason (check console log)"

					# Show modal dialog (will block until user clicks OK)
					try:
						from .ui_helpers import show_error_message
						show_error_message(
							f"No Diagrams Generated!\n\n"
							f"Possible reasons:\n{reason_text}\n\n"
							f"Debug Information:\n"
							f"• Calc members: {len(obj.ObjectBaseCalc.NameMembers) if hasattr(obj.ObjectBaseCalc, 'NameMembers') else 0}\n"
							f"• Selected elements: {len(obj.ObjectBaseElements)}\n"
							f"• Matched members: {len(orderMembers)}\n"
							f"• Enabled diagrams: {', '.join(diagram_types_enabled) if diagram_types_enabled else 'NONE'}\n\n"
							f"Solutions:\n"
							f"• Try creating diagram without selecting members (shows all)\n"
							f"• Enable at least one diagram type in properties\n"
							f"• Check that analysis produced valid results\n"
							f"• Review Report View for details"
						)
						print("diagram: error dialog closed by user")
					except Exception as e:
						print(f"diagram: WARNING - Could not show error dialog: {e}")
					finally:
						# Reset flag so dialog can be shown again for future failures
						Diagram._error_dialog_shown = False
						print("diagram: error dialog flag reset")
				else:
					print("diagram: error dialog already showing, skipping duplicate")
			else:
				print("diagram: skipping error dialog (document is restoring)")

			shape = Part.Shape()  # Create empty shape
		else:
			print("diagram: creating compound shape")
			shape = Part.makeCompound(listDiagram)

			# Debug: print bounding box to help diagnose visibility issues
			try:
				bb = shape.BoundBox
				print(f"diagram: BoundBox - XMin={bb.XMin:.2f}, XMax={bb.XMax:.2f}, YMin={bb.YMin:.2f}, YMax={bb.YMax:.2f}, ZMin={bb.ZMin:.2f}, ZMax={bb.ZMax:.2f}")
				print(f"diagram: BoundBox size - X={bb.XLength:.2f}, Y={bb.YLength:.2f}, Z={bb.ZLength:.2f}")

				# Check if diagram might be outside visible bounds
				max_coord = max(abs(bb.XMin), abs(bb.XMax), abs(bb.YMin), abs(bb.YMax), abs(bb.ZMin), abs(bb.ZMax))
				if max_coord > 100000:
					print(f"diagram: WARNING - Diagram extends very far ({max_coord:.0f} units)")
					print(f"  This may indicate incorrect scale or units")
					print(f"  Try adjusting ScaleMoment or ScaleDeflection properties")

			except Exception as e:
				print(f"diagram: could not get BoundBox: {e}")

			print(f"diagram: ✅ Successfully created {len(listDiagram)} diagram parts")

		obj.Shape = shape
		print(f"diagram: shape assigned, hasShape={obj.Shape is not None}")

		# Estilizacao
		if hasattr(obj, "ViewObject") and obj.ViewObject:
			obj.ViewObject.LineWidth = 1
			obj.ViewObject.PointSize = 1
			obj.ViewObject.LineColor = (int(obj.Color[0]*255),int(obj.Color[1]*255),int(obj.Color[2]*255))
			obj.ViewObject.PointColor = (int(obj.Color[0]*255),int(obj.Color[1]*255),int(obj.Color[2]*255))
			obj.ViewObject.ShapeAppearance = (FreeCAD.Material(DiffuseColor=obj.Color,AmbientColor=(0.33,0.33,0.33),SpecularColor=(0.53,0.53,0.53),EmissiveColor=(0.00,0.00,0.00),Shininess=(0.90),Transparency=(0.00),))
			obj.ViewObject.Transparency = obj.Transparency

	def onChanged(self,obj,Parameter):
		self.ensure_properties(obj)
		if not hasattr(obj, "ObjectBaseCalc"):
			return
		update_params = {
			"ObjectBaseCalc",
			"ObjectBaseElements",
			"MomentZ",
			"MomentY",
			"ShearY",
			"ShearZ",
			"Torque",
			"AxialForce",
			"DeflectionY",
			"DeflectionZ",
			"ScaleMoment",
			"ScaleShear",
			"ScaleTorque",
			"ScaleAxial",
			"ScaleDeflection",
			"FontHeight",
			"Precision",
			"DrawText",
			"ShowOnlyMaxMin",
			"Color",
			"Transparency",
		}
		if Parameter in update_params:
			self.execute(obj)

class ViewProviderDiagram:
	def __init__(self, obj):
		obj.Proxy = self

	def getIcon(self):
		return """/* XPM */
static char * moment_xpm[] = {
"32 32 51 1",
" 	c None",
".	c #0D0000",
"+	c #000000",
"@	c #0E0000",
"#	c #390000",
"$	c #060000",
"%	c #410000",
"&	c #F60000",
"*	c #090000",
"=	c #100000",
"-	c #460000",
";	c #F80000",
">	c #FF0000",
",	c #530000",
"'	c #FB0000",
")	c #5F0000",
"!	c #FD0000",
"~	c #660000",
"{	c #FE0000",
"]	c #720000",
"^	c #7D0000",
"/	c #8C0000",
"(	c #990000",
"_	c #9E0000",
":	c #AB0000",
"<	c #0B0000",
"[	c #B00000",
"}	c #070000",
"|	c #4A0000",
"1	c #880000",
"2	c #040000",
"3	c #4B0000",
"4	c #B50000",
"5	c #0C0000",
"6	c #B10000",
"7	c #A60000",
"8	c #940000",
"9	c #850000",
"0	c #840000",
"a	c #6D0000",
"b	c #0F0000",
"c	c #670000",
"d	c #FC0000",
"e	c #5A0000",
"f	c #110000",
"g	c #FA0000",
"h	c #4D0000",
"i	c #470000",
"j	c #050000",
"k	c #3B0000",
"l	c #010000",
"                                ",
"                              .+",
"                             @#$",
"                            .%&*",
"                           =-;>*",
"                          =,'>>*",
"                         @)!>>>*",
"                        =~{>>>>*",
"                       @]>>>>>>*",
"                      .^>>>>>>>*",
"                     @/>>>>>>>>*",
"                    .(>>>>>>>>>*",
"                   @_>>>>>>>>>>*",
"                  @:>>>>>>>>>>>*",
"                 <[>>>>>>>>>>>>*",
"                }|11111111111112",
"211111111111113}                ",
"$>>>>>>>>>>>>45                 ",
"$>>>>>>>>>>>6.                  ",
"$>>>>>>>>>>7@                   ",
"$>>>>>>>>>(5                    ",
"$>>>>>>>>8@                     ",
"$>>>>>>>9.                      ",
"$>>>>>>0@                       ",
"$>>>>{ab                        ",
"$>>>{cb                         ",
"$>>def                          ",
"$>gh=                           ",
"$;i@                            ",
"jkf                             ",
"l.                              ",
"+                               "};
		"""



class CommandDiagram():

	def GetResources(self):
		return {"Pixmap"  : os.path.join(ICONPATH, "icons/diagram.svg"), # the name of a svg file available in the resources
				"Accel"   : "Shift+D", # a default shortcut (optional)
				"MenuText": "Diagram",
				"ToolTip" : "Generate internal force diagrams"}
	
	def Activated(self):
		# Check if anything is selected
		selection = FreeCADGui.Selection.getSelectionEx()
		if not selection:
			show_error_message(
				"No Selection!\n\n"
				"To create a diagram:\n"
				"1. Select the Calc object in the tree\n"
				"2. Optionally select members (Line/Wire objects) to diagram specific members\n"
				"3. Click 'Diagram' button\n\n"
				"The Calc object MUST be selected first!"
			)
			print("diagram: No selection - need to select Calc object first")
			return

		objCalc = selection[0].Object
		listSelects = list(filter(lambda select: 'Wire' in select.Object.Name or 'Line' in select.Object.Name, selection))

		if 'Calc' in objCalc.Name: #valida se o primeiro elemento de fato é um calc

			doc = FreeCAD.ActiveDocument
			obj = doc.addObject("Part::FeaturePython", "Diagram")
			Diagram(obj, objCalc, listSelects)
			ViewProviderDiagram(obj.ViewObject)
			print(f"diagram: Created diagram linked to {objCalc.Name}")

		else:
			show_error_message(
				"Wrong Selection!\n\n"
				f"You selected: {objCalc.Name} (type: {objCalc.TypeId})\n\n"
				"To create a diagram:\n"
				"1. Select the Calc object in the tree (must be first)\n"
				"2. Optionally Ctrl+Click members (Line/Wire) to diagram specific members\n"
				"3. Click 'Diagram' button\n\n"
				"Make sure you select the Calc object FIRST!"
			)
			print(f"diagram: ERROR - First selection must be Calc object, got {objCalc.Name}")
	
	def IsActive(self):
		return True


FreeCADGui.addCommand("diagram", CommandDiagram())




