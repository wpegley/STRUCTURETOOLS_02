# -*- coding: utf-8 -*-
"""
UI Helper Functions for StructureTools

Shared UI utilities to avoid code duplication across modules.
"""

from PySide import QtWidgets


def show_error_message(msg: str, title: str = "Error") -> None:
    """
    Display an error message dialog to the user.

    Args:
        msg: The error message to display
        title: The dialog window title (default: "Error")
    """
    msg_box = QtWidgets.QMessageBox()
    msg_box.setIcon(QtWidgets.QMessageBox.Critical)
    msg_box.setWindowTitle(title)
    msg_box.setText(msg)
    msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
    msg_box.exec_()


def show_warning_message(msg: str, title: str = "Warning") -> None:
    """
    Display a warning message dialog to the user.

    Args:
        msg: The warning message to display
        title: The dialog window title (default: "Warning")
    """
    msg_box = QtWidgets.QMessageBox()
    msg_box.setIcon(QtWidgets.QMessageBox.Warning)
    msg_box.setWindowTitle(title)
    msg_box.setText(msg)
    msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
    msg_box.exec_()


def show_info_message(msg: str, title: str = "Information") -> None:
    """
    Display an information message dialog to the user.

    Args:
        msg: The information message to display
        title: The dialog window title (default: "Information")
    """
    msg_box = QtWidgets.QMessageBox()
    msg_box.setIcon(QtWidgets.QMessageBox.Information)
    msg_box.setWindowTitle(title)
    msg_box.setText(msg)
    msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
    msg_box.exec_()


def show_success_message(msg: str, title: str = "Success") -> None:
    """
    Display a success message dialog to the user.

    Args:
        msg: The success message to display
        title: The dialog window title (default: "Success")
    """
    show_info_message(msg, title)


def confirm_action(msg: str, title: str = "Confirm") -> bool:
    """
    Display a confirmation dialog and return user's choice.

    Args:
        msg: The confirmation message to display
        title: The dialog window title (default: "Confirm")

    Returns:
        True if user clicked Yes, False otherwise
    """
    msg_box = QtWidgets.QMessageBox()
    msg_box.setIcon(QtWidgets.QMessageBox.Question)
    msg_box.setWindowTitle(title)
    msg_box.setText(msg)
    msg_box.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
    msg_box.setDefaultButton(QtWidgets.QMessageBox.No)
    return msg_box.exec_() == QtWidgets.QMessageBox.Yes
