import traceback

import FreeCAD


def _print_msg(msg):
    FreeCAD.Console.PrintMessage(str(msg) + "\n")


def _print_warn(msg):
    FreeCAD.Console.PrintWarning(str(msg) + "\n")


def _print_err(msg):
    FreeCAD.Console.PrintError(str(msg) + "\n")


def debug(msg):
    _print_msg(msg)


def info(msg):
    _print_msg(msg)


def warn(msg):
    _print_warn(msg)


def warning(msg):
    _print_warn(msg)


def error(msg):
    _print_err(msg)


def exception(msg, exc=None):
    _print_err(msg)
    if exc:
        _print_err(repr(exc))
    _print_err(traceback.format_exc())
