import os

import FreeCAD as App
import FreeCADGui
import Part
from PySide import QtWidgets, QtCore

import utils

ICONPATH = os.path.join(os.path.dirname(__file__), "resources")
DEBUG_TAG = "[SupportDebug]"


def _resolve_point(obj, sub_name):
    """
    Try to get a world-space point for a vertex/edge reference.
    Falls back through multiple strategies for robustness.
    """
    # Special handling: member vertex -> resolve via base edge endpoints to avoid stale placements
    try:
        if getattr(getattr(obj, "Proxy", None), "Type", "") == "OpenSeesMember" and sub_name.startswith("Vertex"):
            base = utils.element_from_linksub(getattr(obj, "ObjectBase", []))
            if base:
                base_obj, base_sub = base
                edge = utils.get_shape_element_global(base_obj, base_sub)
                if edge and hasattr(edge, "Vertexes") and edge.Vertexes:
                    vidx = int(sub_name.replace("Vertex", "")) - 1
                    vidx = max(0, min(vidx, len(edge.Vertexes) - 1))
                    p = edge.Vertexes[vidx].Point
                    _log(f"_resolve_point: member vertex {getattr(obj,'Name',obj)}.{sub_name} mapped to base {getattr(base_obj,'Name',base_obj)}.{base_sub} -> ({p.x:.3f},{p.y:.3f},{p.z:.3f})")
                    return p
    except Exception:
        pass

    # 1) Direct global lookup
    try:
        el = utils.get_shape_element_global(obj, sub_name)
        if el:
            if hasattr(el, "Point"):
                _log(f"_resolve_point: direct global point {getattr(obj,'Name',obj)}.{sub_name} -> ({el.Point.x:.3f},{el.Point.y:.3f},{el.Point.z:.3f})")
                return el.Point
            if hasattr(el, "x"):
                _log(f"_resolve_point: direct global vector {getattr(obj,'Name',obj)}.{sub_name} -> ({el.x:.3f},{el.y:.3f},{el.z:.3f})")
                return el
            if hasattr(el, "Vertexes") and el.Vertexes:
                # Use start of edge
                p = el.Vertexes[0].Point
                _log(f"_resolve_point: direct global edge {getattr(obj,'Name',obj)}.{sub_name} -> ({p.x:.3f},{p.y:.3f},{p.z:.3f})")
                return p
    except Exception:
        pass
    # 2) Use base geometry of member if available
    try:
        if getattr(getattr(obj, "Proxy", None), "Type", "") == "OpenSeesMember":
            base = utils.element_from_linksub(getattr(obj, "ObjectBase", []))
            if base:
                el = utils.get_shape_element_global(*base)
                if el:
                    if hasattr(el, "Point"):
                        p = el.Point
                        _log(f"_resolve_point: member base point {getattr(base[0],'Name',base[0])}.{base[1]} -> ({p.x:.3f},{p.y:.3f},{p.z:.3f})")
                        return p
                    if hasattr(el, "x"):
                        _log(f"_resolve_point: member base vector {getattr(base[0],'Name',base[0])}.{base[1]} -> ({el.x:.3f},{el.y:.3f},{el.z:.3f})")
                        return el
                    if hasattr(el, "Vertexes") and el.Vertexes:
                        return el.Vertexes[0].Point
    except Exception:
        pass
    # 3) Local geometry (unplaced) then apply placement
    try:
        shape = getattr(obj, "Shape", None)
        if shape:
            if sub_name.startswith("Vertex"):
                idx = int(sub_name.replace("Vertex", "")) - 1
                if idx < len(shape.Vertexes):
                    p = shape.Vertexes[idx].Point
                    plc = getattr(obj, "Placement", None)
                    if plc:
                        return plc.multVec(p)
                    return p
            if sub_name.startswith("Edge"):
                idx = int(sub_name.replace("Edge", "")) - 1
                if idx < len(shape.Edges):
                    edge = shape.Edges[idx]
                    p = edge.Vertexes[0].Point if edge.Vertexes else None
                    if p:
                        plc = getattr(obj, "Placement", None)
                        if plc:
                            return plc.multVec(p)
                        return p
    except Exception:
        pass
    return None


def _normalize_selection(selection_obj, sub_name):
    """
    If the user clicks the Member object, its Shape is already placed in
    world coords. Applying Placement again doubles the offset. Normalize
    to the underlying base geometry to avoid double transforms.
    """
    # If the user picked a vertex on the member, keep it as-is (we need that vertex id)
    try:
        if getattr(getattr(selection_obj, "Proxy", None), "Type", "") == "OpenSeesMember" and sub_name.startswith("Vertex"):
            _log(f"Normalize: keeping member vertex selection {selection_obj.Name}.{sub_name}")
            return selection_obj, sub_name
    except Exception:
        pass
    try:
        if getattr(getattr(selection_obj, "Proxy", None), "Type", "") == "OpenSeesMember":
            base = utils.element_from_linksub(getattr(selection_obj, "ObjectBase", []))
            if base:
                _log(f"Normalize: member edge selection {selection_obj.Name}.{sub_name} -> {getattr(base[0],'Name',base[0])}.{base[1]}")
                return base[0], base[1]
    except Exception:
        pass
    return selection_obj, sub_name


def _error(msg: str):
    box = QtWidgets.QMessageBox()
    box.setIcon(QtWidgets.QMessageBox.Critical)
    box.setWindowTitle("Support")
    box.setText(msg)
    box.exec_()


def _log(msg: str):
    try:
        utils.log(f"{DEBUG_TAG} {msg}")
    except Exception:
        pass


# Solver anchor (hidden): holds the DOFs, no shape
class OpenSeesSupportAnchor:
    Type = "OpenSeesSupport"

    def __init__(self, obj, selection):
        obj.Proxy = self
        sel_obj, sel_sub = _normalize_selection(selection[0], selection[1])
        obj.addProperty("App::PropertyLinkSubList", "ObjectBase", "Base", "Reference vertex").ObjectBase = [
            (sel_obj, (sel_sub,))
        ]
        obj.addProperty("App::PropertyVector", "AnchorPoint", "Base", "Stored vertex coordinate for solver")
        obj.addProperty("App::PropertyBool", "FixTranslationX", "Translation", "Fix UX").FixTranslationX = True
        obj.addProperty("App::PropertyBool", "FixTranslationY", "Translation", "Fix UY").FixTranslationY = True
        obj.addProperty("App::PropertyBool", "FixTranslationZ", "Translation", "Fix UZ").FixTranslationZ = True
        obj.addProperty("App::PropertyBool", "FixRotationX", "Rotation", "Fix RX").FixRotationX = True
        obj.addProperty("App::PropertyBool", "FixRotationY", "Rotation", "Fix RY").FixRotationY = True
        obj.addProperty("App::PropertyBool", "FixRotationZ", "Rotation", "Fix RZ").FixRotationZ = True
        obj.addProperty("App::PropertyFloat", "ScaleDraw", "Display", "Scale of support symbol").ScaleDraw = 10.0
        obj.ViewObject.Visibility = False
        obj.Label = "Support"

    def execute(self, obj):
        # Refresh the stored anchor from the current geometry so moves stay in sync
        anchor = None
        link = utils.element_from_linksub(obj.ObjectBase)
        if link:
            anchor = _resolve_point(*link)
        if anchor:
            obj.AnchorPoint = anchor
            _log(f"Anchor execute resolved -> ({anchor.x:.3f}, {anchor.y:.3f}, {anchor.z:.3f}) on {getattr(link[0],'Name',link[0])}.{link[1]}")
        else:
            _log(f"Anchor execute could NOT resolve geometry for link {link}")
        # No shape; solver-only anchor
        obj.Shape = Part.Shape()


# Visible glyph: combined translation (semi-transparent cones) + rotation (solid discs)
class OpenSeesSupportGlyph:
    Type = "OpenSeesSupportGlyph"

    def __init__(self, obj, selection, anchor_point=None):
        obj.Proxy = self
        sel_obj, sel_sub = _normalize_selection(selection[0], selection[1])
        obj.addProperty("App::PropertyLinkSubList", "ObjectBase", "Base", "Reference vertex").ObjectBase = [
            (sel_obj, (sel_sub,))
        ]
        obj.addProperty("App::PropertyVector", "AnchorPoint", "Base", "Stored vertex coordinate for drawing")
        if anchor_point is not None:
            obj.AnchorPoint = anchor_point
        else:
            try:
                vert = utils.get_shape_element_global(selection[0], selection[1])
                if vert and hasattr(vert, "Point"):
                    obj.AnchorPoint = vert.Point
            except Exception:
                pass
        obj.addProperty("App::PropertyBool", "FixTranslationX", "Translation", "Fix UX").FixTranslationX = True
        obj.addProperty("App::PropertyBool", "FixTranslationY", "Translation", "Fix UY").FixTranslationY = True
        obj.addProperty("App::PropertyBool", "FixTranslationZ", "Translation", "Fix UZ").FixTranslationZ = True
        obj.addProperty("App::PropertyBool", "FixRotationX", "Rotation", "Fix RX").FixRotationX = True
        obj.addProperty("App::PropertyBool", "FixRotationY", "Rotation", "Fix RY").FixRotationY = True
        obj.addProperty("App::PropertyBool", "FixRotationZ", "Rotation", "Fix RZ").FixRotationZ = True
        obj.addProperty("App::PropertyFloat", "ScaleDraw", "Display", "Scale of support symbol").ScaleDraw = 10.0
        obj.Label = "SupportGlyph"

    def _vertex(self, obj):
        link = utils.element_from_linksub(obj.ObjectBase)
        if not link:
            _log("Glyph _vertex: missing ObjectBase link")
            return None
        pt = _resolve_point(*link)
        if pt:
            return pt
        # Fallback to stored anchor if geometry resolution failed
        if hasattr(obj, "AnchorPoint"):
            try:
                ap = obj.AnchorPoint
                if abs(ap.x) > 1e-9 or abs(ap.y) > 1e-9 or abs(ap.z) > 1e-9:
                    return ap
            except Exception:
                pass
        _log("Glyph _vertex: failed to resolve point; no anchor fallback available")
        return None

    def _cone(self, obj):
        s = max(0.2, obj.ScaleDraw)
        cone = Part.makeCone(0, 5.0 * s, 10.0 * s)
        cone.translate(App.Vector(0, 0, -10.0 * s))
        return cone

    def _rot_cylinders(self, obj):
        s = max(0.2, obj.ScaleDraw)
        rad = (3.0 * s * 1.75 * 1.5 * 1.5) * 0.6
        h = (18.0 * s * 0.05) * 0.6
        parts = []
        if obj.FixRotationX:
            c = Part.makeCylinder(rad, h)
            c.rotate(App.Vector(0, 0, 0), App.Vector(0, 1, 0), 90)
            parts.append((c, (1.0, 0.0, 0.0)))
        if obj.FixRotationY:
            c = Part.makeCylinder(rad, h)
            c.rotate(App.Vector(0, 0, 0), App.Vector(1, 0, 0), -90)
            parts.append((c, (0.0, 0.7, 0.0)))
        if obj.FixRotationZ:
            c = Part.makeCylinder(rad, h)
            parts.append((c, (0.0, 0.3, 1.0)))
        return parts

    def execute(self, obj):
        point = self._vertex(obj)
        if not point:
            obj.Shape = Part.Shape()
            _log(f"Glyph execute: no point resolved for {obj.Name}")
            return

        shapes = []
        face_colors = []
        # Translation cones (semi-transparent)
        if obj.FixTranslationX:
            c = self._cone(obj)
            c.rotate(App.Vector(0, 0, 0), App.Vector(0, 1, 0), 90)
            shapes.append(c)
            face_colors.extend([(1.0, 0.0, 0.0)] * len(c.Faces))
        if obj.FixTranslationY:
            c = self._cone(obj)
            c.rotate(App.Vector(0, 0, 0), App.Vector(1, 0, 0), -90)
            shapes.append(c)
            face_colors.extend([(0.0, 0.7, 0.0)] * len(c.Faces))
        if obj.FixTranslationZ:
            c = self._cone(obj)
            shapes.append(c)
            face_colors.extend([(0.0, 0.3, 1.0)] * len(c.Faces))
        # Rotation discs (solid)
        for cyl, col in self._rot_cylinders(obj):
            shapes.append(cyl)
            face_colors.extend([col] * len(cyl.Faces))

        if not shapes:
            obj.Shape = Part.Shape()
            return

        compound = Part.makeCompound(shapes)
        obj.Shape = compound
        obj.Placement = App.Placement(point, App.Rotation())
        obj.ViewObject.DisplayMode = "Shaded"
        obj.ViewObject.ShapeColor = (0.6, 0.6, 0.6)
        obj.ViewObject.LineColor = (0.2, 0.2, 0.2)
        try:
            if face_colors and len(face_colors) == len(obj.Shape.Faces):
                obj.ViewObject.DiffuseColor = face_colors
            else:
                obj.ViewObject.DiffuseColor = [(0.6, 0.6, 0.6)] * len(obj.Shape.Faces)
        except Exception:
            pass
        try:
            obj.ViewObject.Transparency = 35  # arrows semi-transparent
        except Exception:
            pass


class ViewProviderSupport:
    def __init__(self, obj):
        obj.Proxy = self

    def getIcon(self):
        return os.path.join(ICONPATH, "icons", "suport.svg")


class CommandSupport:
    def GetResources(self):
        return {
            "Pixmap": os.path.join(ICONPATH, "icons", "suport.svg"),
            "Accel": "Shift+U",
            "MenuText": "Support",
            "ToolTip": "Select a vertex to apply restraints (UX/UY/UZ, RX/RY/RZ). Each support saves with the document.",
        }

    def Activated(self):
        doc = App.ActiveDocument
        if doc is None:
            _error("Open a document before adding supports.")
            return

        previews = {}

        def add_preview(selection_obj, sub_name, opts):
            key = (selection_obj.Name, sub_name)
            if key in previews:
                return
            anchor = None
            sel_obj, sel_sub = _normalize_selection(selection_obj, sub_name)
            anchor = _resolve_point(sel_obj, sel_sub)
            if anchor is None:
                _log(f"Support preview: could not resolve vertex on {selection_obj.Name}.{sub_name} (normalized to {sel_obj.Name}.{sel_sub})")
            else:
                _log(f"Support preview resolved {selection_obj.Name}.{sub_name} -> ({anchor.x:.3f}, {anchor.y:.3f}, {anchor.z:.3f})")
            glyph = doc.addObject("Part::FeaturePython", "SupportGlyph")
            OpenSeesSupportGlyph(glyph, (sel_obj, sel_sub), anchor)
            ViewProviderSupport(glyph.ViewObject)

            glyph.FixTranslationX = opts["tx"]
            glyph.FixTranslationY = opts["ty"]
            glyph.FixTranslationZ = opts["tz"]
            glyph.FixRotationX = opts["rx"]
            glyph.FixRotationY = opts["ry"]
            glyph.FixRotationZ = opts["rz"]
            glyph.ScaleDraw = opts["scale"]

            previews[key] = glyph

        def update_previews(opts):
            for glyph in previews.values():
                glyph.FixTranslationX = opts["tx"]
                glyph.FixTranslationY = opts["ty"]
                glyph.FixTranslationZ = opts["tz"]
                glyph.FixRotationX = opts["rx"]
                glyph.FixRotationY = opts["ry"]
                glyph.FixRotationZ = opts["rz"]
                glyph.ScaleDraw = opts["scale"]
                try:
                    glyph.touch()
                except Exception:
                    pass
            doc.recompute()

        dlg = SupportOptionsDialog(on_change=update_previews)
        dlg.setWindowModality(QtCore.Qt.NonModal)
        dlg.setWindowFlags(dlg.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)

        current = list(FreeCADGui.Selection.getSelectionEx())
        if not current:
            utils.log("Select a vertex to preview support; dialog stays open.")
        else:
            opts = dlg.values()
            for selection in current:
                verts = [sub for sub in selection.SubElementNames if "Vertex" in sub]
                if not verts:
                    # Fallback: use endpoints of the shape
                    try:
                        vtx = getattr(selection.Object.Shape, "Vertexes", [])
                        if vtx:
                            verts = ["Vertex1", f"Vertex{len(vtx)}"]
                            utils.log(f"Selection {selection.Object.Name} has no vertex subelements; using endpoints.")
                        else:
                            utils.log(f"Selection {selection.Object.Name} has no vertex subelements; skipping.")
                            continue
                    except Exception:
                        utils.log(f"Selection {selection.Object.Name} has no vertex subelements; skipping.")
                        continue
                for sub in verts:
                    add_preview(selection.Object, sub, opts)
            doc.recompute()

        class _SelectionObserver:
            def __init__(self, on_select):
                self.on_select = on_select

            def addSelection(self, doc_name, obj_name, sub_name, pnt):
                try:
                    self.on_select(doc_name, obj_name, sub_name, pnt)
                except Exception:
                    pass

        observer = _SelectionObserver(
            lambda doc_n, obj_n, sub_n, _p: add_preview(App.getDocument(doc_n).getObject(obj_n), sub_n, dlg.values())
            if "Vertex" in sub_n else None
        )
        FreeCADGui.Selection.addObserver(observer)

        def finalize(result):
            FreeCADGui.Selection.removeObserver(observer)
            if result == QtWidgets.QDialog.Accepted and previews:
                opts = dlg.values()
                created = 0
                for glyph in previews.values():
                    # Create hidden anchor for solver
                    link = utils.element_from_linksub(glyph.ObjectBase)
                    if not link:
                        utils.log(f"Skipping glyph {glyph.Name}: missing ObjectBase link")
                        continue
                    anchor_point = None
                    try:
                        ap = _resolve_point(*link)
                        if ap:
                            anchor_point = ap
                    except Exception:
                        anchor_point = None
                    if anchor_point is None:
                        try:
                            if getattr(glyph, "Proxy", None):
                                anchor_point = glyph.Proxy._vertex(glyph)
                        except Exception:
                            anchor_point = None
                    anchor = doc.addObject("Part::FeaturePython", "OpenSeesSupport")
                    OpenSeesSupportAnchor(anchor, link)
                    ViewProviderSupport(anchor.ViewObject)
                    anchor.FixTranslationX = opts["tx"]
                    anchor.FixTranslationY = opts["ty"]
                    anchor.FixTranslationZ = opts["tz"]
                    anchor.FixRotationX = opts["rx"]
                    anchor.FixRotationY = opts["ry"]
                    anchor.FixRotationZ = opts["rz"]
                    anchor.ScaleDraw = opts["scale"]
                    if anchor_point:
                        anchor.AnchorPoint = anchor_point
                        try:
                            _log(f"Support created at ({anchor_point.x:.3f}, {anchor_point.y:.3f}, {anchor_point.z:.3f}) from {getattr(link[0],'Name',link[0])}.{link[1]}")
                        except Exception:
                            pass
                    else:
                        _log(f"Support created but no anchor point resolved for {glyph.Name} ({getattr(link[0],'Name',link[0])}.{link[1]})")
                    try:
                        anchor.ViewObject.Visibility = False
                        anchor.ViewObject.ShowInTree = False
                    except Exception:
                        pass
                    # Keep glyph visible
                    glyph.Label = "Support"
                    created += 1
                doc.recompute()
                utils.log(f"Created {created} support(s) with hidden anchors.")
            else:
                for glyph in previews.values():
                    try:
                        doc.removeObject(glyph.Name)
                    except Exception:
                        pass
                doc.recompute()

        dlg.finished.connect(finalize)
        dlg.show()

    def IsActive(self):
        return True


FreeCADGui.addCommand("opensees_support", CommandSupport())


class SupportOptionsDialog(QtWidgets.QDialog):
    """Dialog for support DOF choices with live preview callback."""

    def __init__(self, parent=None, on_change=None):
        super().__init__(parent)
        self.on_change = on_change
        self.setWindowTitle("Support Options")
        self.resize(320, 260)
        layout = QtWidgets.QVBoxLayout(self)

        form = QtWidgets.QFormLayout()
        self.tx = QtWidgets.QCheckBox("Fix UX (red X translation)"); self.tx.setChecked(True)
        self.ty = QtWidgets.QCheckBox("Fix UY (green Y translation)"); self.ty.setChecked(True)
        self.tz = QtWidgets.QCheckBox("Fix UZ (blue Z translation)"); self.tz.setChecked(True)
        self.rx = QtWidgets.QCheckBox("Fix RX (roll about X)"); self.rx.setChecked(True)
        self.ry = QtWidgets.QCheckBox("Fix RY (roll about Y)"); self.ry.setChecked(True)
        self.rz = QtWidgets.QCheckBox("Fix RZ (roll about Z)"); self.rz.setChecked(True)
        form.addRow(self.tx); form.addRow(self.ty); form.addRow(self.tz)
        form.addRow(self.rx); form.addRow(self.ry); form.addRow(self.rz)

        self.scale = QtWidgets.QDoubleSpinBox()
        self.scale.setRange(0.1, 1e3)
        self.scale.setValue(10.0)
        self.scale.setDecimals(2)
        form.addRow("Glyph scale:", self.scale)

        layout.addLayout(form)

        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        layout.addWidget(buttons)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        for cb in (self.tx, self.ty, self.tz, self.rx, self.ry, self.rz):
            cb.stateChanged.connect(self._emit_change)
        self.scale.valueChanged.connect(self._emit_change)

    def _emit_change(self, *args):
        if self.on_change:
            self.on_change(self.values())

    def values(self):
        return {
            "tx": self.tx.isChecked(),
            "ty": self.ty.isChecked(),
            "tz": self.tz.isChecked(),
            "rx": self.rx.isChecked(),
            "ry": self.ry.isChecked(),
            "rz": self.rz.isChecked(),
            "scale": float(self.scale.value()),
        }
