# -*- coding: utf-8 -*-
"""
Constants and Configuration for StructureTools

Centralized location for magic numbers and configuration values.
"""

# =============================================================================
# LOAD VISUALIZATION CONSTANTS
# =============================================================================

# Arrow geometry for load visualization (in mm)
LOAD_ARROW_CONE_RADIUS = 5
LOAD_ARROW_CONE_HEIGHT = 20
LOAD_ARROW_CYLINDER_HEIGHT = 30
LOAD_ARROW_CYLINDER_RADIUS = 2

# Scale factor for load visualization
LOAD_SCALE_FACTOR = 1000000  # Convert from N to visualization units


# =============================================================================
# SUPPORT VISUALIZATION CONSTANTS
# =============================================================================

# Support geometry (in mm)
SUPPORT_CONE_RADIUS = 100
SUPPORT_CONE_HEIGHT = 200
SUPPORT_PLATE_LENGTH = 220
SUPPORT_PLATE_HEIGHT = 20
SUPPORT_PLATE_GAP = 20
SUPPORT_BOX_SIZE = 50

# Support colors (RGB, 0-1 range)
SUPPORT_NODE_COLOR = (1.0, 0.0, 0.0)  # Red


# =============================================================================
# ANALYSIS CONFIGURATION
# =============================================================================

# Default segmentation settings
DEFAULT_SEGMENTS_PER_MEMBER = 4
MIN_SEGMENTS_PER_MEMBER = 1
MAX_SEGMENTS_PER_MEMBER = 100

# Analysis accuracy levels (segments per member)
ACCURACY_QUICK = 2
ACCURACY_INTERMEDIATE = 4
ACCURACY_HIGH = 8
ACCURACY_ULTRA_HIGH = 16

# Performance warning thresholds
WARNING_ELEMENT_COUNT = 500
CRITICAL_ELEMENT_COUNT = 1000

# Tolerance settings
DEFAULT_NODE_TOLERANCE = 1e-4  # meters
DEFAULT_SUPPORT_TOLERANCE = 1e-2  # meters


# =============================================================================
# MATERIAL CONSTANTS
# =============================================================================

# Default material properties
DEFAULT_STEEL_E = 210000  # MPa
DEFAULT_STEEL_POISSON = 0.30
DEFAULT_STEEL_DENSITY = 7850  # kg/m^3

# Material property bounds
MIN_ELASTIC_MODULUS = 0  # MPa (exclusive)
MIN_POISSON_RATIO = -1.0
MAX_POISSON_RATIO = 0.5
MIN_DENSITY = 0  # kg/m^3 (exclusive)


# =============================================================================
# RESULT SAMPLING
# =============================================================================

# Number of points to sample along members for results
DEFAULT_MOMENT_POINTS = 11
DEFAULT_SHEAR_POINTS = 11
DEFAULT_AXIAL_POINTS = 5
DEFAULT_TORQUE_POINTS = 5
DEFAULT_DEFLECTION_POINTS = 11


# =============================================================================
# UNIT SYSTEM
# =============================================================================

# Default units
DEFAULT_LENGTH_UNIT = 'm'
DEFAULT_FORCE_UNIT = 'kN'


# =============================================================================
# UI CONSTANTS
# =============================================================================

# Dialog dimensions
MIN_DIALOG_WIDTH = 500

# Color schemes (for future use)
COLOR_PRIMARY = "#2c3e50"
COLOR_SECONDARY = "#3498db"
COLOR_SUCCESS = "#27ae60"
COLOR_WARNING = "#f39c12"
COLOR_DANGER = "#e74c3c"
COLOR_INFO = "#3498db"


# =============================================================================
# FILE PATHS
# =============================================================================

# Resource subdirectories (relative to module root)
RESOURCE_DIR = "resources"
ICON_DIR = "icons"
TRANSLATION_DIR = "translations"
FONT_DIR = "fonts"

# Icon files
ICON_WORKBENCH = "icone.svg"
ICON_CALC = "calc.svg"
ICON_MEMBER = "member.svg"
ICON_MATERIAL = "material.svg"
ICON_SECTION = "section.svg"
ICON_SUPPORT = "suport.svg"
ICON_SUPPORT_EDGE = "suport_edge.svg"
ICON_LOAD_DISTRIBUTED = "load_distributed.svg"
ICON_LOAD_NODAL = "load_nodal.svg"
ICON_LOAD_POINT = "load_point.svg"
ICON_DIAGRAM = "diagram.svg"

# Font files
FONT_ARIAL = "ARIAL.TTF"