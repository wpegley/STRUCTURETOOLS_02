# -*- coding: utf-8 -*-
"""
Unit Management System for StructureTools

Handles unit system selection and conversion for structural analysis.
PyNite is unit-agnostic, so we must carefully manage units throughout.

CRITICAL: Unit consistency is essential for correct structural analysis!
"""

import FreeCAD as App
from typing import Dict, Tuple, Optional
from . import logger


class UnitSystem:
    """
    Defines a consistent unit system for structural analysis.

    All quantities must use consistent units to ensure PyNite calculations are correct.
    """

    def __init__(self, name: str, length: str, force: str, mass: str, description: str = ""):
        """
        Initialize a unit system.

        Args:
            name: Human-readable name (e.g., "SI (m, kN)")
            length: Length unit (e.g., "m", "mm", "in", "ft")
            force: Force unit (e.g., "kN", "N", "kip", "lbf")
            mass: Mass unit (e.g., "kg", "t", "slug", "lb")
            description: Optional description of the unit system
        """
        self.name = name
        self.length = length
        self.force = force
        self.mass = mass
        self.description = description

        # Derived units (computed from base units)
        self.stress = f"{force}/{length}^2"  # Force per area
        self.density = f"{mass}/{length}^3"  # Mass per volume
        self.force_per_length = f"{force}/{length}"  # Distributed load
        self.moment = f"{force}*{length}"  # Moment/torque
        self.area = f"{length}^2"
        self.second_moment = f"{length}^4"  # Moment of inertia

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"UnitSystem({self.name}, length={self.length}, force={self.force}, mass={self.mass})"

    def to_dict(self) -> Dict[str, str]:
        """Export unit system as dictionary for serialization."""
        return {
            'name': self.name,
            'length': self.length,
            'force': self.force,
            'mass': self.mass,
            'description': self.description
        }


# =============================================================================
# PREDEFINED UNIT SYSTEMS
# =============================================================================

# SI Units (Metric)
UNIT_SI_M_KN = UnitSystem(
    name="SI (m, kN, t)",
    length="m",
    force="kN",
    mass="t",  # metric ton (1000 kg)
    description="Standard SI units with kilonewtons (common in structural engineering)"
)

UNIT_SI_M_N = UnitSystem(
    name="SI (m, N, kg)",
    length="m",
    force="N",
    mass="kg",
    description="Pure SI units with newtons"
)

UNIT_SI_MM_N = UnitSystem(
    name="SI (mm, N, kg)",
    length="mm",
    force="N",
    mass="kg",
    description="SI units with millimeters (common in mechanical engineering)"
)

UNIT_SI_MM_KN = UnitSystem(
    name="SI (mm, kN, t)",
    length="mm",
    force="kN",
    mass="t",
    description="SI units with millimeters and kilonewtons"
)

# US Customary Units (Imperial)
UNIT_US_FT_KIP = UnitSystem(
    name="US Customary (ft, kip, kip)",
    length="ft",
    force="kip",  # 1 kip = 1000 lbf
    mass="kip",  # Mass in kip (not pound-mass)
    description="US units with kips (common in US structural engineering)"
)

UNIT_US_IN_KIP = UnitSystem(
    name="US Customary (in, kip, kip)",
    length="in",
    force="kip",
    mass="kip",
    description="US units with inches and kips"
)

UNIT_US_FT_LBF = UnitSystem(
    name="US Customary (ft, lbf, lb)",
    length="ft",
    force="lbf",  # pound-force
    mass="lb",  # pound-mass
    description="US units with pounds"
)

UNIT_US_IN_LBF = UnitSystem(
    name="US Customary (in, lbf, lb)",
    length="in",
    force="lbf",
    mass="lb",
    description="US units with inches and pounds"
)


# All available unit systems
AVAILABLE_UNIT_SYSTEMS = [
    UNIT_SI_M_KN,      # Most common for structural
    UNIT_SI_M_N,       # Pure SI
    UNIT_SI_MM_N,      # Mechanical engineering
    UNIT_SI_MM_KN,     # Alternative metric
    UNIT_US_FT_KIP,    # Most common for US structural
    UNIT_US_IN_KIP,    # US with inches
    UNIT_US_FT_LBF,    # US with pounds
    UNIT_US_IN_LBF,    # US inches and pounds
]


class UnitManager:
    """
    Manages the active unit system for the StructureTools workbench.

    This is a singleton that maintains the current unit selection and
    provides unit conversion utilities.
    """

    _instance = None
    _unit_system: Optional[UnitSystem] = None

    def __new__(cls):
        """Singleton pattern - only one instance allowed."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        """Initialize the unit manager."""
        # Try to detect FreeCAD's preferred unit system
        self._unit_system = self._detect_freecad_units()
        logger.info(f"UnitManager: initialized with {self._unit_system}")

    def _detect_freecad_units(self) -> UnitSystem:
        """
        Attempt to detect FreeCAD's current unit preferences.

        Returns:
            Detected or default unit system
        """
        try:
            # Get FreeCAD parameter set
            param = App.ParamGet("User parameter:BaseApp/Preferences/Units")
            user_schema = param.GetInt("UserSchema", 0)

            # FreeCAD unit schemas:
            # 0 = Standard (mm, kg, s)
            # 1 = MKS (m, kg, s)
            # 2 = US customary (in, lb)
            # 3 = Imperial (in, lb)
            # 4 = Building Euro (cm, m², m³)
            # 5 = Building US (ft-in, sqft, cuft)
            # 6 = Metric small parts (mm)
            # 7 = Imperial for Civil Engineering (ft, sqft, cuft)

            schema_map = {
                0: UNIT_SI_M_KN,      # Standard (CHANGED: m/kN better for structural analysis)
                1: UNIT_SI_M_N,       # MKS
                2: UNIT_US_IN_LBF,    # US customary
                3: UNIT_US_IN_LBF,    # Imperial
                4: UNIT_SI_M_KN,      # Building Euro (use m, kN)
                5: UNIT_US_FT_KIP,    # Building US (use ft, kip)
                6: UNIT_SI_M_KN,      # Metric small parts (CHANGED: m/kN better)
                7: UNIT_US_FT_KIP,    # Imperial Civil
            }

            detected = schema_map.get(user_schema, UNIT_SI_M_KN)
            logger.info(f"UnitManager: detected FreeCAD schema {user_schema} -> {detected.name}")
            return detected

        except Exception as exc:
            logger.warn(f"UnitManager: could not detect FreeCAD units: {exc}")
            # Default to most common structural engineering units
            return UNIT_SI_M_KN

    def get_unit_system(self) -> UnitSystem:
        """Get the current active unit system."""
        if self._unit_system is None:
            self._unit_system = UNIT_SI_M_KN
        return self._unit_system

    def set_unit_system(self, unit_system: UnitSystem) -> None:
        """
        Set the active unit system.

        Args:
            unit_system: The unit system to use
        """
        if not isinstance(unit_system, UnitSystem):
            raise TypeError(f"Expected UnitSystem, got {type(unit_system)}")

        self._unit_system = unit_system
        logger.info(f"UnitManager: unit system changed to {unit_system.name}")

        # Save to FreeCAD parameters for persistence
        try:
            param = App.ParamGet("User parameter:BaseApp/Preferences/Mod/StructureTools")
            param.SetString("UnitSystemName", unit_system.name)
            param.SetString("LengthUnit", unit_system.length)
            param.SetString("ForceUnit", unit_system.force)
            param.SetString("MassUnit", unit_system.mass)
        except Exception as exc:
            logger.warn(f"UnitManager: could not save preferences: {exc}")

    def get_available_systems(self) -> list:
        """Get list of all available unit systems."""
        return AVAILABLE_UNIT_SYSTEMS

    def get_system_by_name(self, name: str) -> Optional[UnitSystem]:
        """
        Find a unit system by name.

        Args:
            name: Name of the unit system

        Returns:
            UnitSystem if found, None otherwise
        """
        for system in AVAILABLE_UNIT_SYSTEMS:
            if system.name == name:
                return system
        return None

    def get_length_unit(self) -> str:
        """Get current length unit."""
        return self.get_unit_system().length

    def get_force_unit(self) -> str:
        """Get current force unit."""
        return self.get_unit_system().force

    def get_mass_unit(self) -> str:
        """Get current mass unit."""
        return self.get_unit_system().mass

    def get_stress_unit(self) -> str:
        """Get current stress/pressure unit (force/area)."""
        return self.get_unit_system().stress

    def get_density_unit(self) -> str:
        """Get current density unit (mass/volume)."""
        return self.get_unit_system().density

    def validate_consistency(self) -> Tuple[bool, str]:
        """
        Validate that the current unit system is internally consistent.

        Returns:
            (is_valid, message)
        """
        system = self.get_unit_system()

        # Check that units are recognized by FreeCAD
        try:
            # Test length unit
            App.Units.Quantity(1.0, system.length)

            # Test force unit
            App.Units.Quantity(1.0, system.force)

            # Test mass unit
            App.Units.Quantity(1.0, system.mass)

            return True, f"Unit system '{system.name}' is valid"

        except Exception as exc:
            return False, f"Invalid unit system: {exc}"


# Global singleton instance
_unit_manager_instance = None


def get_unit_manager() -> UnitManager:
    """
    Get the global UnitManager singleton instance.

    Returns:
        UnitManager instance
    """
    global _unit_manager_instance
    if _unit_manager_instance is None:
        _unit_manager_instance = UnitManager()
    return _unit_manager_instance


# Convenience functions for easy access
def get_current_units() -> UnitSystem:
    """Get the current active unit system."""
    return get_unit_manager().get_unit_system()


def get_length_unit() -> str:
    """Get current length unit (e.g., 'm', 'mm', 'ft')."""
    return get_unit_manager().get_length_unit()


def get_force_unit() -> str:
    """Get current force unit (e.g., 'kN', 'N', 'kip')."""
    return get_unit_manager().get_force_unit()


def get_mass_unit() -> str:
    """Get current mass unit (e.g., 'kg', 't', 'lb')."""
    return get_unit_manager().get_mass_unit()