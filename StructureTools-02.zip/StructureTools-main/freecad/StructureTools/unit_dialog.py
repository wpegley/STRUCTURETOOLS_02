# -*- coding: utf-8 -*-
"""
Unit System Selection Dialog for StructureTools

Provides a GUI for users to select or confirm the unit system
at workbench activation.
"""

from PySide import QtWidgets, QtCore, QtGui
import FreeCAD as App

from .unit_manager import (
    get_unit_manager,
    UnitSystem,
    AVAILABLE_UNIT_SYSTEMS,
    UNIT_SI_M_KN,
    UNIT_US_FT_KIP
)
from . import logger


class UnitSelectionDialog(QtWidgets.QDialog):
    """
    Dialog for selecting the unit system for structural analysis.

    Shown at workbench activation to ensure user is aware of and
    confirms the unit system being used.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.unit_manager = get_unit_manager()
        self.selected_system = self.unit_manager.get_unit_system()

        self.setWindowTitle("StructureTools - Unit System")
        self.setMinimumWidth(600)
        self.setModal(True)

        self.setup_ui()

    def setup_ui(self):
        """Build the dialog UI."""
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Header
        header = QtWidgets.QLabel("⚙️ Unit System Configuration")
        header.setStyleSheet("""
            font-size: 16pt;
            font-weight: bold;
            color: #2c3e50;
            padding: 10px;
        """)
        layout.addWidget(header)

        # Warning message
        warning = QtWidgets.QLabel(
            "⚠️ <b>CRITICAL:</b> Unit consistency is essential for correct structural analysis!\n\n"
            "PyNite (the FEA solver) is <b>unit-agnostic</b> and will use whatever units you provide.\n"
            "All inputs (geometry, loads, materials, sections) <b>MUST</b> use the same unit system.\n\n"
            "<b>Mixing units will produce incorrect and potentially dangerous results!</b>"
        )
        warning.setWordWrap(True)
        warning.setStyleSheet("""
            QLabel {
                background-color: #fff3cd;
                border: 2px solid #ffc107;
                border-radius: 5px;
                padding: 15px;
                color: #856404;
            }
        """)
        layout.addWidget(warning)

        # Detected FreeCAD units
        detected_group = QtWidgets.QGroupBox("Detected FreeCAD Preferences")
        detected_layout = QtWidgets.QFormLayout()

        try:
            param = App.ParamGet("User parameter:BaseApp/Preferences/Units")
            user_schema = param.GetInt("UserSchema", 0)
            schema_names = {
                0: "Standard (mm, kg, s)",
                1: "MKS (m, kg, s)",
                2: "US Customary (in, lb)",
                3: "Imperial decimal (in, lb)",
                4: "Building Euro (cm, m², m³)",
                5: "Building US (ft-in)",
                6: "Metric small parts & CNC (mm)",
                7: "Imperial for Civil Eng (ft, in)",
            }
            schema_name = schema_names.get(user_schema, f"Unknown ({user_schema})")

            detected_label = QtWidgets.QLabel(f"<b>{schema_name}</b>")
            detected_layout.addRow("FreeCAD Unit Schema:", detected_label)

            hint = QtWidgets.QLabel(
                "<i>StructureTools has automatically suggested a compatible unit system below.</i>"
            )
            hint.setWordWrap(True)
            detected_layout.addRow("", hint)

        except Exception as exc:
            logger.warn(f"unit_dialog: could not read FreeCAD preferences: {exc}")
            error_label = QtWidgets.QLabel("<i>Could not detect FreeCAD unit preferences</i>")
            detected_layout.addRow("Status:", error_label)

        detected_group.setLayout(detected_layout)
        layout.addWidget(detected_group)

        # Unit system selection
        selection_group = QtWidgets.QGroupBox("Select Unit System for Analysis")
        selection_layout = QtWidgets.QVBoxLayout()

        # Create radio buttons for each unit system
        self.radio_buttons = []
        self.button_group = QtWidgets.QButtonGroup(self)

        # Organize by category
        layout.addWidget(QtWidgets.QLabel("<b>Metric (SI) Units:</b>"))
        for system in AVAILABLE_UNIT_SYSTEMS:
            if system.name.startswith("SI"):
                radio = self._create_unit_radio_button(system)
                self.button_group.addButton(radio)
                self.radio_buttons.append(radio)
                selection_layout.addWidget(radio)

        selection_layout.addSpacing(10)
        selection_layout.addWidget(QtWidgets.QLabel("<b>US Customary (Imperial) Units:</b>"))

        for system in AVAILABLE_UNIT_SYSTEMS:
            if system.name.startswith("US"):
                radio = self._create_unit_radio_button(system)
                self.button_group.addButton(radio)
                self.radio_buttons.append(radio)
                selection_layout.addWidget(radio)

        # Pre-select the current system
        for radio in self.radio_buttons:
            if radio.property("unit_system") == self.selected_system:
                radio.setChecked(True)
                break

        selection_group.setLayout(selection_layout)
        layout.addWidget(selection_group)

        # Unit details display
        self.details_group = QtWidgets.QGroupBox("Selected Unit System Details")
        self.details_layout = QtWidgets.QFormLayout()

        self.length_label = QtWidgets.QLabel()
        self.force_label = QtWidgets.QLabel()
        self.mass_label = QtWidgets.QLabel()
        self.stress_label = QtWidgets.QLabel()
        self.density_label = QtWidgets.QLabel()

        self.details_layout.addRow("<b>Length:</b>", self.length_label)
        self.details_layout.addRow("<b>Force:</b>", self.force_label)
        self.details_layout.addRow("<b>Mass:</b>", self.mass_label)
        self.details_layout.addRow("<b>Stress/Pressure:</b>", self.stress_label)
        self.details_layout.addRow("<b>Density:</b>", self.density_label)

        self.details_group.setLayout(self.details_layout)
        layout.addWidget(self.details_group)

        # Update details with current selection
        self._update_details()

        # Connect radio button changes to details update
        self.button_group.buttonClicked.connect(self._on_selection_changed)

        # Remember choice checkbox
        remember_group = QtWidgets.QGroupBox()
        remember_layout = QtWidgets.QVBoxLayout()

        self.remember_checkbox = QtWidgets.QCheckBox(
            "Remember this choice and don't show this dialog again"
        )
        self.remember_checkbox.setChecked(False)
        self.remember_checkbox.setStyleSheet("QCheckBox { font-weight: bold; padding: 5px; }")

        # Add explanatory label
        remember_hint = QtWidgets.QLabel(
            "<i>You can change units later via: StructureTools menu → Unit Settings</i>"
        )
        remember_hint.setWordWrap(True)
        remember_hint.setStyleSheet("color: #7f8c8d; padding-left: 20px;")

        remember_layout.addWidget(self.remember_checkbox)
        remember_layout.addWidget(remember_hint)
        remember_group.setLayout(remember_layout)
        layout.addWidget(remember_group)

        # Buttons
        button_box = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def _create_unit_radio_button(self, system: UnitSystem) -> QtWidgets.QRadioButton:
        """Create a radio button for a unit system with description."""
        radio = QtWidgets.QRadioButton(system.name)
        radio.setProperty("unit_system", system)

        # Add tooltip with description
        if system.description:
            radio.setToolTip(system.description)

        # Highlight recommended choices
        if system in [UNIT_SI_M_KN, UNIT_US_FT_KIP]:
            radio.setText(system.name + " (Recommended)")
            radio.setStyleSheet("QRadioButton { font-weight: bold; }")

        return radio

    def _on_selection_changed(self, button):
        """Handle unit system selection change."""
        self.selected_system = button.property("unit_system")
        self._update_details()

    def _update_details(self):
        """Update the details display with selected unit system."""
        if not self.selected_system:
            return

        self.length_label.setText(f"<code>{self.selected_system.length}</code>")
        self.force_label.setText(f"<code>{self.selected_system.force}</code>")
        self.mass_label.setText(f"<code>{self.selected_system.mass}</code>")
        self.stress_label.setText(f"<code>{self.selected_system.stress}</code>")
        self.density_label.setText(f"<code>{self.selected_system.density}</code>")

    def get_selected_system(self) -> UnitSystem:
        """Get the selected unit system."""
        return self.selected_system

    def should_remember(self) -> bool:
        """Check if user wants to remember the choice."""
        checked = self.remember_checkbox.isChecked()
        logger.info(f"unit_dialog: remember checkbox state = {checked}")
        return checked

    def accept(self):
        """Handle OK button click."""
        # Validate selection
        if not self.selected_system:
            QtWidgets.QMessageBox.warning(
                self,
                "No Selection",
                "Please select a unit system before continuing."
            )
            return

        # Apply the selected unit system
        self.unit_manager.set_unit_system(self.selected_system)
        logger.info(f"unit_dialog: user selected {self.selected_system.name}")

        # Save "don't show again" preference if checked
        remember = self.should_remember()
        logger.info(f"unit_dialog: remember preference = {remember}")

        if remember:
            try:
                param = App.ParamGet("User parameter:BaseApp/Preferences/Mod/StructureTools")
                param.SetBool("DontShowUnitDialog", True)
                logger.info("unit_dialog: saved 'don't show again' preference to FreeCAD parameters")
                App.Console.PrintMessage("Unit preference saved - dialog will not show on next activation\n")
            except Exception as exc:
                logger.warn(f"unit_dialog: could not save preferences: {exc}")
                App.Console.PrintWarning(f"Could not save preference: {exc}\n")

        super().accept()


def show_unit_dialog(parent=None) -> bool:
    """
    Show the unit selection dialog.

    Returns:
        True if user confirmed, False if cancelled
    """
    # Check if user has previously chosen to not show the dialog
    try:
        param = App.ParamGet("User parameter:BaseApp/Preferences/Mod/StructureTools")
        dont_show = param.GetBool("DontShowUnitDialog", False)

        if dont_show:
            logger.info("unit_dialog: skipped (user preference)")
            return True
    except Exception as exc:
        logger.warn(f"unit_dialog: could not read preferences: {exc}")

    # Show the dialog
    dialog = UnitSelectionDialog(parent)
    result = dialog.exec_()

    return result == QtWidgets.QDialog.Accepted


def reset_unit_dialog_preference():
    """Reset the 'don't show again' preference for the unit dialog."""
    try:
        param = App.ParamGet("User parameter:BaseApp/Preferences/Mod/StructureTools")
        param.SetBool("DontShowUnitDialog", False)
        logger.info("unit_dialog: reset 'don't show again' preference")
        return True
    except Exception as exc:
        logger.error(f"unit_dialog: could not reset preference: {exc}")
        return False


# Global flag to prevent duplicate dialogs
_dialog_shown = False


def show_unit_dialog_deferred():
    """
    Show unit dialog with deferred execution (non-blocking for workbench activation).

    This function is called via QTimer to avoid blocking workbench startup.
    Includes protection against showing duplicate dialogs.
    """
    global _dialog_shown

    # Prevent duplicate dialogs from being shown
    if _dialog_shown:
        logger.info("unit_dialog: already shown, skipping duplicate")
        return

    try:
        from .unit_manager import get_current_units

        # Check if user has previously chosen to not show the dialog
        param = App.ParamGet("User parameter:BaseApp/Preferences/Mod/StructureTools")
        dont_show = param.GetBool("DontShowUnitDialog", False)

        if dont_show:
            # Load saved unit system
            units = get_current_units()
            logger.info(f"unit_dialog: using saved units: {units.name}")
            App.Console.PrintMessage(f"Using unit system: {units.name}\n")
            _dialog_shown = True
            return

        # Mark as shown to prevent duplicates
        _dialog_shown = True

        # Show the dialog
        dialog = UnitSelectionDialog()
        result = dialog.exec_()

        if result == QtWidgets.QDialog.Accepted:
            units = get_current_units()
            App.Console.PrintMessage(f"Unit system selected: {units.name}\n")
        else:
            logger.info("unit_dialog: cancelled by user")

    except Exception as exc:
        logger.exception(f"unit_dialog: error in deferred show: {exc}")
        App.Console.PrintError(f"Unit dialog error: {exc}\n")
        _dialog_shown = False  # Reset on error so it can be tried again