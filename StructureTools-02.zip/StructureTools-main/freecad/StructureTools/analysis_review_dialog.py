"""
Pre-Analysis Review Dialog

Displays all analysis inputs with their units and allows user to verify/correct
interpretations before running the calculation.
"""

import FreeCAD as App
from PySide import QtCore, QtWidgets, QtGui


class AnalysisReviewDialog(QtWidgets.QDialog):
    """Dialog for reviewing analysis inputs before calculation."""

    def __init__(self, calc_obj, parent=None):
        super().__init__(parent)
        self.calc_obj = calc_obj
        self.unit_corrections = {}  # Store user corrections
        self.accepted = False

        self.setWindowTitle("Analysis Review - Verify Units")
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)

        # Minimal styling - just highlight selected tab, let FreeCAD handle the rest
        self.setStyleSheet("""
            QTabBar::tab:selected {
                background-color: palette(highlight);
                color: palette(highlighted-text);
                font-weight: bold;
            }
        """)

        self.setup_ui()
        self.populate_data()

    def setup_ui(self):
        """Create the dialog UI."""
        layout = QtWidgets.QVBoxLayout(self)

        # Header
        header = QtWidgets.QLabel(
            "<b>Review Analysis Parameters</b><br>"
            "Verify that all values are interpreted correctly before running analysis."
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        # Warning banner - use QGroupBox for visual distinction
        warning_box = QtWidgets.QGroupBox("⚠️ Important")
        warning_layout = QtWidgets.QVBoxLayout(warning_box)
        warning = QtWidgets.QLabel(
            "<b>Common Issue</b>: Distributed loads are often given in <b>kN/m</b>, "
            "but may be entered as <b>N/mm</b>. Check load magnitudes carefully!"
        )
        warning.setWordWrap(True)
        warning_layout.addWidget(warning)
        layout.addWidget(warning_box)

        # Tab widget for different categories
        self.tabs = QtWidgets.QTabWidget()
        layout.addWidget(self.tabs)

        # System Units Tab
        self.system_tab = QtWidgets.QWidget()
        self.system_layout = QtWidgets.QFormLayout(self.system_tab)
        self.tabs.addTab(self.system_tab, "System Units")

        # Members Tab
        self.members_tab = QtWidgets.QWidget()
        self.members_layout = QtWidgets.QVBoxLayout(self.members_tab)
        self.tabs.addTab(self.members_tab, "Members")

        # Loads Tab
        self.loads_tab = QtWidgets.QWidget()
        self.loads_layout = QtWidgets.QVBoxLayout(self.loads_tab)
        self.loads_scroll = QtWidgets.QScrollArea()
        self.loads_scroll.setWidgetResizable(True)
        self.loads_container = QtWidgets.QWidget()
        self.loads_container_layout = QtWidgets.QVBoxLayout(self.loads_container)
        self.loads_scroll.setWidget(self.loads_container)
        self.loads_layout.addWidget(self.loads_scroll)
        self.tabs.addTab(self.loads_tab, "Loads")

        # Supports Tab
        self.supports_tab = QtWidgets.QWidget()
        self.supports_layout = QtWidgets.QVBoxLayout(self.supports_tab)
        self.tabs.addTab(self.supports_tab, "Supports")

        # Analysis Settings Tab
        self.settings_tab = QtWidgets.QWidget()
        self.settings_layout = QtWidgets.QFormLayout(self.settings_tab)
        self.tabs.addTab(self.settings_tab, "Analysis Settings")

        # Button box
        button_box = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def populate_data(self):
        """Populate the dialog with analysis data."""
        self.populate_system_units()
        self.populate_members()
        self.populate_loads()
        self.populate_supports()
        self.populate_settings()

    def populate_system_units(self):
        """Populate system units tab."""
        # Get unit system
        length_unit = self.calc_obj.LengthUnit if hasattr(self.calc_obj, 'LengthUnit') else 'mm'
        force_unit = self.calc_obj.ForceUnit if hasattr(self.calc_obj, 'ForceUnit') else 'N'

        self.system_layout.addRow("Length Unit:", QtWidgets.QLabel(f"<b>{length_unit}</b>"))
        self.system_layout.addRow("Force Unit:", QtWidgets.QLabel(f"<b>{force_unit}</b>"))

        # Derived units
        dist_load_unit = f"{force_unit}/{length_unit}"
        moment_unit = f"{force_unit}·{length_unit}"

        self.system_layout.addRow("Distributed Load Unit:", QtWidgets.QLabel(f"<b>{dist_load_unit}</b>"))
        self.system_layout.addRow("Moment Unit:", QtWidgets.QLabel(f"<b>{moment_unit}</b>"))

        # Common engineering units for reference
        self.system_layout.addRow("", QtWidgets.QLabel(""))  # Spacer
        ref_label = QtWidgets.QLabel(
            "<b>Common Engineering Units Reference:</b><br>"
            "• Distributed loads: kN/m, kN/ft, lb/ft<br>"
            "• Point loads: kN, kip, lb<br>"
            "• Moments: kN·m, kip·ft, lb·ft"
        )
        ref_label.setWordWrap(True)
        self.system_layout.addRow(ref_label)

    def populate_members(self):
        """Populate members tab."""
        if not hasattr(self.calc_obj, 'ListElements'):
            self.members_layout.addWidget(QtWidgets.QLabel("No elements found"))
            return

        elements = [e for e in self.calc_obj.ListElements if 'Line' in e.Name or 'Wire' in e.Name or hasattr(e, 'SectionMember')]

        if not elements:
            self.members_layout.addWidget(QtWidgets.QLabel("No structural members found"))
            return

        table = QtWidgets.QTableWidget(len(elements), 4)
        table.setHorizontalHeaderLabels(["Member", "Material", "Section", "Length"])
        table.horizontalHeader().setStretchLastSection(True)

        for i, element in enumerate(elements):
            # Member name
            table.setItem(i, 0, QtWidgets.QTableWidgetItem(element.Name))

            # Material
            mat_name = element.MaterialMember.Name if hasattr(element, 'MaterialMember') and element.MaterialMember else "Not set"
            table.setItem(i, 1, QtWidgets.QTableWidgetItem(mat_name))

            # Section
            sec_name = element.SectionMember.Name if hasattr(element, 'SectionMember') and element.SectionMember else "Not set"
            table.setItem(i, 2, QtWidgets.QTableWidgetItem(sec_name))

            # Length
            if hasattr(element, 'Shape') and element.Shape:
                length = element.Shape.Length
                length_unit = self.calc_obj.LengthUnit if hasattr(self.calc_obj, 'LengthUnit') else 'mm'
                length_converted = float(App.Units.Quantity(length, 'mm').getValueAs(length_unit))
                table.setItem(i, 3, QtWidgets.QTableWidgetItem(f"{length_converted:.1f} {length_unit}"))
            else:
                table.setItem(i, 3, QtWidgets.QTableWidgetItem("N/A"))

        self.members_layout.addWidget(table)

    def populate_loads(self):
        """Populate loads tab with unit correction options."""
        if not hasattr(self.calc_obj, 'ListElements'):
            self.loads_container_layout.addWidget(QtWidgets.QLabel("No elements found"))
            return

        loads = [e for e in self.calc_obj.ListElements if 'Load' in e.Name or hasattr(e, 'ForceZ')]

        if not loads:
            self.loads_container_layout.addWidget(QtWidgets.QLabel("No loads found"))
            return

        for load_idx, load in enumerate(loads):
            # Create group box for each load
            group = QtWidgets.QGroupBox(f"📊 {load.Name}")
            group_layout = QtWidgets.QFormLayout(group)

            # Load type
            if hasattr(load, 'InitialLoading') and hasattr(load, 'FinalLoading'):
                load_type = "Distributed Load"
            elif hasattr(load, 'PointLoading'):
                load_type = "Point Load"
            else:
                load_type = "Unknown"

            group_layout.addRow("Type:", QtWidgets.QLabel(f"<b>{load_type}</b>"))

            # Direction
            if hasattr(load, 'GlobalDirection'):
                direction = load.GlobalDirection
                group_layout.addRow("Direction:", QtWidgets.QLabel(direction))

            # For distributed loads
            if hasattr(load, 'InitialLoading') and hasattr(load, 'FinalLoading'):
                initial = load.InitialLoading
                final = load.FinalLoading

                # Get raw numeric value (what user actually entered)
                if hasattr(initial, 'Value'):
                    initial_val = float(initial.Value)
                    final_val = float(final.Value)
                else:
                    initial_val = float(initial)
                    final_val = float(final)

                # Current interpretation
                force_unit = self.calc_obj.ForceUnit if hasattr(self.calc_obj, 'ForceUnit') else 'N'
                length_unit = self.calc_obj.LengthUnit if hasattr(self.calc_obj, 'LengthUnit') else 'mm'
                current_unit = f"{force_unit}/{length_unit}"

                group_layout.addRow("Value Entered:", QtWidgets.QLabel(f"<b>{initial_val:.3f}</b>"))
                group_layout.addRow("Currently Stored As:", QtWidgets.QLabel(f"<b>{initial_val:.6f} {current_unit}</b>"))

                # Unit correction options
                correct_label = QtWidgets.QLabel("<b style='color: #d9534f;'>⚠️ If you meant different units, select here:</b>")
                group_layout.addRow("", correct_label)

                unit_combo = QtWidgets.QComboBox()
                unit_combo.addItem(f"✓ Correct as shown ({current_unit})", None)
                unit_combo.addItem("kN/m", "kN/m")
                unit_combo.addItem("kN/mm", "kN/mm")
                unit_combo.addItem("N/m", "N/m")
                unit_combo.addItem("N/mm", "N/mm")
                unit_combo.addItem("kip/ft", "kip/ft")
                unit_combo.addItem("kip/in", "kip/in")
                unit_combo.addItem("lb/ft", "lb/ft")
                unit_combo.addItem("lb/in", "lb/in")

                unit_combo.currentIndexChanged.connect(
                    lambda idx, ld=load, combo=unit_combo, grp_layout=group_layout, init_v=initial_val:
                        self.on_load_unit_changed(ld, combo, grp_layout, init_v)
                )

                group_layout.addRow("I actually meant:", unit_combo)

                # Placeholder for conversion display (will be populated by on_load_unit_changed)
                conversion_label = QtWidgets.QLabel("")
                group_layout.addRow("", conversion_label)

                # Store references
                self.unit_corrections[load.Name] = {
                    'combo': unit_combo,
                    'load': load,
                    'conversion_label': conversion_label,
                    'initial_val': initial_val,
                    'final_val': final_val
                }

            # For point loads
            elif hasattr(load, 'PointLoading'):
                point_load = load.PointLoading
                force_unit = self.calc_obj.ForceUnit if hasattr(self.calc_obj, 'ForceUnit') else 'N'

                point_val = float(point_load.getValueAs(force_unit)) if hasattr(point_load, 'getValueAs') else float(point_load)

                group_layout.addRow("Magnitude:", QtWidgets.QLabel(f"<b>{point_val:.3f} {force_unit}</b>"))

                # Unit correction for point loads
                unit_combo = QtWidgets.QComboBox()
                unit_combo.addItem(f"✓ Correct as shown ({force_unit})", None)
                unit_combo.addItem("kN", "kN")
                unit_combo.addItem("N", "N")
                unit_combo.addItem("kip", "kip")
                unit_combo.addItem("lb", "lb")

                # Note: Point load unit correction disabled but keep UI for consistency
                # unit_combo.currentIndexChanged.connect(
                #     lambda idx, ld=load, combo=unit_combo: self.on_load_unit_changed(ld, combo)
                # )

                group_layout.addRow("Actual units:", unit_combo)

                self.unit_corrections[load.Name] = {'combo': unit_combo, 'load': load}

            self.loads_container_layout.addWidget(group)

        self.loads_container_layout.addStretch()

    def on_load_unit_changed(self, load, combo, group_layout, initial_val):
        """Handle load unit correction and show conversion."""
        actual_unit = combo.currentData()

        if load.Name not in self.unit_corrections:
            return

        conversion_label = self.unit_corrections[load.Name].get('conversion_label')

        if actual_unit is None:
            # No correction needed
            self.unit_corrections[load.Name]['correction'] = None
            if conversion_label:
                conversion_label.setText("")
        else:
            # Store correction
            self.unit_corrections[load.Name]['correction'] = actual_unit

            # Calculate and display what will be sent to Calc
            if actual_unit == "kN/m":
                converted = initial_val * 0.001
                factor_text = "× 0.001"
            elif actual_unit == "N/m":
                converted = initial_val * 0.000001
                factor_text = "× 0.000001"
            elif actual_unit == "N/mm":
                converted = initial_val
                factor_text = "× 1"
            elif actual_unit == "kN/mm":
                converted = initial_val * 1000.0
                factor_text = "× 1000"
            elif actual_unit == "kip/ft":
                converted = initial_val * 0.14594  # kip/ft to N/mm
                factor_text = "× 0.14594"
            elif actual_unit == "kip/in":
                converted = initial_val * 1.75127  # kip/in to N/mm
                factor_text = "× 1.75127"
            elif actual_unit == "lb/ft":
                converted = initial_val * 0.00014594  # lb/ft to N/mm
                factor_text = "× 0.00014594"
            elif actual_unit == "lb/in":
                converted = initial_val * 0.00175127  # lb/in to N/mm
                factor_text = "× 0.00175127"
            else:
                converted = initial_val
                factor_text = "unknown"

            if conversion_label:
                conversion_label.setText(
                    f"<b style='color: #5cb85c;'>✓ Will send to Calc: {converted:.8f} N/mm</b><br>"
                    f"<i>Conversion: {initial_val:.3f} {actual_unit} {factor_text} = {converted:.8f} N/mm</i>"
                )

    def populate_supports(self):
        """Populate supports tab."""
        if not hasattr(self.calc_obj, 'ListElements'):
            self.supports_layout.addWidget(QtWidgets.QLabel("No elements found"))
            return

        supports = [e for e in self.calc_obj.ListElements if 'Support' in e.Name or 'Suport' in e.Name or hasattr(e, 'FixTranslationX')]

        if not supports:
            self.supports_layout.addWidget(QtWidgets.QLabel("No supports found"))
            return

        table = QtWidgets.QTableWidget(len(supports), 7)
        table.setHorizontalHeaderLabels(["Support", "Type", "X", "Y", "Z", "RX", "RY", "RZ"])
        table.horizontalHeader().setStretchLastSection(True)

        for i, support in enumerate(supports):
            # Support name
            table.setItem(i, 0, QtWidgets.QTableWidgetItem(support.Name))

            # Determine type
            if hasattr(support, 'ObjectBase') and support.ObjectBase:
                obj, subs = support.ObjectBase[0]
                sub_name = subs[0] if subs else ""
                if 'Vertex' in sub_name:
                    sup_type = "Vertex"
                elif 'Edge' in sub_name:
                    sup_type = "Edge"
                else:
                    sup_type = "Unknown"
            else:
                sup_type = "Unknown"
            table.setItem(i, 1, QtWidgets.QTableWidgetItem(sup_type))

            # DOF restraints
            fix_x = "✓" if getattr(support, 'FixTranslationX', False) else ""
            fix_y = "✓" if getattr(support, 'FixTranslationY', False) else ""
            fix_z = "✓" if getattr(support, 'FixTranslationZ', False) else ""
            fix_rx = "✓" if getattr(support, 'FixRotationX', False) else ""
            fix_ry = "✓" if getattr(support, 'FixRotationY', False) else ""
            fix_rz = "✓" if getattr(support, 'FixRotationZ', False) else ""

            table.setItem(i, 2, QtWidgets.QTableWidgetItem(fix_x))
            table.setItem(i, 3, QtWidgets.QTableWidgetItem(fix_y))
            table.setItem(i, 4, QtWidgets.QTableWidgetItem(fix_z))
            table.setItem(i, 5, QtWidgets.QTableWidgetItem(fix_rx))
            table.setItem(i, 6, QtWidgets.QTableWidgetItem(fix_ry))
            table.setItem(i, 7, QtWidgets.QTableWidgetItem(fix_rz))

        self.supports_layout.addWidget(table)

    def populate_settings(self):
        """Populate analysis settings tab."""
        import FreeCAD

        # Add warning at top explaining how to change settings
        warning = QtWidgets.QLabel(
            "⚠️ <b>Self-weight can now be toggled below.</b> Other settings require closing this dialog."
        )
        warning.setWordWrap(True)
        warning.setStyleSheet("QLabel { background-color: #fff3cd; padding: 10px; margin-bottom: 10px; }")
        self.settings_layout.addRow("", warning)

        # Segments per member
        segments = getattr(self.calc_obj, 'SegmentsPerMember', 4)
        self.settings_layout.addRow("Segments per member:", QtWidgets.QLabel(f"<b>{segments}</b>"))
        FreeCAD.Console.PrintMessage(f"review_dialog: SegmentsPerMember = {segments}\n")

        # Mesh refinement
        refine = getattr(self.calc_obj, 'RefineAtSupports', False)
        refine_text = "Enabled ✓" if refine else "Disabled"
        self.settings_layout.addRow("Mesh refinement at supports:", QtWidgets.QLabel(f"<b>{refine_text}</b>"))
        FreeCAD.Console.PrintMessage(f"review_dialog: RefineAtSupports = {refine}\n")

        # Self-weight - NOW EDITABLE
        self_weight = getattr(self.calc_obj, 'SelfWeight', False)
        FreeCAD.Console.PrintMessage(f"review_dialog: SelfWeight = {self_weight}\n")

        # Create checkbox that user can toggle
        self.selfweight_checkbox = QtWidgets.QCheckBox("Include self-weight in analysis")
        self.selfweight_checkbox.setChecked(self_weight)
        self.selfweight_checkbox.setStyleSheet("QCheckBox { font-weight: bold; }")

        # Add explanatory label
        sw_explanation = QtWidgets.QLabel(
            "<i>Tip: Self-weight includes the dead load of all structural members based on material density.</i>"
        )
        sw_explanation.setWordWrap(True)

        self.settings_layout.addRow("Self-weight:", self.selfweight_checkbox)
        self.settings_layout.addRow("", sw_explanation)

    def accept(self):
        """User clicked OK - validate first, then apply unit corrections if any."""
        import FreeCAD

        # Save self-weight checkbox state to Calc object
        if hasattr(self, 'selfweight_checkbox'):
            new_selfweight = self.selfweight_checkbox.isChecked()
            self.calc_obj.SelfWeight = new_selfweight
            FreeCAD.Console.PrintMessage(f"review_dialog: Set SelfWeight = {new_selfweight}\n")

        # Validation: Check for potential issues
        issues = []

        # Check 1: Look for suspiciously large load values that might be unit errors
        for load_name, correction_data in self.unit_corrections.items():
            if 'initial_val' in correction_data:
                initial_val = correction_data['initial_val']
                correction = correction_data.get('correction')

                # If no correction selected but value seems large
                if correction is None:
                    if initial_val > 100:  # More than 100 N/mm is very large
                        issues.append(
                            f"⚠️ Load '{load_name}': {initial_val:.3f} N/mm seems very large.\n"
                            f"   Did you mean {initial_val:.3f} kN/m instead?\n"
                            f"   ({initial_val:.3f} N/mm = {initial_val * 1000:.0f} kN/m)"
                        )
                    elif initial_val < 0.00001 and initial_val != 0:  # Very small non-zero value
                        issues.append(
                            f"⚠️ Load '{load_name}': {initial_val:.8f} N/mm seems very small.\n"
                            f"   Check if units are correct."
                        )

        # Check 2: Verify self-weight is as intended (check the checkbox state)
        if hasattr(self, 'selfweight_checkbox'):
            self_weight = self.selfweight_checkbox.isChecked()
            if not self_weight:
                issues.append(
                    "ℹ️ Self-weight is NOT included.\n"
                    "   Tick the checkbox in the 'Analysis Settings' tab if you want to include it."
                )

        # Check 3: Verify members have materials and sections
        if hasattr(self.calc_obj, 'ListElements'):
            elements = [e for e in self.calc_obj.ListElements if 'Line' in e.Name or 'Wire' in e.Name or hasattr(e, 'SectionMember')]
            for element in elements:
                if not hasattr(element, 'MaterialMember') or not element.MaterialMember:
                    issues.append(f"❌ Member '{element.Name}' has no material assigned!")
                if not hasattr(element, 'SectionMember') or not element.SectionMember:
                    issues.append(f"❌ Member '{element.Name}' has no section assigned!")

        # If there are issues, show warning dialog
        if issues:
            msg = QtWidgets.QMessageBox(self)
            msg.setIcon(QtWidgets.QMessageBox.Warning)
            msg.setWindowTitle("Pre-Analysis Issues Detected")
            msg.setText(
                "<b>The following potential issues were detected:</b><br><br>"
                "Please review carefully before proceeding."
            )
            msg.setDetailedText("\n\n".join(issues))
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
            msg.setDefaultButton(QtWidgets.QMessageBox.Cancel)

            # Make detailed text visible by default
            for button in msg.buttons():
                if msg.buttonRole(button) == QtWidgets.QMessageBox.ActionRole:
                    button.click()

            result = msg.exec_()
            if result != QtWidgets.QMessageBox.Ok:
                FreeCAD.Console.PrintWarning("review_dialog: User cancelled due to validation issues\n")
                return  # Don't close dialog

            FreeCAD.Console.PrintWarning("review_dialog: User proceeded despite validation warnings\n")

        self.accepted = True

        # NOTE: Unit correction logic DISABLED as of 2025-12-26
        # The new unit system (m/kN with proper conversion functions in calc.py) handles units correctly.
        # If users have old loads with wrong values from before this fix, they should delete and recreate them.

        # Check if user requested any corrections and warn them
        for load_name, correction_data in self.unit_corrections.items():
            if 'correction' in correction_data and correction_data['correction'] is not None:
                actual_unit = correction_data['correction']
                FreeCAD.Console.PrintWarning(
                    f"review_dialog: Unit correction requested for '{load_name}' ({actual_unit}) but DISABLED.\n"
                    f"  The new unit system (Dec 2025) handles conversions automatically.\n"
                    f"  If the load value is incorrect, please DELETE the load and CREATE a new one.\n"
                )

        super().accept()

    def get_corrections(self):
        """Return dictionary of unit corrections made."""
        corrections = {}
        for load_name, correction_data in self.unit_corrections.items():
            if 'correction' in correction_data and correction_data['correction'] is not None:
                corrections[load_name] = correction_data['correction']
        return corrections
