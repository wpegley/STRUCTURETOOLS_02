import FreeCAD, App, FreeCADGui, Part, os

from freecad.StructureTools.suport import show_error_message, _set_shaded_display, SupportTaskPanel

ICONPATH = os.path.join(os.path.dirname(__file__), "resources")
SUPPORT_EDGE_COLOR = (0.0, 0.67, 0.0)


class SupportEdge:
    def __init__(self, obj, selection):
        obj.Proxy = self
        obj.addProperty("App::PropertyLinkSubList", "ObjectBase", "Base", "Object base")

        obj.addProperty("App::PropertyBool", "FixTranslationX", "Translation", "Nodal loading").FixTranslationX = True
        obj.addProperty("App::PropertyBool", "FixTranslationY", "Translation", "Nodal loading").FixTranslationY = True
        obj.addProperty("App::PropertyBool", "FixTranslationZ", "Translation", "Nodal loading").FixTranslationZ = True

        obj.addProperty("App::PropertyBool", "FixRotationX", "Rotation", "Nodal loading").FixRotationX = True
        obj.addProperty("App::PropertyBool", "FixRotationY", "Rotation", "Nodal loading").FixRotationY = True
        obj.addProperty("App::PropertyBool", "FixRotationZ", "Rotation", "Nodal loading").FixRotationZ = True

        obj.addProperty("App::PropertyFloat", "ScaleDraw", "Draw", "Scale from drawing").ScaleDraw = 1
        obj.addProperty("App::PropertyLength", "Distance", "Base", "Distance from start").Distance = 0

        obj.ObjectBase = [(selection[0], (selection[1],))]

        try:
            subelement = self.getSubelement(obj, selection[1])
            if hasattr(subelement, "Length"):
                obj.Distance = subelement.Length / 2
        except Exception:
            pass

    def getSubelement(self, obj, nameSubElement):
        if not hasattr(obj, "ObjectBase") or not obj.ObjectBase or not obj.ObjectBase[0]:
            return None
        base_obj = obj.ObjectBase[0][0]
        shape = getattr(base_obj, "Shape", None)
        if not shape:
            return None

        if "Edge" in nameSubElement:
            try:
                index = int(nameSubElement.split("Edge")[1]) - 1
            except Exception:
                return None
            if index < 0 or index >= len(shape.Edges):
                return None
            return shape.Edges[index]

        try:
            index = int(nameSubElement.split("Vertex")[1]) - 1
        except Exception:
            return None
        if index < 0 or index >= len(shape.Vertexes):
            return None
        return shape.Vertexes[index]

    def getPointOnEdge(self, edge, distance_mm):
        start = edge.Vertexes[0].Point
        end = edge.Vertexes[1].Point
        direction = end.sub(start)
        length = direction.Length
        if length <= 1e-6:
            return start
        distance_mm = max(0.0, min(distance_mm, length))
        direction = direction.multiply(distance_mm / length)
        return start.add(direction)

    def makeCone(self, obj, simples=False):
        radiusCone = 100
        heightCone = 200
        lengthPlate = 220
        heigthPlate = 20
        gap = 20

        cone = Part.makeCone(radiusCone * obj.ScaleDraw, 0, heightCone * obj.ScaleDraw)
        cone.translate(FreeCAD.Vector(0, 0, -heightCone * obj.ScaleDraw))
        box = Part.makeBox(lengthPlate * obj.ScaleDraw, lengthPlate * obj.ScaleDraw, heigthPlate * obj.ScaleDraw)
        box.translate(FreeCAD.Vector(-lengthPlate / 2 * obj.ScaleDraw, -lengthPlate / 2 * obj.ScaleDraw, (-heigthPlate - gap - heightCone) * obj.ScaleDraw))

        if simples:
            return cone
        return Part.makeCompound([cone, box])

    def makebox(self, obj, restricao=False):
        lenghtBox = 220
        heigthBox = 40
        minbox = 50

        if restricao:
            box = Part.makeBox(minbox * obj.ScaleDraw, minbox * obj.ScaleDraw, minbox * obj.ScaleDraw)
            box.translate(FreeCAD.Vector(-minbox / 2 * obj.ScaleDraw, -minbox / 2 * obj.ScaleDraw, -minbox * obj.ScaleDraw))
        else:
            box = Part.makeBox(lenghtBox * obj.ScaleDraw, lenghtBox * obj.ScaleDraw, heigthBox * obj.ScaleDraw)
            box.translate(FreeCAD.Vector(-lenghtBox / 2 * obj.ScaleDraw, -lenghtBox / 2 * obj.ScaleDraw, -heigthBox * obj.ScaleDraw))

        return box

    def execute(self, obj):
        if not hasattr(obj, "ObjectBase") or not obj.ObjectBase or not obj.ObjectBase[0][1]:
            obj.Shape = Part.Shape()
            return
        subelement = self.getSubelement(obj, obj.ObjectBase[0][1][0])
        if not hasattr(subelement, "Length"):
            obj.Shape = Part.Shape()
            return
        distance_mm = float(obj.Distance.getValueAs("mm"))
        point = self.getPointOnEdge(subelement, distance_mm)

        listSimbols = []
        if obj.FixTranslationX and obj.FixTranslationY and obj.FixTranslationZ and obj.FixRotationX and obj.FixRotationY and obj.FixRotationZ:
            box = self.makebox(obj)
            listSimbols.append(box)
        else:
            if obj.FixTranslationX and obj.FixTranslationY and obj.FixTranslationZ:
                cone = self.makeCone(obj, True)
                listSimbols.append(cone)
            else:
                if obj.FixTranslationX:
                    cone = self.makeCone(obj)
                    cone.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), 90)
                    listSimbols.append(cone)
                if obj.FixTranslationY:
                    cone = self.makeCone(obj)
                    cone.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), 90)
                    listSimbols.append(cone)
                if obj.FixTranslationZ:
                    cone = self.makeCone(obj)
                    listSimbols.append(cone)
            if obj.FixRotationX or obj.FixRotationY or obj.FixRotationZ:
                box = self.makebox(obj, True)
                listSimbols.append(box)

        simbol = Part.makeCompound(listSimbols)
        simbol.translate(point)

        obj.Shape = Part.makeCompound(listSimbols)
        obj.Placement.Base = simbol.Placement.Base
        _set_shaded_display(obj.ViewObject)
        obj.ViewObject.ShapeAppearance = (FreeCAD.Material(DiffuseColor=SUPPORT_EDGE_COLOR,AmbientColor=(0.00,0.00,0.00),SpecularColor=(0.00,0.00,0.00),EmissiveColor=(0.00,0.00,0.00),Shininess=(0.90),Transparency=(0.00),))
        obj.Label = "Support (Edge)"

    def onChanged(self, obj, Parameter):
        if Parameter in ("ObjectBase", "edgeLength", "Distance", "ScaleDraw", "FixTranslationX", "FixTranslationY", "FixTranslationZ", "FixRotationX", "FixRotationY", "FixRotationZ"):
            self.execute(obj)


class ViewProviderSupportEdge:
    def __init__(self, obj):
        obj.Proxy = self

    def getIcon(self):
        return os.path.join(ICONPATH, "icons/suport_edge.svg")


class CommandSupportEdge:
    def GetResources(self):
        return {
            "Pixmap": os.path.join(ICONPATH, "icons/suport_edge.svg"),
            "Accel": "Shift+E",
            "MenuText": "Support (Edge)",
            "ToolTip": "Adds a relocatable support on a member",
        }

    def Activated(self):
        selections = list(FreeCADGui.Selection.getSelectionEx())
        if not selections:
            show_error_message("Select a beam edge to add a support.")
            return

        if len(selections) == 1 and not selections[0].HasSubObjects:
            selected_obj = selections[0].Object
            if selected_obj and hasattr(selected_obj, "Distance") and hasattr(selected_obj, "ObjectBase"):
                panel = SupportTaskPanel(selected_obj, allow_distance=True)
                FreeCADGui.Control.showDialog(panel)
                return

        created = 0
        for selection in selections:
            if selection.HasSubObjects:
                for subSelectionname in selection.SubElementNames:
                    if "Edge" not in subSelectionname:
                        continue
                    doc = FreeCAD.ActiveDocument
                    obj = doc.addObject("Part::FeaturePython", "Support_Edge")
                    SupportEdge(obj, (selection.Object, subSelectionname))
                    ViewProviderSupportEdge(obj.ViewObject)
                    created += 1
            else:
                line = selection.Object
                edges = line.Shape.Edges
                for i in range(len(edges)):
                    doc = FreeCAD.ActiveDocument
                    obj = doc.addObject("Part::FeaturePython", "Support_Edge")
                    SupportEdge(obj, (selection.Object, "Edge" + str(i + 1)))
                    ViewProviderSupportEdge(obj.ViewObject)
                    created += 1

        if created == 0:
            show_error_message("Select a beam edge to add a support.")
            return

        FreeCAD.ActiveDocument.recompute()
        return

    def IsActive(self):
        return True


FreeCADGui.addCommand("support_edge", CommandSupportEdge())
