"""
Simple Pre-Analysis Review Dialog

Shows a summary of what will be analyzed with a simple confirmation.
No unit validation, no tabs, no complexity.
"""

import FreeCAD as App
from PySide import QtCore, QtWidgets


class SimpleReviewDialog(QtWidgets.QDialog):
    """Simple dialog for confirming analysis before calculation."""

    def __init__(self, calc_obj, parent=None):
        super().__init__(parent)
        self.calc_obj = calc_obj
        self.accepted = False

        self.setWindowTitle("Confirm Analysis")
        self.setMinimumWidth(600)
        self.setMinimumHeight(400)

        self.setup_ui()
        self.populate_data()

    def setup_ui(self):
        """Create the simple dialog UI."""
        layout = QtWidgets.QVBoxLayout(self)

        # Title
        title = QtWidgets.QLabel("<h2>Ready to Run Analysis</h2>")
        layout.addWidget(title)

        # Scroll area for content
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)

        content_widget = QtWidgets.QWidget()
        self.content_layout = QtWidgets.QVBoxLayout(content_widget)
        self.content_layout.setSpacing(15)

        scroll.setWidget(content_widget)
        layout.addWidget(scroll, stretch=1)

        # Buttons
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()

        cancel_btn = QtWidgets.QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        run_btn = QtWidgets.QPushButton("Run Analysis")
        run_btn.setDefault(True)
        run_btn.clicked.connect(self.accept_and_run)
        run_btn.setStyleSheet("font-weight: bold; padding: 8px 20px;")
        button_layout.addWidget(run_btn)

        layout.addLayout(button_layout)

    def populate_data(self):
        """Populate the dialog with analysis summary."""
        # Get data
        lines = [obj for obj in self.calc_obj.ListElements if "Line" in obj.Name or "Wire" in obj.Name]
        supports = [obj for obj in self.calc_obj.ListElements if "Suport" in obj.Name or "Support" in obj.Name]
        loads_dist = [obj for obj in self.calc_obj.ListElements if "Load_Distributed" in obj.Name]
        loads_point = [obj for obj in self.calc_obj.ListElements if "Load_Point" in obj.Name]

        # Unit info with better contrast
        unit_text = f"<b>Unit System:</b> {self.calc_obj.LengthUnit}, {self.calc_obj.ForceUnit}"
        unit_label = QtWidgets.QLabel(unit_text)
        unit_label.setStyleSheet("background: #1565c0; color: white; padding: 10px; border-radius: 4px; font-weight: bold;")
        self.content_layout.addWidget(unit_label)

        # Members section
        members_group = QtWidgets.QGroupBox(f"Members ({len(lines)})")
        members_layout = QtWidgets.QVBoxLayout()

        if lines:
            for line in lines[:5]:  # Show first 5
                material_name = line.MaterialMember.Label if hasattr(line, 'MaterialMember') and line.MaterialMember else "None"
                section_name = line.SectionMember.Label if hasattr(line, 'SectionMember') and line.SectionMember else "None"

                text = f"• {line.Label}: {material_name} / {section_name}"
                members_layout.addWidget(QtWidgets.QLabel(text))

            if len(lines) > 5:
                members_layout.addWidget(QtWidgets.QLabel(f"... and {len(lines) - 5} more"))
        else:
            members_layout.addWidget(QtWidgets.QLabel("<i>No members</i>"))

        members_group.setLayout(members_layout)
        self.content_layout.addWidget(members_group)

        # Supports section
        supports_group = QtWidgets.QGroupBox(f"Supports ({len(supports)})")
        supports_layout = QtWidgets.QVBoxLayout()

        if supports:
            for support in supports[:5]:
                fx = "✓" if getattr(support, "FixTranslationX", False) else "○"
                fy = "✓" if getattr(support, "FixTranslationY", False) else "○"
                fz = "✓" if getattr(support, "FixTranslationZ", False) else "○"

                text = f"• {support.Label}: X={fx} Y={fy} Z={fz}"
                supports_layout.addWidget(QtWidgets.QLabel(text))

            if len(supports) > 5:
                supports_layout.addWidget(QtWidgets.QLabel(f"... and {len(supports) - 5} more"))
        else:
            supports_layout.addWidget(QtWidgets.QLabel("<i>No supports - ANALYSIS WILL FAIL</i>"))

        supports_group.setLayout(supports_layout)
        self.content_layout.addWidget(supports_group)

        # Loads section
        total_loads = len(loads_dist) + len(loads_point)
        loads_group = QtWidgets.QGroupBox(f"Loads ({total_loads})")
        loads_layout = QtWidgets.QVBoxLayout()

        old_load_detected = False

        if loads_dist or loads_point:
            # Distributed loads
            for load in loads_dist[:5]:
                # Get raw stored value in N
                initial_n = float(load.InitialLoading.getValueAs('N')) if hasattr(load.InitialLoading, 'getValueAs') else float(load.InitialLoading)
                final_n = float(load.FinalLoading.getValueAs('N')) if hasattr(load.FinalLoading, 'getValueAs') else float(load.FinalLoading)

                # NEW SYSTEM: Property value should be ~10000 N (representing 10 kN/m)
                # OLD SYSTEM: Property value was ~10000000 N (broken conversion)
                # Detect old loads: if value > 100000 N, it's likely an old load
                if initial_n > 100000 or final_n > 100000:
                    old_load_detected = True

                # Convert to kN/m for display: N → kN/m = N / 1000
                initial_kn_m = initial_n / 1000.0
                final_kn_m = final_n / 1000.0

                text = f"• {load.Label}: {initial_kn_m:.2f} to {final_kn_m:.2f} kN/m {load.GlobalDirection}"
                label = QtWidgets.QLabel(text)
                if initial_n > 100000 or final_n > 100000:
                    label.setStyleSheet("color: red; font-weight: bold;")
                loads_layout.addWidget(label)

            # Point loads
            for load in loads_point[:5]:
                force = float(load.PointLoading.getValueAs(self.calc_obj.ForceUnit)) if hasattr(load.PointLoading, 'getValueAs') else float(load.PointLoading)
                text = f"• {load.Label}: {force:.2f} {self.calc_obj.ForceUnit} {load.GlobalDirection}"
                loads_layout.addWidget(QtWidgets.QLabel(text))

            if total_loads > 5:
                loads_layout.addWidget(QtWidgets.QLabel(f"... and {total_loads - 5} more"))
        else:
            loads_layout.addWidget(QtWidgets.QLabel("<i>No loads defined</i>"))

        loads_group.setLayout(loads_layout)
        self.content_layout.addWidget(loads_group)

        # OLD LOAD INFO - show message if old loads were detected (but they'll be auto-fixed)
        if old_load_detected:
            info_box = QtWidgets.QLabel(
                "ℹ️ <b>OLD LOAD DETECTED</b><br><br>"
                "Load values shown in <span style='color: #ff0000;'><b>RED</b></span> are from the OLD unit system.<br>"
                "Don't worry - these will be <b>automatically corrected</b> when you run the analysis!<br><br>"
                "The system will divide old values by 1000 to fix them.<br>"
                "Example: 3000000 N → 3000 N (representing 3 kN/m)<br><br>"
                "After analysis, your load values will be permanently updated."
            )
            info_box.setStyleSheet(
                "background: #1976d2; color: white; padding: 15px; "
                "border: 3px solid #0d47a1; border-radius: 5px; "
                "font-size: 10pt;"
            )
            info_box.setWordWrap(True)
            self.content_layout.addWidget(info_box)

        # Analysis settings
        settings_group = QtWidgets.QGroupBox("Analysis Settings")
        settings_layout = QtWidgets.QVBoxLayout()

        segments = self.calc_obj.SegmentsPerMember if hasattr(self.calc_obj, 'SegmentsPerMember') else 4
        refine = self.calc_obj.RefineAtSupports if hasattr(self.calc_obj, 'RefineAtSupports') else True

        settings_layout.addWidget(QtWidgets.QLabel(f"• Segments per member: {segments}"))
        settings_layout.addWidget(QtWidgets.QLabel(f"• Refine at supports: {'Yes' if refine else 'No'}"))

        settings_group.setLayout(settings_layout)
        self.content_layout.addWidget(settings_group)

        # Add stretch to push everything to top
        self.content_layout.addStretch()

    def accept_and_run(self):
        """User clicked Run Analysis."""
        # Self-weight feature removed - always disabled by default
        self.accepted = True
        self.accept()

    def get_corrections(self):
        """Return empty dict (no corrections in simple dialog)."""
        return {}
