"""
anaStruct Solver Adapter for StructureTools

This module provides an alternative solver using anaStruct instead of PyNite.
anaStruct properly handles fixed supports and rotational constraints.

License Note: anaStruct is GPL-3.0 licensed. Use only for personal projects.
"""

import FreeCAD as App
from anastruct import SystemElements
import numpy as np

logger = App.Console.PrintLog


def analyze_with_anastruct(calc_obj):
    """
    Run structural analysis using anaStruct instead of PyNite.

    Args:
        calc_obj: FreeCAD StructureTools calculation object

    Returns:
        dict: Analysis results compatible with StructureTools display
    """

    logger("=" * 80 + "\n")
    logger("USING ANASTRUCT SOLVER (accurate fixed support handling)\n")
    logger("=" * 80 + "\n")

    # Get unit settings
    unit_length = calc_obj.LengthUnit  # Should be 'm'
    unit_force = calc_obj.ForceUnit    # Should be 'kN'

    logger(f"Units: {unit_length}, {unit_force}\n")

    # Extract geometry from FreeCAD objects
    lines = [obj for obj in calc_obj.ListElements if "Line" in obj.Name or "Wire" in obj.Name]
    supports = [obj for obj in calc_obj.ListElements if "Suport" in obj.Name or "Support" in obj.Name]
    loads_dist = [obj for obj in calc_obj.ListElements if "Load_Distributed" in obj.Name]
    loads_point = [obj for obj in calc_obj.ListElements if "Load_Point" in obj.Name]

    if not lines:
        logger("ERROR: No structural members found\n")
        return None

    logger(f"Found {len(lines)} structural member(s)\n")

    if len(lines) > 1:
        logger("WARNING: anaStruct adapter currently supports single-beam analysis only\n")
        logger(f"Using only the first member: {lines[0].Label}\n")

    # Get first line (beam)
    line = lines[0]
    logger(f"Analyzing beam: {line.Label}\n")

    # Get material properties
    if not hasattr(line, 'MaterialMember') or not line.MaterialMember:
        logger("ERROR: No material assigned to member\n")
        return None

    material = line.MaterialMember
    # Young's modulus - FreeCAD stores in Pa (base SI unit)
    # Get in Pa, then convert to kN/m²: 1 Pa = 0.001 kN/m²
    E_pa = float(material.ModulusElasticity.getValueAs('Pa'))
    E_kn_m2 = E_pa / 1000.0  # Pa → kN/m²

    logger(f"Material: E = {E_pa/1e9:.1f} GPa = {E_kn_m2:.0f} kN/m²\n")

    # Get section properties
    if not hasattr(line, 'SectionMember') or not line.SectionMember:
        logger("ERROR: No section assigned to member\n")
        return None

    section = line.SectionMember

    # anaStruct uses EI directly (not separate E and I)
    # Get moment of inertia (for vertical loads, use Iz in FreeCAD terms)
    # Try different property names (MomentInertiaZ, Iz)
    if hasattr(section, 'MomentInertiaZ'):
        Iz_mm4 = float(App.Units.Quantity(section.MomentInertiaZ, 'mm^4').getValueAs('mm^4'))
    elif hasattr(section, 'Iz'):
        Iz_mm4 = float(App.Units.Quantity(section.Iz, 'mm^4').getValueAs('mm^4'))
    else:
        logger("ERROR: Section has no Iz or MomentInertiaZ property\n")
        return None

    Iz_m4 = Iz_mm4 / 1e12  # Convert mm⁴ to m⁴
    EI = E_kn_m2 * Iz_m4  # kN·m²

    logger(f"Section: Iz = {Iz_mm4:.2e} mm⁴ = {Iz_m4:.2e} m⁴\n")
    logger(f"Flexural rigidity: EI = {EI:.2f} kN·m²\n")

    # Get geometry (assuming simple beam along X-axis)
    vertices = line.Shape.Vertexes
    if len(vertices) != 2:
        logger(f"ERROR: Expected 2 vertices, found {len(vertices)}\n")
        return None

    p1 = vertices[0].Point
    p2 = vertices[1].Point

    # Convert to meters
    x1 = p1.x / 1000.0
    y1 = p1.z / 1000.0  # FreeCAD Z → anaStruct Y (vertical)
    x2 = p2.x / 1000.0
    y2 = p2.z / 1000.0

    L = ((x2 - x1)**2 + (y2 - y1)**2)**0.5

    logger(f"Beam: ({x1:.3f}, {y1:.3f}) to ({x2:.3f}, {y2:.3f}), Length = {L:.3f} m\n")

    # Create anaStruct system (EA is not critical for bending analysis)
    # Get cross-sectional area
    A_m2 = float(section.AreaSection.getValueAs('m^2'))  # Convert to m²
    EA = E_kn_m2 * A_m2  # kN

    logger(f"Section: A = {A_m2*1e4:.2f} cm²\n")
    logger(f"Axial rigidity: EA = {EA:.0f} kN\n")

    ss = SystemElements(EA=EA, EI=EI)

    # Add element
    ss.add_element(location=[[x1, y1], [x2, y2]])

    logger(f"Added element from node 1 to node 2\n")

    # Process supports
    if not supports:
        logger("WARNING: No supports found - model is unconstrained\n")
        logger("At least two supports are required for a valid analysis\n")
        return None

    logger(f"Found {len(supports)} support(s)\n")
    support_nodes = []
    for support in supports:
        # Get support location
        loc = None

        # Try AnchorPoint first (if explicitly set)
        if hasattr(support, 'AnchorPoint'):
            ap = support.AnchorPoint
            try:
                if ap and (abs(ap.x) + abs(ap.y) + abs(ap.z)) > 0:
                    loc = ap
            except Exception:
                pass

        # Try ObjectBase (list of tuples)
        if loc is None and hasattr(support, 'ObjectBase') and support.ObjectBase:
            try:
                obj_base = support.ObjectBase

                # ObjectBase is typically a list: [(object, (subname,))]
                if isinstance(obj_base, list) and len(obj_base) > 0:
                    obj_base = obj_base[0]

                # Handle tuple (object, subnames)
                if isinstance(obj_base, (tuple, list)) and len(obj_base) >= 2:
                    base_obj = obj_base[0]
                    sub_names = obj_base[1]

                    # Check if there's a specific vertex subname
                    if sub_names and len(sub_names) > 0:
                        sub_name = sub_names[0]
                        if 'Vertex' in sub_name and hasattr(base_obj, 'Shape'):
                            # Extract vertex index (e.g., "Vertex1" -> 0)
                            vertex_idx = int(sub_name.replace('Vertex', '')) - 1
                            if 0 <= vertex_idx < len(base_obj.Shape.Vertexes):
                                loc = base_obj.Shape.Vertexes[vertex_idx].Point
                                logger(f"  ObjectBase: using {sub_name} (index {vertex_idx})\n")

                    # If no subname or not found, use first vertex
                    if loc is None and hasattr(base_obj, 'Shape') and hasattr(base_obj.Shape, 'Vertexes'):
                        if len(base_obj.Shape.Vertexes) > 0:
                            loc = base_obj.Shape.Vertexes[0].Point
                            logger(f"  ObjectBase: using first vertex (no subname)\n")
                elif isinstance(obj_base, (tuple, list)) and len(obj_base) >= 1:
                    # Only base object, no subnames
                    base_obj = obj_base[0]
                    if hasattr(base_obj, 'Shape') and hasattr(base_obj.Shape, 'Vertexes'):
                        if len(base_obj.Shape.Vertexes) > 0:
                            loc = base_obj.Shape.Vertexes[0].Point
                            logger(f"  ObjectBase: using first vertex (tuple)\n")
                else:
                    # Single object
                    if hasattr(obj_base, 'Shape') and hasattr(obj_base.Shape, 'Vertexes'):
                        if len(obj_base.Shape.Vertexes) > 0:
                            loc = obj_base.Shape.Vertexes[0].Point
                            logger(f"  ObjectBase: using first vertex (single)\n")
            except Exception as e:
                logger(f"WARNING: Could not get location from ObjectBase for support '{support.Label}': {e}\n")

        # Fallback to Placement
        if loc is None and hasattr(support, 'Placement'):
            loc = support.Placement.Base

        if loc is None:
            logger(f"ERROR: Could not determine location for support '{support.Label}'\n")
            continue

        sx = loc.x / 1000.0
        sy = loc.z / 1000.0  # FreeCAD Z → anaStruct Y

        logger(f"Support '{support.Label}' location: ({sx:.3f}, {sy:.3f})\n")

        # Determine which node (1 or 2) is closest
        dist1 = ((sx - x1)**2 + (sy - y1)**2)**0.5
        dist2 = ((sx - x2)**2 + (sy - y2)**2)**0.5

        logger(f"  Distance to node 1 ({x1:.3f}, {y1:.3f}): {dist1:.3f} m\n")
        logger(f"  Distance to node 2 ({x2:.3f}, {y2:.3f}): {dist2:.3f} m\n")

        node_id = 1 if dist1 < dist2 else 2

        # Check fixity flags
        fx = getattr(support, "FixTranslationX", True)
        fy = getattr(support, "FixTranslationY", True)
        fz = getattr(support, "FixTranslationZ", True)
        rx = getattr(support, "FixRotationX", True)
        ry = getattr(support, "FixRotationY", True)
        rz = getattr(support, "FixRotationZ", True)

        logger(f"Support '{support.Label}' at node {node_id}: Trans({fx},{fy},{fz}) Rot({rx},{ry},{rz})\n")

        # Determine support type based on rotational constraints
        # For 2D beam in XY plane, RZ (rotation about Z-axis) controls moment resistance
        if ry:  # FreeCAD RotY controls out-of-plane bending
            # Fixed support (prevents rotation)
            logger(f"  → FIXED support (rotation prevented)\n")
            support_type = "fixed"
        else:
            # Hinged/roller support (allows rotation)
            logger(f"  → HINGED support (rotation free)\n")
            support_type = "hinged"

        support_nodes.append((node_id, support_type))

    # Apply supports to anaStruct
    # Collect all fixed and hinged nodes
    fixed_nodes = [n for n, t in support_nodes if t == "fixed"]
    hinged_nodes = [n for n, t in support_nodes if t == "hinged"]

    if fixed_nodes:
        ss.add_support_fixed(fixed_nodes)
        logger(f"Applied FIXED supports to nodes: {fixed_nodes}\n")

    if hinged_nodes:
        ss.add_support_hinged(hinged_nodes)
        logger(f"Applied HINGED supports to nodes: {hinged_nodes}\n")

    # Validate we have supports
    if not fixed_nodes and not hinged_nodes:
        logger("ERROR: No valid supports could be applied\n")
        return None

    # Process loads
    if not loads_dist:
        logger("WARNING: No distributed loads found\n")
    else:
        logger(f"Found {len(loads_dist)} distributed load(s)\n")

    for load in loads_dist:
        try:
            # Get load magnitude
            # StructureTools stores distributed loads as force in N (not N/m)
            # The value represents force per meter: 3000 N means 3 kN/m
            if hasattr(load, 'InitialLoading'):
                if hasattr(load.InitialLoading, 'getValueAs'):
                    initial_n = float(load.InitialLoading.getValueAs('N'))
                else:
                    initial_n = float(load.InitialLoading)
            else:
                logger(f"WARNING: Load '{load.Label}' has no InitialLoading property\n")
                continue

            if hasattr(load, 'FinalLoading'):
                if hasattr(load.FinalLoading, 'getValueAs'):
                    final_n = float(load.FinalLoading.getValueAs('N'))
                else:
                    final_n = float(load.FinalLoading)
            else:
                logger(f"WARNING: Load '{load.Label}' has no FinalLoading property\n")
                continue

            # Convert N to kN/m (value in N represents kN/m magnitude)
            w_start = initial_n / 1000.0  # N → kN/m
            w_end = final_n / 1000.0      # N → kN/m

            # Get direction
            direction = getattr(load, 'GlobalDirection', '-Z')

            # Map FreeCAD direction to anaStruct direction
            # FreeCAD: -Z is downward (gravity)
            # anaStruct: -Y is downward
            if direction == "-Z":
                # Downward load (negative in anaStruct)
                w_start = -abs(w_start)
                w_end = -abs(w_end)
            elif direction == "+Z":
                # Upward load (positive in anaStruct)
                w_start = abs(w_start)
                w_end = abs(w_end)

            logger(f"Distributed load '{load.Label}': {w_start:.2f} to {w_end:.2f} kN/m (direction: {direction})\n")

            # Apply uniform load to element 1
            if abs(w_start - w_end) < 1e-6:
                # Uniform load
                ss.q_load(q=w_start, element_id=1)
                logger(f"  Applied as uniform load: q={w_start:.2f} kN/m\n")
            else:
                # Linearly varying load (not yet implemented in this adapter)
                logger(f"  WARNING: Linearly varying loads not yet supported in anaStruct adapter\n")
                logger(f"  Using average value: q={(w_start + w_end)/2:.2f} kN/m\n")
                ss.q_load(q=(w_start + w_end)/2, element_id=1)

        except Exception as e:
            logger(f"ERROR: Failed to process load '{load.Label}': {e}\n")
            continue

    # Solve
    logger("\n" + "=" * 80 + "\n")
    logger("Running anaStruct analysis...\n")
    logger("=" * 80 + "\n")

    try:
        ss.solve()
        logger("✓ Analysis completed successfully\n")
    except Exception as e:
        logger(f"✗ Analysis FAILED: {e}\n")
        return None

    # Extract results
    logger("\n" + "=" * 80 + "\n")
    logger("RESULTS\n")
    logger("=" * 80 + "\n")

    # Get deflection (at center of beam)
    element_results = ss.get_element_results(element_id=1)

    # anaStruct deflection: wmin = most negative (downward), wmax = most positive (upward)
    # For downward loads, wmin has the largest magnitude
    wmin = element_results['wmin']  # Most negative deflection (m)
    wmax = element_results['wmax']  # Most positive deflection (m)

    # Maximum deflection magnitude
    max_deflection_m = max(abs(wmin), abs(wmax))
    max_deflection_mm = max_deflection_m * 1000.0  # Convert to mm

    logger(f"Deflection range: {wmin*1000:.3f} mm to {wmax*1000:.3f} mm\n")
    logger(f"Maximum deflection: {max_deflection_mm:.3f} mm\n")

    # Get node reactions
    # anaStruct returns: Fx (horizontal), Fy (vertical), Tz (moment about Z-axis)
    node1_results = ss.get_node_results_system(node_id=1)
    node2_results = ss.get_node_results_system(node_id=2)

    # anaStruct coordinate system: X=horizontal, Y=vertical (up positive), Z=out of plane
    # Moments: Tz = rotation about Z-axis (bending in XY plane)
    M_left = node1_results.get('Tz', 0)  # Moment at left support (kN·m)
    M_right = node2_results.get('Tz', 0)  # Moment at right support (kN·m)

    # Vertical reactions (Fy in anaStruct)
    R_left = node1_results.get('Fy', 0)  # Vertical reaction at left (kN)
    R_right = node2_results.get('Fy', 0)  # Vertical reaction at right (kN)

    logger(f"\nReactions:\n")
    logger(f"  Left support:  V = {R_left:.2f} kN, M = {M_left:.2f} kN·m\n")
    logger(f"  Right support: V = {R_right:.2f} kN, M = {M_right:.2f} kN·m\n")

    # Extract diagram data from anaStruct element
    elem = ss.element_map[1]

    # anaStruct provides numpy arrays with diagram values
    # Convert to format expected by StructureTools: "x1,x2,x3;y1,y2,y3"
    num_points = len(elem.bending_moment)

    # X positions along beam (from 0 to L)
    x_positions = [L * i / (num_points - 1) for i in range(num_points)]

    # Bending moment (kN·m) - anaStruct returns in kN·m
    moment_values = elem.bending_moment.tolist()

    # Shear force (kN) - anaStruct returns in kN
    shear_values = elem.shear_force.tolist()

    # Deflection (m) - convert to mm for StructureTools
    deflection_values = [v * 1000.0 for v in elem.deflection.tolist()]

    # Format as comma-separated strings with x;y separator
    moment_str = ','.join(str(x) for x in x_positions) + ';' + ','.join(str(m) for m in moment_values)
    shear_str = ','.join(str(x) for x in x_positions) + ';' + ','.join(str(s) for s in shear_values)
    deflection_str = ','.join(str(x) for x in x_positions) + ';' + ','.join(str(d) for d in deflection_values)

    logger(f"\nDiagram data extracted: {num_points} points along beam\n")
    logger(f"  Moment range: {min(moment_values):.3f} to {max(moment_values):.3f} kN·m\n")
    logger(f"  Shear range: {min(shear_values):.3f} to {max(shear_values):.3f} kN\n")
    logger(f"  Deflection range: {min(deflection_values):.3f} to {max(deflection_values):.3f} mm\n")

    # Package results for StructureTools
    results = {
        'max_deflection_mm': max_deflection_mm,
        'M_left': M_left,
        'M_right': M_right,
        'R_left': R_left,
        'R_right': R_right,
        'element_results': element_results,
        'system': ss,  # Full anaStruct SystemElements object for detailed results
        'beam_start': (x1, y1),
        'beam_end': (x2, y2),
        'beam_length': L,
        'node1_results': node1_results,
        'node2_results': node2_results,
        'solver': 'anaStruct',
        # Diagram data in StructureTools format
        'moment_diagram': moment_str,
        'shear_diagram': shear_str,
        'deflection_diagram': deflection_str,
        'min_moment': min(moment_values),
        'max_moment': max(moment_values),
        'min_shear': min(shear_values),
        'max_shear': max(shear_values),
        'min_deflection': min(deflection_values),
        'max_deflection': max(deflection_values)
    }

    logger("\n" + "=" * 80 + "\n")
    logger("anaStruct analysis complete\n")
    logger("=" * 80 + "\n\n")

    return results


if __name__ == "__main__":
    # Quick test
    print("anaStruct solver adapter loaded successfully")
    print("GPL-3.0 licensed - for personal use only")
