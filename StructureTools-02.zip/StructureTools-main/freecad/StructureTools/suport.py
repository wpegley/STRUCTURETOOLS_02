import os
import FreeCAD
import App
import FreeCADGui
import Part
from PySide import QtWidgets

from .ui_helpers import show_error_message
from . import logger

ICONPATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))
SUPPORT_NODE_COLOR = (1.0, 0.0, 0.0)

def _set_shaded_display(view_object):
    if not view_object:
        return
    if hasattr(view_object, "DisplayMode") and view_object.DisplayMode:
        if "Shaded" in view_object.DisplayMode:
            view_object.DisplayMode = "Shaded"


class Suport:
    def __init__(self, obj, selection):
        obj.Proxy = self
        obj.addProperty("App::PropertyLinkSubList", "ObjectBase", "Base", "Object base")

        obj.addProperty("App::PropertyBool", "FixTranslationX", "Translation", "Nodal loading").FixTranslationX = True
        obj.addProperty("App::PropertyBool", "FixTranslationY", "Translation", "Nodal loading").FixTranslationY = True
        obj.addProperty("App::PropertyBool", "FixTranslationZ", "Translation", "Nodal loading").FixTranslationZ = True

        obj.addProperty("App::PropertyBool", "FixRotationX", "Rotation", "Nodal loading").FixRotationX = True
        obj.addProperty("App::PropertyBool", "FixRotationY", "Rotation", "Nodal loading").FixRotationY = True
        obj.addProperty("App::PropertyBool", "FixRotationZ", "Rotation", "Nodal loading").FixRotationZ = True
        
        obj.addProperty("App::PropertyFloat", "ScaleDraw", "Draw", "Scale from drawing").ScaleDraw = 1
        
        obj.ObjectBase = [(selection[0], (selection[1],))]
    
    # Desenha carregamento pontual
    def drawNodeLoad(self, obj, vertex):
        pass
    
    # Retorna o subelemento asociado
    def getSubelement(self, obj, nameSubElement):
        if not hasattr(obj, "ObjectBase") or not obj.ObjectBase or not obj.ObjectBase[0]:
            return None
        base_obj = obj.ObjectBase[0][0]
        shape = getattr(base_obj, "Shape", None)
        if not shape:
            return None

        if "Edge" in nameSubElement:
            try:
                index = int(nameSubElement.split("Edge")[1]) - 1
            except Exception:
                return None
            if index < 0 or index >= len(shape.Edges):
                return None
            return shape.Edges[index]

        try:
            index = int(nameSubElement.split("Vertex")[1]) - 1
        except Exception:
            return None
        if index < 0 or index >= len(shape.Vertexes):
            return None
        return shape.Vertexes[index]

    # Desenha a forma do cone com a base quadrada
    def makeCone(self, obj, simples = False):
        radiusCone = 100
        heightCone = 200
        lengthPlate = 220
        heigthPlate = 20
        gap = 20
        

        cone = Part.makeCone(radiusCone * obj.ScaleDraw , 0, heightCone * obj.ScaleDraw )
        cone.translate(FreeCAD.Vector(0,0, -heightCone * obj.ScaleDraw))
        box = Part.makeBox(lengthPlate * obj.ScaleDraw, lengthPlate * obj.ScaleDraw, heigthPlate * obj.ScaleDraw) 
        box.translate(FreeCAD.Vector(-lengthPlate/2 * obj.ScaleDraw, -lengthPlate/2 * obj.ScaleDraw, (-heigthPlate - gap - heightCone )* obj.ScaleDraw))
        
        if simples:
            return cone
        else:
            return Part.makeCompound([cone, box])
    
    # Desenha o simbolo do engaste ou restrição de rotação em algum eixo no caso de pinos
    def makebox(self, obj, restricao = False):
        lenghtBox = 220
        heigthBox = 40
        minbox = 50

        if restricao:
            box = Part.makeBox(minbox * obj.ScaleDraw, minbox * obj.ScaleDraw, minbox * obj.ScaleDraw)
            box.translate(FreeCAD.Vector(-minbox/2 * obj.ScaleDraw, -minbox/2 * obj.ScaleDraw, - minbox * obj.ScaleDraw))
        else:
            box = Part.makeBox(lenghtBox * obj.ScaleDraw, lenghtBox * obj.ScaleDraw, heigthBox * obj.ScaleDraw)
            box.translate(FreeCAD.Vector(-lenghtBox/2 * obj.ScaleDraw, -lenghtBox/2 * obj.ScaleDraw, - heigthBox * obj.ScaleDraw))

        return box
    
    def execute(self, obj):
        if not hasattr(obj, "ObjectBase") or not obj.ObjectBase or not obj.ObjectBase[0][1]:
            obj.Shape = Part.Shape()
            return
        subelement = self.getSubelement(obj, obj.ObjectBase[0][1][0])
        if not subelement:
            obj.Shape = Part.Shape()
            return
        
        listSimbols = []
        
        # Caso for um engaste
        if obj.FixTranslationX and obj.FixTranslationY and obj.FixTranslationZ and obj.FixRotationX and obj.FixRotationY and obj.FixRotationZ:
            box = self.makebox(obj)
            listSimbols.append(box)
            
        else:

            # Caso seja um pino   
            if obj.FixTranslationX and obj.FixTranslationY and obj.FixTranslationZ:
                cone = self.makeCone(obj, True)
                listSimbols.append(cone)
                
            else:
                
                if obj.FixTranslationX:
                    cone = self.makeCone(obj)
                    cone.rotate(FreeCAD.Vector(0,0,0), FreeCAD.Vector(0,1,0), 90)
                    listSimbols.append(cone)
                
                if obj.FixTranslationY:
                    cone = self.makeCone(obj)
                    cone.rotate(FreeCAD.Vector(0,0,0), FreeCAD.Vector(1,0,0), 90)
                    listSimbols.append(cone)
                
                if obj.FixTranslationZ:
                    cone = self.makeCone(obj)
                    # cone.rotate(FreeCAD.Vector(0,0,0), FreeCAD.Vector(1,0,0), 90)
                    listSimbols.append(cone)
            
            if obj.FixRotationX or obj.FixRotationY or obj.FixRotationZ:
                box = self.makebox(obj, True)
                listSimbols.append(box)

        simbol = Part.makeCompound(listSimbols)
        simbol.translate(subelement.Point)

        obj.Shape = Part.makeCompound(listSimbols)
        obj.Placement.Base = simbol.Placement.Base
        _set_shaded_display(obj.ViewObject)
        obj.ViewObject.ShapeAppearance = (FreeCAD.Material(DiffuseColor=SUPPORT_NODE_COLOR,AmbientColor=(0.00,0.00,0.00),SpecularColor=(0.00,0.00,0.00),EmissiveColor=(0.00,0.00,0.00),Shininess=(0.90),Transparency=(0.00),))
        obj.Label = 'Support'
        
        
       


    def onChanged(self, obj, Parameter):
        if Parameter in ("ObjectBase", "ScaleDraw", "FixTranslationX", "FixTranslationY", "FixTranslationZ", "FixRotationX", "FixRotationY", "FixRotationZ"):
            self.execute(obj)


class SupportTaskPanel:
    def __init__(self, obj, allow_distance):
        self.obj = obj
        self.allow_distance = allow_distance
        self.form = QtWidgets.QWidget()
        self.form.setWindowTitle("Support")

        layout = QtWidgets.QVBoxLayout(self.form)
        layout.setContentsMargins(8, 8, 8, 8)

        self.scale_spin = QtWidgets.QDoubleSpinBox()
        self.scale_spin.setRange(1e-6, 1e6)
        self.scale_spin.setDecimals(6)
        self.scale_spin.setSingleStep(0.1)
        self.scale_spin.setValue(float(getattr(obj, "ScaleDraw", 1)))
        layout.addWidget(QtWidgets.QLabel("Draw scale"))
        layout.addWidget(self.scale_spin)

        if self.allow_distance and hasattr(obj, "Distance"):
            self.distance_spin = QtWidgets.QDoubleSpinBox()
            self.distance_spin.setRange(0.0, 1e9)
            self.distance_spin.setDecimals(6)
            self.distance_spin.setSingleStep(10)
            self.distance_spin.setValue(float(obj.Distance.getValueAs("mm")))
            layout.addWidget(QtWidgets.QLabel("Distance from start (mm)"))
            layout.addWidget(self.distance_spin)
        else:
            self.distance_spin = None

        layout.addWidget(QtWidgets.QLabel("Fix translations"))
        self.fix_tx = QtWidgets.QCheckBox("X")
        self.fix_ty = QtWidgets.QCheckBox("Y")
        self.fix_tz = QtWidgets.QCheckBox("Z")
        row_t = QtWidgets.QHBoxLayout()
        row_t.addWidget(self.fix_tx)
        row_t.addWidget(self.fix_ty)
        row_t.addWidget(self.fix_tz)
        row_t.addStretch(1)
        layout.addLayout(row_t)

        layout.addWidget(QtWidgets.QLabel("Fix rotations"))
        self.fix_rx = QtWidgets.QCheckBox("X")
        self.fix_ry = QtWidgets.QCheckBox("Y")
        self.fix_rz = QtWidgets.QCheckBox("Z")
        row_r = QtWidgets.QHBoxLayout()
        row_r.addWidget(self.fix_rx)
        row_r.addWidget(self.fix_ry)
        row_r.addWidget(self.fix_rz)
        row_r.addStretch(1)
        layout.addLayout(row_r)

        self._load_from_object()
        self.scale_spin.valueChanged.connect(self._on_scale_changed)
        if self.distance_spin:
            self.distance_spin.valueChanged.connect(self._on_distance_changed)
        self.fix_tx.toggled.connect(self._on_fix_changed)
        self.fix_ty.toggled.connect(self._on_fix_changed)
        self.fix_tz.toggled.connect(self._on_fix_changed)
        self.fix_rx.toggled.connect(self._on_fix_changed)
        self.fix_ry.toggled.connect(self._on_fix_changed)
        self.fix_rz.toggled.connect(self._on_fix_changed)

    def getStandardButtons(self):
        return QtWidgets.QDialogButtonBox.Close

    def accept(self):
        FreeCADGui.Control.closeDialog()
        return True

    def reject(self):
        FreeCADGui.Control.closeDialog()
        return True

    def _load_from_object(self):
        self.fix_tx.setChecked(bool(getattr(self.obj, "FixTranslationX", False)))
        self.fix_ty.setChecked(bool(getattr(self.obj, "FixTranslationY", False)))
        self.fix_tz.setChecked(bool(getattr(self.obj, "FixTranslationZ", False)))
        self.fix_rx.setChecked(bool(getattr(self.obj, "FixRotationX", False)))
        self.fix_ry.setChecked(bool(getattr(self.obj, "FixRotationY", False)))
        self.fix_rz.setChecked(bool(getattr(self.obj, "FixRotationZ", False)))

    def _recompute(self):
        try:
            FreeCAD.ActiveDocument.recompute()
        except Exception:
            pass

    def _on_scale_changed(self, value):
        self.obj.ScaleDraw = float(value)
        self._recompute()

    def _on_distance_changed(self, value):
        if not hasattr(self.obj, "Distance"):
            return
        self.obj.Distance = FreeCAD.Units.Quantity(value, "mm")
        self._recompute()

    def _on_fix_changed(self, _checked):
        self.obj.FixTranslationX = self.fix_tx.isChecked()
        self.obj.FixTranslationY = self.fix_ty.isChecked()
        self.obj.FixTranslationZ = self.fix_tz.isChecked()
        self.obj.FixRotationX = self.fix_rx.isChecked()
        self.obj.FixRotationY = self.fix_ry.isChecked()
        self.obj.FixRotationZ = self.fix_rz.isChecked()
        self._recompute()
    

class ViewProviderSuport:
    def __init__(self, obj):
        obj.Proxy = self
    

    def getIcon(self):
        return """
/* XPM */
static char * suport_xpm[] = {
"32 32 148 2",
"  	c None",
". 	c #000B00",
"+ 	c #001600",
"@ 	c #000900",
"# 	c #008800",
"$ 	c #0E950E",
"% 	c #000A00",
"& 	c #005300",
"* 	c #00AB00",
"= 	c #44CE50",
"- 	c #005200",
"; 	c #001900",
"> 	c #00A800",
", 	c #4ACA65",
"' 	c #2EC431",
") 	c #001A00",
"! 	c #008D00",
"~ 	c #38BD58",
"{ 	c #58D66E",
"] 	c #119A11",
"^ 	c #000700",
"/ 	c #005900",
"( 	c #28B449",
"_ 	c #4CC96F",
": 	c #4FD55A",
"< 	c #015801",
"[ 	c #001F00",
"} 	c #00A900",
"| 	c #1CAE38",
"1 	c #3DBC66",
"2 	c #55D172",
"3 	c #31C632",
"4 	c #001D00",
"5 	c #000800",
"6 	c #008F00",
"7 	c #11AB27",
"8 	c #2FB358",
"9 	c #46C26B",
"0 	c #5BD86F",
"a 	c #119F11",
"b 	c #005E00",
"c 	c #08AA15",
"d 	c #21AD47",
"e 	c #37B861",
"f 	c #4FCA70",
"g 	c #51D75A",
"h 	c #015D01",
"i 	c #002100",
"j 	c #01AA04",
"k 	c #14A931",
"l 	c #29B052",
"m 	c #3FBE67",
"n 	c #58D372",
"o 	c #33C934",
"p 	c #002300",
"q 	c #009300",
"r 	c #09A917",
"s 	c #1CAB3E",
"t 	c #31B45B",
"u 	c #48C56D",
"v 	c #5EDB71",
"w 	c #13A313",
"x 	c #006400",
"y 	c #0FA927",
"z 	c #23AD4A",
"A 	c #39BA63",
"B 	c #51CD71",
"C 	c #54D95B",
"D 	c #016301",
"E 	c #002700",
"F 	c #00AA00",
"G 	c #04AA0B",
"H 	c #16AA35",
"I 	c #2BB154",
"J 	c #42C069",
"K 	c #5AD673",
"L 	c #36CB36",
"M 	c #002800",
"N 	c #009700",
"O 	c #0BA91C",
"P 	c #1EAC42",
"Q 	c #33B55D",
"R 	c #4AC76E",
"S 	c #61DD71",
"T 	c #14A514",
"U 	c #006900",
"V 	c #11A92B",
"W 	c #25AF4D",
"X 	c #3BBA64",
"Y 	c #54CF71",
"Z 	c #58DD5D",
"` 	c #026902",
" .	c #002C00",
"..	c #06AA10",
"+.	c #18AA39",
"@.	c #2DB357",
"#.	c #44C16A",
"$.	c #5DD873",
"%.	c #37CC37",
"&.	c #002B00",
"*.	c #009800",
"=.	c #0CA920",
"-.	c #20AD45",
";.	c #35B75F",
">.	c #4DC96F",
",.	c #65E171",
"'.	c #14A914",
").	c #006E00",
"!.	c #01AB03",
"~.	c #13A92F",
"{.	c #27B050",
"].	c #3EBC66",
"^.	c #56D172",
"/.	c #5CE05D",
"(.	c #026E02",
"_.	c #002F00",
":.	c #08AA14",
"<.	c #1AAA3C",
"[.	c #2FB459",
"}.	c #46C36C",
"|.	c #60DB74",
"1.	c #39CE39",
"2.	c #003200",
"3.	c #009C00",
"4.	c #0EA924",
"5.	c #22AD48",
"6.	c #38B861",
"7.	c #4FCB70",
"8.	c #67E572",
"9.	c #17AE17",
"0.	c #000C00",
"a.	c #007200",
"b.	c #02AB06",
"c.	c #13AA2D",
"d.	c #29B050",
"e.	c #40BE68",
"f.	c #59D473",
"g.	c #5DE35D",
"h.	c #027802",
"i.	c #009400",
"j.	c #059609",
"k.	c #0F9D17",
"l.	c #1FAA24",
"m.	c #0E9F0E",
"n.	c #001200",
"o.	c #000D00",
"p.	c #000600",
"q.	c #00A000",
"                              . .                               ",
"                              + +                               ",
"                            @ # $ @                             ",
"                          % & * = - .                           ",
"                          ; > * , ' )                           ",
"                        @ ! * * ~ { ] ^                         ",
"                      % / * * * ( _ : < .                       ",
"                      [ } * * * | 1 2 3 4                       ",
"                    5 6 * * * * 7 8 9 0 a ^                     ",
"                  . b * * * * * c d e f g h %                   ",
"                  i } * * * * * j k l m n o p                   ",
"                5 q * * * * * * * r s t u v w 5                 ",
"              % x * * * * * * * * * y z A B C D %               ",
"              E F * * * * * * * * * G H I J K L M               ",
"            @ N * * * * * * * * * * * O P Q R S T 5             ",
"          % U * * * * * * * * * * * * * V W X Y Z ` %           ",
"           .* * * * * * * * * * * * * * ..+.@.#.$.%.&.          ",
"        @ *.* * * * * * * * * * * * * * * =.-.;.>.,.'.@         ",
"      % ).* * * * * * * * * * * * * * * * !.~.{.].^./.(.@       ",
"    5 _.* * * * * * * * * * * * * * * * * * :.<.[.}.|.1.2.5     ",
"    % 3.* * * * * * * * * * * * * * * * * * * 4.5.6.7.8.9.0.    ",
"  . a.* * * * * * * * * * * * * * * * * * * * b.c.d.e.f.g.h.@   ",
"^ M i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.q j.k.l.m.E 5 ",
"% n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.n.% ",
"                                                                ",
"% o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.o.% ",
"p.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.p.",
"p.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.q.p.",
"5 % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 5 ",
"                                                                ",
"                                                                ",
"                                                                "};
        """


class CommandSuport():
    """My new command"""

    def GetResources(self):
        return {"Pixmap"  : os.path.join(ICONPATH, "icons/suport.svg"), # the name of a svg file available in the resources
                "Accel"   : "Shift+S", # a default shortcut (optional)
                "MenuText": "Support (Node)",
                "ToolTip" : "Adds a nodal support"}

    def Activated(self):
        """Create a support at selected node(s)."""
        try:
            selections = list(FreeCADGui.Selection.getSelectionEx())

            if not selections:
                show_error_message("No selection found.\nPlease select a vertex (node) to add a support.")
                return

            if len(selections) == 1 and not selections[0].HasSubObjects:
                selected_obj = selections[0].Object
                if selected_obj and hasattr(selected_obj, "FixTranslationX") and hasattr(selected_obj, "ObjectBase"):
                    panel = SupportTaskPanel(selected_obj, allow_distance=False)
                    FreeCADGui.Control.showDialog(panel)
                    return

            for selection in selections:
                if not hasattr(selection, 'SubElementNames'):
                    logger.warn(f"suport: selection has no SubElementNames: {selection}")
                    continue

                for subSelectionname in selection.SubElementNames:
                    if 'Edge' in subSelectionname:
                        show_error_message(
                            f"Cannot add support to edge '{subSelectionname}'.\n"
                            "Please select a vertex (node) instead."
                        )
                        continue

                    if 'Vertex' not in subSelectionname:
                        show_error_message(
                            f"Invalid selection: '{subSelectionname}'.\n"
                            "Please select a vertex (node) to add a support."
                        )
                        continue

                    try:
                        doc = FreeCAD.ActiveDocument
                        obj = doc.addObject("Part::FeaturePython", "Suport")
                        objSuport = Suport(obj, (selection.Object, subSelectionname))
                        ViewProviderSuport(obj.ViewObject)
                        logger.info(f"suport: created support at {subSelectionname}")
                    except Exception as exc:
                        logger.exception(f"suport: failed to create support: {exc}")
                        show_error_message(
                            f"Failed to create support:\n{str(exc)}\n\n"
                            "Please ensure you selected a valid vertex."
                        )

            FreeCAD.ActiveDocument.recompute()

        except AttributeError as exc:
            logger.exception(f"suport: attribute error: {exc}")
            show_error_message(
                f"Invalid selection:\n{str(exc)}\n\n"
                "Please select a vertex (node) from a valid object."
            )
        except Exception as exc:
            logger.exception(f"suport: unexpected error: {exc}")
            show_error_message(
                f"Unexpected error:\n{str(exc)}\n\n"
                "Please check the console for details."
            )
        return

    def IsActive(self):
        
        return True

FreeCADGui.addCommand("suport", CommandSuport())

