# -*- coding: utf-8 -*-
"""
Unit Settings Command for StructureTools

Provides a menu command to change unit settings after workbench activation.
"""

import os
import FreeCADGui
from .unit_dialog import UnitSelectionDialog, reset_unit_dialog_preference
from . import logger

ICONPATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "resources"))


class CommandUnitSettings:
    """Command to open unit settings dialog."""

    def GetResources(self):
        return {
            "Pixmap": os.path.join(ICONPATH, "icons/material.svg"),  # Reuse material icon for now
            "Accel": "Shift+U",
            "MenuText": "Unit Settings...",
            "ToolTip": "Configure unit system for structural analysis"
        }

    def Activated(self):
        """Show unit settings dialog."""
        try:
            dialog = UnitSelectionDialog()
            result = dialog.exec_()

            if result:
                from .unit_manager import get_current_units
                units = get_current_units()
                logger.info(f"unit_settings: user changed units to {units.name}")
            else:
                logger.info("unit_settings: user cancelled")

        except Exception as exc:
            logger.exception(f"unit_settings: error showing dialog: {exc}")
            from .ui_helpers import show_error_message
            show_error_message(
                f"Failed to open unit settings:\n{str(exc)}\n\n"
                "Please check the console for details."
            )

    def IsActive(self):
        """Command is always active."""
        return True


FreeCADGui.addCommand("unit_settings", CommandUnitSettings())
