# StructureTools Test Suite

Basic validation and unit tests for StructureTools workbench.

## Running Tests

```bash
cd tests
python test_validation.py
```

## Test Status

- ✅ Input validation tests
- ✅ Coordinate transformation tests
- ⚠️ FEA validation tests (skeleton only - needs integration)

## IMPORTANT

These are BASIC tests. Validate results against established FEA software before production use.
