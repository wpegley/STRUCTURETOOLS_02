# Self-Weight Re-Implementation
## Date: 2025-12-31 Evening

---

## ✅ Status: IN PROGRESS

### Completed Steps

1. ✅ **Added SelfWeight property** (calc.py:402-407)
   - Boolean property in Calc object
   - Default: False (backward compatible)
   - Tooltip explains functionality

2. ✅ **Added checkbox to dialog** (calc.py:212-223)
   - Checkbox with clear label and tooltip
   - Connected to `on_selfweight_changed` handler
   - Placed before refinement checkbox

3. ✅ **Added event handler** (calc.py:267-270)
   - `on_selfweight_changed(state)` method
   - Stores value in `self.selfweight_enabled`
   - Logs changes

4. ✅ **Initialized dialog attribute** (calc.py:45)
   - `self.selfweight_enabled = False` in `__init__`
   - Default OFF for backward compatibility

5. ✅ **Fixed persistence** (calc.py:311-317)
   - `get_values()` now returns selfweight setting
   - **THIS WAS THE BIG FIX!**

6. ✅ **Property assignment** (calc.py:1789-1791)
   - `obj.SelfWeight = settings['selfweight']`
   - Set IMMEDIATELY after Calc creation
   - Logged to console

7. ✅ **Updated console logging** (calc.py:1793-1795)
   - Shows "self-weight ENABLED" or "disabled"
   - Clear confirmation in console

---

## 🔧 Remaining Work

### Next Step: Calculate Self-Weight

**Location**: calc.py around line 1480

**Current Code**:
```python
# Self-weight disabled - users can add self-weight manually as distributed loads

model = self.setLoads(model, loads, nodes_map, obj.ForceUnit, obj.LengthUnit, members_map)
```

**Need to Replace With**:
```python
# Apply self-weight if enabled
if obj.SelfWeight:
    model = self.applySelfWeight(model, lines, members_map, obj.ForceUnit, obj.LengthUnit)
    logger.info("calc: self-weight loads applied")
else:
    logger.info("calc: self-weight disabled")

model = self.setLoads(model, loads, nodes_map, obj.ForceUnit, obj.LengthUnit, members_map)
```

### Then: Implement `applySelfWeight` Method

**Purpose**: Calculate weight for each member and apply as distributed load

**Formula**:
```
Self-Weight = Area × Density × Gravity
```

**Details**:
- Area: From section properties (m²)
- Density: From material properties (kg/m³)
  - Steel S235: 7850 kg/m³
  - Aluminum: 2700 kg/m³
  - Concrete: 2400 kg/m³
- Gravity: 9.81 m/s²
- Direction: -Z (downward)

**Unit Conversion**:
- Result in Newtons (N)
- Convert to ForceUnit (kN, N, etc.) for display
- Force per meter: N/m or kN/m

**PyNite API**:
```python
model.add_member_dist_load(
    Member=member_name,
    Direction='FZ',  # -Z direction (downward)
    w1=-weight_per_meter,  # Negative for downward
    w2=-weight_per_meter,  # Uniform load
    x1=0.0,  # Start of member
    x2=member_length,  # End of member
    case='D'  # Dead load case
)
```

---

## 🧪 Testing Plan

**STATUS**: ⚠️ User opened OLD file instead of running NEW analysis

### User's Console Log Analysis (19:44:31):
- Shows: "diagram: document is restoring" (file opening)
- Missing: All self-weight calculation messages
- **Reason**: Self-weight only runs during NEW analysis, not document restore

### Correct Testing Procedure:
See [TESTING_SELFWEIGHT_20251231.md](TESTING_SELFWEIGHT_20251231.md) for detailed instructions.

**Quick Summary**:
1. Create NEW document (don't open old file)
2. Create simple structure with material and section
3. Tick "Include self-weight" checkbox ✅
4. Run NEW analysis
5. Check console for self-weight messages

### Expected Console Output:
```
calc: self-weight property set to True
calc: user confirmed analysis (self-weight: ENABLED)
calc: calculating self-weight for 1 members
calc:   Line: A=0.007810 m², ρ=7850 kg/m³
calc:     Self-weight: 0.601 kN/m (downward)
calc: applied self-weight to 8 member segments
calc: self-weight loads applied
```

### Comparison Test:
1. **Without self-weight**: Tick checkbox OFF → Check results
2. **With self-weight**: Tick checkbox ON ✅ → Check results
3. **Expected**: Deflections and moments INCREASE with self-weight

---

## ⚠️ Issues Fixed

### Original Problem: Checkbox Persistence

**Before**: Checkbox value never reached property
- User ticks checkbox ✅
- Dialog closes
- Property remains False ❌
- Console: "self-weight: disabled" (wrong!)

**After (Fixed)**:
- User ticks checkbox ✅
- `on_selfweight_changed()` sets `self.selfweight_enabled = True`
- `get_values()` returns `{'selfweight': True, ...}`
- `obj.SelfWeight = settings['selfweight']` sets property ✅
- Console: "self-weight ENABLED" (correct!)

**Root Cause**: Settings never included selfweight value

**Fix**: Added `'selfweight': self.selfweight_enabled` to `get_values()` return dict

---

## 📊 Expected Console Output

### Before (Current State):
```
calc: user confirmed analysis (self-weight: disabled)
calc: building model with 8 segments per member
```

### After (With Self-Weight):
```
calc: self-weight property set to True
calc: user confirmed analysis (self-weight ENABLED)
calc: building model with 8 segments per member
calc: calculating self-weight for 1 members
calc:   Line: section=HEB200 (A=0.00781 m²), material=S235 (ρ=7850 kg/m³)
calc:   Self-weight: 0.60 kN/m (downward)
calc: self-weight loads applied
```

---

## 🔄 Restore Backup

If problems occur:
```bash
cd "c:\Users\wpegl\AppData\Roaming\FreeCAD\v1-1\Mod\StructureTools-main\freecad\StructureTools"
copy /Y calc.py.BACKUP_20251231 calc.py
```

---

**Status**: ✅ Implementation complete, comprehensive debugging added
**Next**: User needs to test with NEW analysis (not opening old file)
**Testing Guide**: See TESTING_SELFWEIGHT_20251231.md
