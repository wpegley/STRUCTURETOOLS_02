# Unit System Management in StructureTools

## Overview

StructureTools uses **PyNite** as its finite element analysis (FEA) solver. PyNite is **unit-agnostic**, meaning it doesn't care what units you use - it simply performs calculations on the numbers you provide.

**⚠️ CRITICAL: This means YOU are responsible for ensuring unit consistency!**

Mixing units (e.g., meters with inches, or Newtons with kips) will produce **incorrect and potentially dangerous results**. The workbench will not detect unit mismatches.

## How It Works

### 1. Unit System Selection at Startup

When you first activate the StructureTools workbench, a dialog appears allowing you to select your preferred unit system:

- **SI (Metric) Units**
  - SI (m, kN, t) - **Recommended** for most structural engineering
  - SI (m, N, kg) - Pure SI units
  - SI (mm, N, kg) - Common in mechanical engineering
  - SI (mm, kN, t) - Alternative metric

- **US Customary (Imperial) Units**
  - US Customary (ft, kip, kip) - **Recommended** for US structural engineering
  - US Customary (in, kip, kip) - US with inches
  - US Customary (ft, lbf, lb) - US with pounds
  - US Customary (in, lbf, lb) - US inches and pounds

The dialog attempts to detect your FreeCAD unit preferences and suggests a compatible unit system.

### 2. Unit System Components

Each unit system defines:

| Component | Example (SI m, kN) | Example (US ft, kip) |
|-----------|-------------------|----------------------|
| **Length** | m | ft |
| **Force** | kN | kip |
| **Mass** | t (metric ton) | kip |
| **Stress** | kN/m² | kip/ft² |
| **Density** | t/m³ | kip/ft³ |
| **Distributed Load** | kN/m | kip/ft |
| **Moment** | kN·m | kip·ft |
| **Area** | m² | ft² |
| **Moment of Inertia** | m⁴ | ft⁴ |

### 3. FreeCAD Integration

The workbench automatically converts FreeCAD's internal units (always millimeters) to your selected unit system before passing to PyNite.

**Important**: FreeCAD geometry is **always** in millimeters internally, but displays in your chosen schema. The workbench handles this conversion automatically.

## Usage Guidelines

### DO ✅

1. **Select units at workbench activation** - Review and confirm the suggested unit system
2. **Use consistent units** - All inputs must match your selected system
3. **Check unit labels** - The calc dialog shows the active unit system
4. **Verify material properties** - Ensure E, ν, ρ match your units
5. **Verify section properties** - Ensure A, I, J match your units
6. **Check load magnitudes** - Ensure loads use correct force/length units

### DON'T ❌

1. **Don't mix units** - Never use meters with inches, or Newtons with kips
2. **Don't assume** - Always verify what units you're using
3. **Don't skip the dialog** - Review units even if familiar with the model
4. **Don't change units mid-analysis** - Complete analysis with one unit system

## Changing Units

### During Workbench Session

1. Go to **StructureTools menu → Unit Settings...**
2. Select your desired unit system
3. Click **OK**

**⚠️ Warning**: Changing units does NOT convert existing model data! You must:
- Recreate materials with properties in new units
- Recreate sections with properties in new units
- Recreate loads with magnitudes in new units
- Re-run all calculations

### Resetting Dialog Preference

If you checked "Remember this choice and don't show this dialog again" but want to see it again:

```python
# In FreeCAD Python console
from freecad.StructureTools.unit_dialog import reset_unit_dialog_preference
reset_unit_dialog_preference()
```

## Common Unit Conversions

### Length
- 1 m = 3.28084 ft = 39.3701 in = 1000 mm
- 1 ft = 0.3048 m = 12 in
- 1 in = 25.4 mm = 0.0254 m

### Force
- 1 kN = 1000 N = 0.224809 kip = 224.809 lbf
- 1 kip = 1000 lbf = 4.44822 kN
- 1 N = 0.224809 lbf

### Stress/Pressure
- 1 MPa = 1000 kPa = 1 N/mm² = 145.038 psi
- 1 ksi = 1000 psi = 6.89476 MPa
- 1 kN/m² = 0.001 MPa = 20.8854 psf

### Density
- 1 kg/m³ = 0.001 t/m³ = 0.0624279 lb/ft³
- 1 lb/ft³ = 16.0185 kg/m³

## Example: Steel Material Properties

### SI (m, kN, t)
```
E = 210000000 kN/m² (210 GPa)
ν = 0.30
ρ = 7.85 t/m³ (7850 kg/m³)
```

### SI (mm, N, kg)
```
E = 210000 N/mm²
ν = 0.30
ρ = 7850 kg/m³
```

### US (ft, kip, kip)
```
E = 432960 kip/ft² (29000 ksi)
ν = 0.30
ρ = 0.490 kip/ft³ (490 lb/ft³)
```

## Troubleshooting

### Problem: Results seem unrealistic

**Possible causes**:
1. Unit mismatch - Check all inputs use same system
2. Wrong magnitude - Verify load values (e.g., 10 kN vs 10000 N)
3. Wrong material properties - Ensure E is in correct units

**Solution**:
1. Open **Unit Settings** dialog
2. Verify selected unit system
3. Check all material properties match units
4. Check all load magnitudes match units
5. Re-run analysis

### Problem: Dialog doesn't appear

**Cause**: You previously checked "Don't show again"

**Solution**:
```python
from freecad.StructureTools.unit_dialog import reset_unit_dialog_preference
reset_unit_dialog_preference()
```

### Problem: Want to use custom units

**Solution**: Currently not supported. Choose the closest standard system and manually ensure consistency.

## Technical Details

### Unit Manager Singleton

The `UnitManager` class maintains the globally-selected unit system:

```python
from freecad.StructureTools.unit_manager import get_unit_manager, get_current_units

# Get unit manager
manager = get_unit_manager()

# Get current units
units = get_current_units()
print(f"Length: {units.length}")
print(f"Force: {units.force}")
print(f"Mass: {units.mass}")
```

### FreeCAD Unit Schema Detection

The workbench attempts to detect FreeCAD's unit schema:

| FreeCAD Schema | Suggested StructureTools Units |
|----------------|-------------------------------|
| Standard (mm, kg, s) | SI (mm, N, kg) |
| MKS (m, kg, s) | SI (m, N, kg) |
| US customary (in, lb) | US Customary (in, lbf, lb) |
| Building Euro | SI (m, kN, t) |
| Building US | US Customary (ft, kip, kip) |
| Imperial Civil | US Customary (ft, kip, kip) |

### Persistence

Your unit choice is saved in FreeCAD preferences:
```
User parameter:BaseApp/Preferences/Mod/StructureTools
  - UnitSystemName
  - LengthUnit
  - ForceUnit
  - MassUnit
  - DontShowUnitDialog
```

## Best Practices

1. **Always verify units** before running analysis
2. **Document your unit system** in model notes
3. **Double-check conversions** when working with reference data
4. **Use recommended systems** (SI m,kN or US ft,kip) for structural work
5. **Validate results** against hand calculations or other software

## Safety Notice

⚠️ **CRITICAL FOR STRUCTURAL ENGINEERING**

Unit errors in structural analysis can lead to:
- Under-designed structures (unsafe)
- Over-designed structures (expensive)
- Catastrophic failures
- Legal liability

**Always**:
- Have a professional engineer review your work
- Verify units before and after analysis
- Compare with hand calculations for simple cases
- Cross-check with established FEA software

---

**Remember**: PyNite doesn't know about units. **You** are responsible for consistency!
