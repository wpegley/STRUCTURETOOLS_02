# Pre-Analysis Review Dialog - User Guide

## Overview

The **Pre-Analysis Review Dialog** appears before every structural analysis, allowing you to verify that all inputs are interpreted correctly—especially load magnitudes and their units. This prevents the common error of applying loads that are 1000× too large or too small due to unit mismatches.

## The Problem It Solves

### Common Unit Confusion

Structural engineers typically work with:
- **Distributed loads**: kN/m (kilonewton per meter)
- **Point loads**: kN (kilonewton)
- **Moments**: kN·m (kilonewton-meter)

However, StructureTools uses base units internally:
- **Length**: mm (millimeter)
- **Force**: N (Newton)
- **Distributed loads**: N/mm

**The issue**: 1 kN/m = 0.001 N/mm

If you enter "10" thinking it means "10 kN/m" but the system interprets it as "10 N/mm", that's actually **10,000 kN/m** - a thousand times larger!

## Dialog Features

### 5 Review Tabs

#### 1. System Units Tab
Shows the current unit system being used for analysis:
- Length unit (mm, m, ft, in)
- Force unit (N, kN, kip, lb)
- Derived units (distributed load, moment)
- Reference table of common engineering units

#### 2. Members Tab
Lists all structural members:
- Member name
- Material assigned
- Section assigned
- Length in current units

**Purpose**: Verify all members have materials and sections defined.

#### 3. Loads Tab ⚠️ **MOST IMPORTANT**
Displays all loads with:
- Load type (Distributed / Point)
- Direction (+X, -Y, etc.)
- Current magnitude and units
- **Unit correction dropdown**

**This is where you fix unit mismatches!**

#### 4. Supports Tab
Shows all supports with:
- Support name
- Type (Vertex / Edge)
- DOF restraints (X, Y, Z translations and rotations)

**Purpose**: Verify support configuration is correct.

#### 5. Analysis Settings Tab
Displays analysis parameters:
- Segments per member
- Mesh refinement status
- Self-weight inclusion

**Purpose**: Confirm analysis settings before running.

## How to Use the Unit Correction Feature

### Step 1: Review Load Magnitudes

When the dialog appears, look at the **Loads** tab. For each load, you'll see:

```
📊 Load_Distributed
Type: Distributed Load
Direction: -Y
Initial Loading: 10.000 N/mm
Final Loading: 10.000 N/mm
```

### Step 2: Check if Units Are Correct

Ask yourself: "Did I intend this as N/mm or kN/m?"

**Common cases**:
- If you entered "10" meaning "10 kN/m", the display should show "0.010 N/mm" (NOT "10.000 N/mm")
- If you see "10000.000 N/mm", you probably meant "10 kN/m" (which is 0.01 N/mm)

### Step 3: Correct Units if Needed

If the interpretation is wrong:

1. Click the dropdown that says "✓ Correct as shown (N/mm)"
2. Select the **actual** units you meant:
   - kN/m
   - kN/mm
   - N/m
   - N/mm
   - kip/ft
   - kip/in
   - lb/ft
   - lb/in

3. The system will automatically convert your value to the correct internal units

### Step 4: Click OK

Once all loads are correctly interpreted, click **OK** to proceed with analysis.

## Example Scenario

### Problem: Load 1000× Too Large

**What you entered**:
- Load_Distributed
- InitialLoading: 10
- FinalLoading: 10
- GlobalDirection: -Y
- **Intended meaning**: 10 kN/m (typical building floor load)

**What the system shows**:
```
Initial Loading: 10.000 N/mm
Final Loading: 10.000 N/mm
```

**What this actually means**:
- 10 N/mm = 10,000 N/m = 10,000 kN/m
- That's the weight of **1000 cars** on your beam!

**How to fix**:
1. Select "kN/m" from the dropdown
2. System re-interprets "10" as "10 kN/m"
3. Internally converts to 0.01 N/mm
4. Analysis proceeds with correct magnitude

## Real-World Examples

### Example 1: Office Floor Load

**Typical value**: 2.5 kN/m² on a 4m wide area = 10 kN/m line load

**If entered as**: 10 N/mm
**Actual magnitude**: 10,000 kN/m ❌ **WRONG**

**Correction**: Select "kN/m" from dropdown
**Result**: 0.01 N/mm ✅ **CORRECT**

### Example 2: Roof Snow Load

**Typical value**: 1.0 kN/m² on a 6m wide area = 6 kN/m line load

**If entered as**: 6 N/mm
**Actual magnitude**: 6,000 kN/m ❌ **WRONG**

**Correction**: Select "kN/m" from dropdown
**Result**: 0.006 N/mm ✅ **CORRECT**

### Example 3: Point Load from Column

**Typical value**: 150 kN concentrated load

**If entered as**: 150 N
**Actual magnitude**: 150 N = 0.15 kN ❌ **WRONG**

**Correction**: Select "kN" from dropdown
**Result**: 150,000 N ✅ **CORRECT**

## Unit Conversion Reference

### Distributed Loads

| Input Value | Actual Units | Conversion Factor | Internal (N/mm) |
|-------------|--------------|-------------------|-----------------|
| 10          | kN/m         | ÷ 1000            | 0.01            |
| 10          | N/m          | ÷ 1,000,000       | 0.00001         |
| 10          | N/mm         | × 1               | 10.0            |
| 10          | kN/mm        | × 1000            | 10,000          |
| 10          | kip/ft       | kip→N, ft→mm      | 145.94          |
| 10          | lb/ft        | lb→N, ft→mm       | 0.1459          |

### Point Loads

| Input Value | Actual Units | Conversion Factor | Internal (N) |
|-------------|--------------|-------------------|--------------|
| 100         | kN           | × 1000            | 100,000      |
| 100         | N            | × 1               | 100          |
| 100         | kip          | × 4448.22         | 444,822      |
| 100         | lb           | × 4.44822         | 444.822      |

## Warning Signs of Unit Errors

### Diagrams Way Too Large

If moment or deflection diagrams are **millions of units** tall:
```
diagram: BoundBox size - Z=18046875000.00
```

**Likely cause**: Load magnitude is 1000× too large (entered as N/mm instead of kN/m)

**Fix**: Edit load, rerun analysis, correct units in review dialog

### Diagrams Way Too Small or Zero

If diagrams show no deflection or near-zero values:

**Likely cause**: Load magnitude is 1000× too small (entered as kN/m but system expects N/mm without conversion)

**Fix**: Check load units in review dialog, ensure correct interpretation

### Unrealistic Results

If maximum moment is **18 billion N·mm** for a simple 5m beam:

**Likely cause**: Load is way too large due to unit error

**Calculation check**:
- Simple beam, 5m span, 10 kN/m UDL
- Max moment = wL²/8 = (10 × 5²)/8 = 31.25 kN·m = 31,250,000 N·mm
- If you see 18,000,000,000 N·mm, load was probably 1000× too large

## Best Practices

### 1. Always Review Loads Tab First

The Loads tab is where unit errors appear. Check it **before** looking at other tabs.

### 2. Know Your Typical Load Ranges

**Distributed loads on beams**:
- Residential floor: 2-5 kN/m
- Office floor: 5-10 kN/m
- Warehouse: 10-20 kN/m
- Very heavy equipment: 50+ kN/m

**Point loads**:
- Light fixtures: 0.1-1 kN
- Small equipment: 1-10 kN
- Column loads: 50-500 kN
- Heavy machinery: 1000+ kN

If your values are way outside these ranges, check units!

### 3. Use Consistent Unit System

Pick one unit system and stick with it:
- **Metric**: kN/m for distributed, kN for point
- **US**: kip/ft for distributed, kip for point

Don't mix units within a model.

### 4. Double-Check After Correction

After selecting corrected units:
1. Note the internal value shown
2. Mentally verify: does this make sense?
3. If unsure, click Cancel and recalculate manually

### 5. Check Console Output

After clicking OK, console shows:
```
calc: user applied unit corrections to 1 load(s)
calc:   - Load_Distributed: corrected to kN/m
```

This confirms your corrections were applied.

## Technical Details

### How Unit Correction Works

When you select actual units from the dropdown:

1. **Extract current value**: Read the Quantity value from the load property
2. **Re-interpret**: Call `Quantity.getValueAs(actual_unit)` to get value in actual units
3. **Store corrected**: Set property to `Quantity(value, actual_unit)`
4. **Convert internally**: PyNite receives value in system base units (N, mm)

**Example**:
```python
# User entered 10, meaning 10 kN/m
load.InitialLoading = Quantity(10, "N/mm")  # Wrong interpretation

# User selects "kN/m" from dropdown
actual_value = load.InitialLoading.getValueAs("kN/m")  # = 10000 kN/m (wrong!)

# Correction: user actually meant 10 kN/m
load.InitialLoading = Quantity(10, "kN/m")  # Correct interpretation
internal_value = load.InitialLoading.getValueAs("N/mm")  # = 0.01 N/mm (correct!)
```

### Coordinate System Reminder

**FreeCAD axes**:
- +X: Horizontal (typical beam span direction)
- +Y: Horizontal perpendicular
- +Z: Vertical (up)

**Gravity loads**: Use **-Z** direction (downward)

**Common mistake**: Using -Y for gravity because that's "down" in 2D diagrams. In 3D, use -Z!

## Troubleshooting

### Dialog Doesn't Appear

**Possible causes**:
- Old version of calc.py (before review dialog feature)
- Import error for `analysis_review_dialog.py`

**Solution**: Restart FreeCAD, check console for errors

### Dropdown Doesn't Show My Units

**Available units**:
- Distributed: kN/m, kN/mm, N/m, N/mm, kip/ft, kip/in, lb/ft, lb/in
- Point: kN, N, kip, lb

**If you need others**: Choose closest and manually adjust load value

### Correction Doesn't Fix Diagram Scale

**Possible causes**:
1. Multiple loads need correction (fix all of them)
2. Load was edited after initial creation (value changed)
3. Diagram ScaleMoment property also needs adjustment

**Solution**: Check all loads, adjust ScaleMoment if needed

## Summary

The Pre-Analysis Review Dialog is your **safety check** before running expensive calculations:

**Benefits**:
- ✅ Catch unit errors before analysis
- ✅ Verify all inputs are correct
- ✅ No more 1000× load mistakes
- ✅ Confidence in results

**Usage**:
1. Review appears automatically before analysis
2. Check Loads tab carefully
3. Correct any unit misinterpretations
4. Click OK to proceed

**Remember**: The most common error is confusing **kN/m** (engineering units) with **N/mm** (system units). Always verify loads are interpreted correctly!

---

**Feature Added**: 2025-12-26
**Files**: [analysis_review_dialog.py](analysis_review_dialog.py), [calc.py](calc.py)
**Related Documentation**:
- [UNIT_SYSTEM.md](UNIT_SYSTEM.md) - Unit system architecture
- [OBJECTBASE_LOAD_SUPPORT.md](OBJECTBASE_LOAD_SUPPORT.md) - Load application
