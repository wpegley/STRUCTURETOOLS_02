# Migration Guide: Updating Old Load Objects

## After Unit System Fix (2025-12-26)

If you see the warning:
```
Load 'Load_Distributed': 1000000.000 N/mm seems very large.
Did you mean 1000000.000 kN/m instead?
```

This means you have **old load objects** created before the unit system fix that need to be recreated.

---

## Why This Happened

**Before the fix** (old system):
- Internal units: mm and N
- User entered: 10 (meaning 10 kN/m)
- System stored: 10000000 N (10 million N, interpreting as N/mm)
- This was wrong but "worked" because conversion was broken both ways

**After the fix** (new system):
- Internal units: m and kN
- User enters: 10 (meaning 10 kN/m)
- System stores: 10000 N (10 kN)
- Conversion properly handles: 10000 N ÷ 1000 = 10 kN/m ✓

**Your old load** has value 1000000 which the new system tries to interpret as 1000000 kN/m (way too large!).

---

## Solution: Delete and Recreate Loads

### Step 1: Note Your Load Values

Before deleting, write down what you intended:
- **Example**: If you meant "10 kN/m uniformly distributed load downward"

### Step 2: Delete Old Load Objects

1. Select the load object(s) in the tree (e.g., `Load_Distributed`)
2. Press `Delete` key
3. Confirm deletion

### Step 3: Create New Load

1. Select the beam/edge you want to load
2. Click the "Distributed Load" icon (or use Shift+L)
3. In the properties panel, set:
   - **InitialLoading**: Enter the number you intend (e.g., `10`)
   - **FinalLoading**: Same or different for trapezoidal load
   - **GlobalDirection**: Usually `-Z` for gravity loads

**Important**: Just enter the numerical value you want in kN/m. Don't multiply by 1000.

### Step 4: Verify

1. Check the properties panel shows reasonable values:
   - `InitialLoading: 10000 N` = 10 kN ✓
   - NOT: `10000000 N` = 10000 kN ✗

2. Run analysis - the console should show:
   ```
   calc: applied distributed load (10.0 to 10.0 kN/m) to X segments
   ```
   NOT: `(1000.0 to 1000.0 kN/m)` or other wrong values

---

## Quick Reference: Load Input Values

| Load Type | Old System (WRONG) | New System (CORRECT) |
|-----------|-------------------|----------------------|
| 10 kN/m UDL | Enter: 10000000 | Enter: 10 |
| 20 kN/m UDL | Enter: 20000000 | Enter: 20 |
| 5 kN/m UDL | Enter: 5000000 | Enter: 5 |
| 50 kN point load | Enter: 50000 | Enter: 50 |

**Rule**: Enter the value in kilonewtons (kN) or kilonewtons per meter (kN/m), not Newtons.

---

## What If I Don't Recreate?

The analysis **will still run** but with incorrect load magnitudes. Your old load with value 1000000 will be interpreted as 1000 kN/m instead of the intended 10 kN/m, giving results that are 100× too large!

**Always recreate old loads after updating to the new system.**

---

## For Future Reference

### Creating New Loads (Post-Fix)

When creating distributed loads:
1. **Think in engineering units**: "I want 10 kN per meter"
2. **Enter the number**: Just type `10`
3. **FreeCAD shows**: `10000 N` in the property (this is correct! 10 kN = 10000 N)
4. **Solver receives**: 10 kN/m (our conversion handles it)

### Understanding PropertyForce

The property is technically `PropertyForce` which stores force in Newtons (N), but:
- You're entering a **distributed load** (force per length)
- The value represents kN/m
- Our conversion function correctly interprets it

**Don't worry about the N vs kN/m confusion** - just enter the numerical value you want in kN/m and the system handles the rest.

---

## Troubleshooting

### "Load value seems very large" Warning

- This means your load is probably old (created before the fix)
- **Solution**: Delete and recreate the load object

### Analysis Results Too Large/Small

- Check console log: `calc: applied distributed load (X to Y kN/m)`
- If X/Y are way off from what you intended, recreate the load

### Self-Weight Calculation Wrong

- Make sure you've restarted FreeCAD after updating the code
- Check console: `calc: material density = ~77.0 kN/m³` for steel
- If it shows 78.5, you're still running old code

---

**Date**: 2025-12-26
**Applies to**: Unit system overhaul (density fix, m/kN system, load conversion)
**Status**: Permanent change - old loads incompatible with new system
