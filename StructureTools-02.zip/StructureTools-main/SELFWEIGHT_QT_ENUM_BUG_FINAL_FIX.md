# Self-Weight Qt Enum Bug - FINAL FIX
## Date: 2025-12-31 Very Late Evening

---

## 🔴 ROOT CAUSE IDENTIFIED: Qt CheckState Enum Comparison Bug

### The Smoking Gun

User's console log (20:18:12) revealed:
```
DEBUG calc_dialog: self-weight checkbox state=2, QtCore.Qt.Checked=CheckState.Checked
DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled=False
```

**Analysis**:
- User **DID tick** the checkbox ✅
- Qt returned `state=2` (integer value for Checked)
- `QtCore.Qt.Checked` printed as `"CheckState.Checked"` (enum string representation)
- Comparison `state == QtCore.Qt.Checked` **FAILED** ❌
- Result: `self.selfweight_enabled = False` (wrong!)

---

## 🐛 The Bug

### Original Code (BROKEN)

**File**: [calc.py:270](calc.py#L270)

```python
def on_selfweight_changed(self, state):
    """Handle self-weight checkbox change - PERSISTENCE FIX."""
    self.selfweight_enabled = (state == QtCore.Qt.Checked)  # BUG: Enum comparison fails
```

### Why It Failed

Qt's `QCheckBox.stateChanged` signal emits a `Qt.CheckState` enum:
- `Qt.CheckState.Unchecked` = 0
- `Qt.CheckState.PartiallyChecked` = 1
- `Qt.CheckState.Checked` = 2

In FreeCAD's Qt bindings (PySide2/PySide6), comparing the enum object directly fails:
```python
state = 2  # Integer value
QtCore.Qt.Checked = <enum 'CheckState.Checked'>  # Enum object

(state == QtCore.Qt.Checked)  # FALSE! (comparing int to enum object)
```

The comparison returns `False` even though the checkbox is checked because Python is comparing an **integer (2)** to an **enum object** instead of comparing values.

---

## ✅ THE FIX

### New Code (WORKING)

**File**: [calc.py:268-274](calc.py#L268-L274)

```python
def on_selfweight_changed(self, state):
    """Handle self-weight checkbox change - PERSISTENCE FIX."""
    # CRITICAL FIX: Qt returns CheckState enum (value 2 for Checked), not boolean
    # Must compare integer value, not enum object
    self.selfweight_enabled = (int(state) == 2)  # 2 = Qt.CheckState.Checked
    logger.info(f"DEBUG calc_dialog: self-weight checkbox state={state} (int={int(state)})")
    logger.info(f"DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled={self.selfweight_enabled}")
```

### Why This Works

- Convert enum to integer: `int(state)`
- Compare integer values: `int(state) == 2`
- When checkbox ticked: `int(2) == 2` → `True` ✅
- When checkbox unticked: `int(0) == 2` → `False` ✅

---

## 📊 Expected Console Output (After Fix)

### When User TICKS Checkbox ✅

```
DEBUG calc_dialog: self-weight checkbox state=2 (int=2)
DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled=True
DEBUG: dialog.get_values() returned: {'segments': 16, 'selfweight': True, ...}
DEBUG: settings['selfweight'] = True
calc: SelfWeight property initialized to True (from constructor parameter)
DEBUG: obj.SelfWeight after construction = True
calc: starting analysis (self-weight ENABLED)
calc: calculating self-weight for 1 members
calc:   Line: A=0.001730 m², ρ=7850 kg/m³
calc:     Self-weight: 0.133 kN/m (downward)
calc: applied self-weight to 16 member segments
```

### When User DOES NOT TICK Checkbox ❌

```
(No event handler called - checkbox starts unchecked)
DEBUG: dialog.get_values() returned: {'segments': 16, 'selfweight': False, ...}
DEBUG: settings['selfweight'] = False
calc: SelfWeight property initialized to False (from constructor parameter)
calc: starting analysis (self-weight disabled)
```

---

## 🔬 Before vs After

### Before Fix (User's Console 20:18:12)

```
DEBUG calc_dialog: self-weight checkbox state=2, QtCore.Qt.Checked=CheckState.Checked
DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled=False  ❌ WRONG!
DEBUG: dialog.get_values() returned: {'segments': 16, 'selfweight': False, ...}
calc: SelfWeight property initialized to False (from constructor parameter)
calc: starting analysis (self-weight disabled)
```

**Result**: Checkbox ticked, but analysis ran without self-weight

### After Fix (Expected)

```
DEBUG calc_dialog: self-weight checkbox state=2 (int=2)
DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled=True  ✅ CORRECT!
DEBUG: dialog.get_values() returned: {'segments': 16, 'selfweight': True, ...}
calc: SelfWeight property initialized to True (from constructor parameter)
calc: starting analysis (self-weight ENABLED)
calc: calculating self-weight for 1 members
```

**Result**: Checkbox ticked, analysis runs WITH self-weight

---

## 🎯 Testing Instructions

1. **Close FreeCAD completely** (force restart to reload Python modules)
2. **Open FreeCAD** and StructureTools workbench
3. **Create NEW test structure**:
   - Line: 5m span
   - Material: Steel (ρ=7850 kg/m³)
   - Section: 150UB14.0 (A=1730 mm²)
   - Supports: Fixed + Roller
   - Load: 10 kN point load at midspan
4. **Select the Line** in tree view
5. **Click "Calc" button**
6. **✅ TICK the "Include self-weight" checkbox**
7. **Click OK**
8. **Check Report View console**

### You Should See

```
DEBUG calc_dialog: self-weight checkbox state=2 (int=2)
DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled=True  ✅
```

Not:
```
DEBUG calc_dialog: self-weight checkbox changed to self.selfweight_enabled=False  ❌
```

---

## 📝 All Files Modified in This Session

1. **calc.py line 364**: Added `selfweight_enabled` parameter to `Calc.__init__()`
2. **calc.py line 425-426**: Use parameter instead of hardcoded False
3. **calc.py line 1874**: Pass `selfweight_enabled=settings['selfweight']` to constructor
4. **calc.py lines 1864-1879**: Added comprehensive debug logging
5. **calc.py lines 270-274**: **CRITICAL FIX** - Use `int(state) == 2` instead of enum comparison

---

## 🔄 Restore if Needed

If issues occur:

```bash
cd "c:\Users\wpegl\AppData\Roaming\FreeCAD\v1-1\Mod\StructureTools-main\freecad\StructureTools"
copy /Y calc.py.BACKUP_20251231 calc.py
```

---

## 📊 Summary of Root Causes

### Original "BIG!" Problem (Weeks Ago)
**Issue**: Checkbox value never saved to property
**Cause**: `get_values()` didn't return `'selfweight'` key
**Fixed**: Added `'selfweight': self.selfweight_enabled` to returned dictionary

### Today's Problem #1 (Timing Bug)
**Issue**: Property set after construction caused race condition
**Cause**: `obj.SelfWeight = settings['selfweight']` after object creation
**Fixed**: Pass `selfweight_enabled` to constructor, set during `__init__()`

### Today's Problem #2 (Qt Enum Bug) **THE ACTUAL ROOT CAUSE**
**Issue**: Checkbox ticked but `self.selfweight_enabled` set to False
**Cause**: Comparing integer `2` to enum object `QtCore.Qt.Checked` failed
**Fixed**: Use `int(state) == 2` to compare integer values

---

## ✅ Status

**Implementation**: ✅ COMPLETE
**Testing**: ⏳ AWAITING USER TEST (must restart FreeCAD)
**Expected Outcome**: Self-weight correctly applied when checkbox ticked

---

## 🎯 Success Criteria

After restart and new analysis with checkbox ticked:

1. ✅ Console shows: `self.selfweight_enabled=True` (not False)
2. ✅ Console shows: `settings['selfweight'] = True`
3. ✅ Console shows: `SelfWeight property initialized to True`
4. ✅ Console shows: `self-weight ENABLED`
5. ✅ Console shows: `calculating self-weight for X members`
6. ✅ Console shows: `Self-weight: 0.133 kN/m (downward)`
7. ✅ Deflection increases from 4.62mm to ~4.7-4.8mm
8. ✅ Moment increases from 6.25kNm to ~6.4-6.5kNm
9. ✅ Results match other software more closely

---

**This was a classic Qt enum comparison bug - the integer value was correct (2 = Checked), but Python's enum object comparison failed. Converting to integer fixes it permanently.**
