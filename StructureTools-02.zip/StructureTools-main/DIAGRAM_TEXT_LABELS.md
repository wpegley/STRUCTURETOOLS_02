# Diagram Text Labels - User Guide

## Overview

The diagram text label system allows you to control what value labels appear on your structural analysis diagrams (moment, shear, deflection, etc.).

## Properties

### DrawText (Boolean)
- **Default**: `False` (OFF)
- **Location**: Diagram object → Properties → Diagram → DrawText
- **Description**: Master toggle for showing text labels on diagrams

**When OFF**: No text labels are displayed
**When ON**: Text labels are displayed according to the ShowOnlyMaxMin setting

### ShowOnlyMaxMin (Boolean)
- **Default**: `True` (ON)
- **Location**: Diagram object → Properties → Diagram → ShowOnlyMaxMin
- **Description**: Controls which values are labeled when DrawText is enabled

**When ON**: Only shows maximum and minimum values
**When OFF**: Shows all sampled values along the member

## Usage Scenarios

### 1. Clean Diagrams (Default) ✅
```
DrawText: OFF
ShowOnlyMaxMin: (doesn't matter)
Result: No text labels, clean visualization
```

**Best for**:
- Initial overview
- Presentations
- When you just want to see the shape of the diagram

### 2. Critical Values Only
```
DrawText: ON
ShowOnlyMaxMin: ON
Result: Only max and min values labeled
```

**Best for**:
- Design checks (you need peak values)
- When segment count is high (16+ segments)
- Readable diagrams with key information
- Most structural engineering workflows

**Example**:
```
Beam with 16 segments × 11 sample points = 176 total values
With ShowOnlyMaxMin ON: Only 2-4 labels shown (max and min for each diagram type)
```

### 3. All Values Visible
```
DrawText: ON
ShowOnlyMaxMin: OFF
Result: All sampled values labeled
```

**Best for**:
- Low segment counts (2-4 segments)
- Detailed analysis
- When you need every data point
- Academic/teaching purposes

**Warning**: With high segment counts this becomes cluttered and hard to read.

## How It Works

### Value Selection Logic

When `ShowOnlyMaxMin` is enabled:

1. **Find Maximum**: Identifies the point with the highest absolute value
2. **Find Minimum**: Identifies the point with the lowest value (most negative)
3. **Filter Zeros**: Skips values that are effectively zero (< 1e-9)
4. **Display**: Shows only these critical values

**Example for Moment Diagram**:
```
Sampled values: [0, 125, 250, 375, 500, 425, 350, 275, 200, 125, 0]

ShowOnlyMaxMin OFF: All 11 values labeled
ShowOnlyMaxMin ON:  Only "500" (max) and "0" (ends) labeled
```

### Zero Suppression

Zero or near-zero values are automatically hidden when using ShowOnlyMaxMin to avoid cluttering the diagram with "0.0000e+00" labels at supports or endpoints.

## Performance Notes

### Text Label Impact

Text labels are generated as 3D wire string geometry, which impacts performance:

- **DrawText OFF**: Fastest diagram generation, minimal geometry
- **ShowOnlyMaxMin ON**: Moderate performance (2-4 text objects)
- **ShowOnlyMaxMin OFF**: Slower with high segment counts (100+ text objects)

**Recommendation**: Keep `DrawText = False` for regular work, enable only when you need specific values.

## Real-World Examples

### Example 1: Simple Beam Analysis
```
Configuration:
- 1 beam, 5000mm long
- 4 segments per member
- Support at ends
- Point load at midspan

Settings:
- DrawText: ON
- ShowOnlyMaxMin: ON

Result:
- Moment diagram shows maximum moment at midspan
- Shear diagram shows max shear at supports
- Clean, readable output with critical design values
```

### Example 2: Complex Frame (16+ segments)
```
Configuration:
- Multiple members
- 16 segments per member
- Multiple load cases
- Detailed mesh for accuracy

Settings:
- DrawText: OFF (initially)
- ShowOnlyMaxMin: ON

Workflow:
1. Generate diagrams with DrawText OFF for quick overview
2. Enable DrawText to see max/min values
3. Never need ShowOnlyMaxMin OFF (too cluttered)

Result:
- Fast initial visualization
- Critical values available when needed
- Readable diagrams despite high segment count
```

## Related Properties

These properties also affect diagram appearance:

### FontHeight (Integer)
- **Default**: 100
- **Description**: Size of text labels
- **Range**: 50-500 recommended
- **Note**: Larger values = easier to read but takes more space

### Precision (Integer)
- **Default**: 2
- **Description**: Number of decimal places (scientific notation)
- **Range**: 0-6
- **Example**:
  - Precision 2: `1.23e+03`
  - Precision 4: `1.2345e+03`

## Troubleshooting

### Problem: Can't see any text labels
**Check**:
1. Is `DrawText` enabled? (must be ON)
2. Are the values non-zero? (zero values are suppressed)
3. Is `FontHeight` too small? (increase to 100-200)

### Problem: Too many labels, diagram is cluttered
**Solution**:
1. Enable `ShowOnlyMaxMin`
2. Or reduce segment count (fewer sample points)
3. Or disable `DrawText` entirely

### Problem: Important mid-span values not shown
**This is expected**: `ShowOnlyMaxMin` only shows the absolute maximum and minimum across the entire member. If you need all values, set `ShowOnlyMaxMin = False`, but be prepared for clutter.

### Problem: Text labels overlap
**Solutions**:
1. Use `ShowOnlyMaxMin` to show fewer labels
2. Reduce `FontHeight`
3. Increase diagram scale properties (ScaleMoment, etc.) to spread out the diagram

## Summary

**For most users**:
- Leave `DrawText = False` for clean diagrams
- Leave `ShowOnlyMaxMin = True` as insurance
- Enable `DrawText` when you need to see peak values
- You'll get exactly the critical values you need without clutter

**Benefits of ShowOnlyMaxMin**:
- ✅ Readable diagrams even with fine meshes
- ✅ Shows critical design values (max moment, max shear)
- ✅ No manual calculation needed
- ✅ Good balance of information vs. clarity
- ✅ Faster diagram generation than showing all values

---

**Feature Added**: 2025-12-26
**Files Modified**: [diagram.py](diagram.py)
**Related Features**:
- [AUTO_MESH_REFINEMENT.md](AUTO_MESH_REFINEMENT.md) - Why you can now use higher segment counts
- [FINAL_FIXES_SUMMARY.md](FINAL_FIXES_SUMMARY.md) - Complete session overview
