<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES" sourcelanguage="en">
<context>
    <name>Log</name>
    <message>
        <location filename="../../init_gui.py" line="30"/>
        <source>Switching to StructureTools</source>
        <translation>Cambiando a entorno de trabajo StructureTools</translation>
    </message>
    <message>
        <location filename="../../init_gui.py" line="32"/>
        <source>Run a numpy function:</source>
        <translation>Ejecutar una función de numpy</translation>
    </message>
</context>
<context>
    <name>Workbench</name>
    <message>
        <location filename="../../init_gui.py" line="36"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../../init_gui.py" line="12"/>
        <source>template workbench</source>
        <translation>Entorno de trabajo plantilla</translation>
    </message>
    <message>
        <location filename="../../init_gui.py" line="13"/>
        <source>a simple template workbench</source>
        <translation>Una plantilla simple de entorno de trabajo</translation>
    </message>
</context>
</TS>
