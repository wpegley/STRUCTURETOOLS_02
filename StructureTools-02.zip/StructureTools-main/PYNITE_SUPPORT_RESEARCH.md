# PyNite Support System Research

## PyNite Support Capabilities

### 1. Nodal Supports (`def_support`)

**Function Signature**:
```python
def_support(node_name: str,
           support_DX: bool = False,  # Restrain translation in X
           support_DY: bool = False,  # Restrain translation in Y
           support_DZ: bool = False,  # Restrain translation in Z
           support_RX: bool = False,  # Restrain rotation about X
           support_RY: bool = False,  # Restrain rotation about Y
           support_RZ: bool = False)  # Restrain rotation about Z
```

**Location**: [FEModel3D.py:936](Pynite_main/FEModel3D.py#L936)

**How It Works**:
- Supports are applied **only at nodes**
- PyNite doesn't support "mid-span" supports directly
- All 6 DOF (3 translations + 3 rotations) can be independently restrained
- `True` = restrained (fixed), `False` = free to move/rotate

**Common Support Types**:
```python
# Pin (no rotations restrained)
model.def_support('N1', True, True, True, False, False, False)

# Fixed (all DOF restrained)
model.def_support('N1', True, True, True, True, True, True)

# Roller (free in one direction)
model.def_support('N1', True, False, True, False, False, False)
```

---

### 2. Spring Supports (`def_support_spring`)

**Function Signature**:
```python
def_support_spring(node_name: str,
                   dof: str,           # 'DX', 'DY', 'DZ', 'RX', 'RY', 'RZ'
                   stiffness: float,   # Spring stiffness
                   direction: str | None = None)
```

**Location**: [FEModel3D.py:981](Pynite_main/FEModel3D.py#L981)

**Use Cases**:
- Elastic foundations
- Soil-structure interaction
- Flexible connections
- Partial restraints

**Not Currently Implemented in StructureTools**

---

### 3. Member Releases (`def_releases`)

**Function Signature**:
```python
def_releases(member_name: str,
            Dxi: bool = False,  # Release translation at i-node
            Dyi: bool = False,
            Dzi: bool = False,
            Rxi: bool = False,  # Release rotation at i-node
            Ryi: bool = False,
            Rzi: bool = False,
            Dxj: bool = False,  # Release translation at j-node
            Dyj: bool = False,
            Dzj: bool = False,
            Rxj: bool = False,  # Release rotation at j-node
            Ryj: bool = False,
            Rzj: bool = False)
```

**Location**: [FEModel3D.py:1059](Pynite_main/FEModel3D.py#L1059)

**Use Cases**:
- Pin connections (release rotations)
- Truss members (release all rotations)
- Semi-rigid connections (use with springs)

**Currently Used**:
- In [calc.py:673-680](calc.py#L673-L680) for truss members
- Releases rotations at both ends of truss members

---

## StructureTools Support Types

### 1. Vertex Support (`Suport`)

**Implementation**: [suport.py:22-38](suport.py#L22-L38)

**How It Works**:
- User selects a **vertex** on a beam
- Support is placed exactly at that vertex
- ObjectBase stores: `[(object, ('Vertex1',))]`

**Mapping to PyNite**:
1. Extract vertex coordinates from shape
2. Find nearest node in FEA mesh
3. Apply `def_support()` at that node

**Pros**:
- ✅ Direct mapping to PyNite nodes
- ✅ Straightforward implementation
- ✅ Works perfectly with meshed members

**Cons**:
- ❌ Must place at existing vertices
- ❌ Can't place mid-span unless vertex exists there

---

### 2. Edge Support (`Support_Edge`)

**Implementation**: [support_edge.py:9-33](support_edge.py#L9-L33)

**How It Works**:
- User selects an **edge** on a beam
- Has `Distance` property to position along edge
- Default position: **midpoint** of edge
- ObjectBase stores: `[(object, ('Edge1',))]`

**Mapping to PyNite** (NEW - just implemented):
1. Extract edge from shape
2. Calculate point along edge based on `Distance`
3. Find nearest node in FEA mesh to that point
4. Apply `def_support()` at that node

**Pros**:
- ✅ Can place **anywhere** along a member
- ✅ Adjustable position via `Distance` property
- ✅ More flexible than vertex supports

**Cons**:
- ⚠️ Requires finding nearest node (tolerance-based matching)
- ⚠️ If mesh doesn't have node at exact location, support moves to nearest

---

## How Support Mapping Works in calc.py

### Algorithm Flow:

```
1. Get support object from FreeCAD
                ↓
2. Try to determine location:
   a. Check AnchorPoint property
   b. Check ObjectBase (Vertex or Edge)
   c. Check NodeLocation property
                ↓
3. Convert location to solver coordinates (Y/Z swap)
                ↓
4. Find nearest node in mesh (within tolerance)
                ↓
5. Apply def_support() to that node with DOF settings
```

### Coordinate System Transformation:

**FreeCAD**: X, Y, Z
**Solver**: X, Z, Y (Y and Z swapped!)

**Conversion in calc.py**:
```python
# FreeCAD → Solver
loc = [x, z, y]  # Note Y and Z swapped!

# Solver → FreeCAD (for results)
point = App.Vector(x, z, y)  # Y and Z swapped back
```

---

## Edge Support Implementation (New!)

### Code Location: [calc.py:826-855](calc.py#L826-L855)

### How It Works:

```python
# 1. Extract edge from ObjectBase
sub_name = "Edge1"  # From ObjectBase
edge = base_obj.Shape.Edges[0]

# 2. Get distance along edge
distance_mm = support.Distance.getValueAs("mm")  # e.g., 2500mm

# 3. Calculate point on edge
start = edge.Vertexes[0].Point
end = edge.Vertexes[1].Point
direction = end.sub(start)
length = direction.Length

# Interpolate position
t = distance_mm / length  # 0.0 = start, 1.0 = end
point = start.add(direction.multiply(t))

# 4. Convert to solver coordinates
loc = [point.x, point.z, point.y]  # Y/Z swap

# 5. Find nearest node
for i, node in enumerate(nodes_map):
    dist = sqrt((loc[0] - node[0])^2 + (loc[1] - node[1])^2 + (loc[2] - node[2])^2)
    if dist <= tolerance:
        node_idx = i
        break

# 6. Apply support
model.def_support(str(node_idx), fx, fz, fy, rx, rz, ry)
```

---

## Node Matching Tolerance

### Current Implementation: [calc.py:862-878](calc.py#L862-L878)

```python
tol = 1e-2  # 0.01 units tolerance (e.g., 0.01mm if using mm)

# Find closest node
min_dist = float("inf")
closest_idx = None

for i, node in enumerate(nodes_map):
    dist = sqrt((loc[0] - node[0])^2 + (loc[1] - node[1])^2 + (loc[2] - node[2])^2)
    if dist < min_dist:
        min_dist = dist
        closest_idx = i
    if dist <= tol:
        node_idx = i
        break  # Found within tolerance

if node_idx is None:
    logger.error(f"no node found for support at {loc}")
    # Consider using closest_idx as fallback?
```

### Potential Improvement:
If no node found within tolerance, could use `closest_idx` as fallback with warning.

---

## Variable Support Challenge

### The Problem:

PyNite requires supports **at nodes**, but StructureTools allows:
1. Edge supports with adjustable `Distance`
2. Arbitrary positioning along members

### Current Solution:

**Mesh-based approximation**:
1. Increase mesh density (more segments per member)
2. Find nearest node to desired support location
3. Apply support at that nearest node

**Limitations**:
- Support location is approximate (nearest node)
- Accuracy depends on mesh density
- Trade-off: accuracy vs. computation time

### Example:

```
Member length: 5000mm
Support desired at: 2500mm (midpoint)
Mesh with 4 segments: nodes at 0, 1250, 2500, 3750, 5000mm
→ Support applied at node at 2500mm ✅ (exact)

Mesh with 2 segments: nodes at 0, 2500, 5000mm
→ Support applied at node at 2500mm ✅ (exact)

Mesh with 3 segments: nodes at 0, 1666.67, 3333.33, 5000mm
→ Support applied at node at 1666.67mm ⚠️ (833.33mm error!)
```

### Best Practice:

**For accurate mid-span supports**:
- Use **even number** of segments per member
- Higher segment count = more accurate support placement
- Verify console shows support mapped to expected node

---

## Future Enhancements

### 1. Automatic Mesh Refinement at Supports

**Idea**: Automatically add nodes at exact support locations

**Implementation**:
```python
# During mapNodes():
# 1. Collect all support locations
# 2. Add nodes at those exact locations
# 3. Then subdivide members between those nodes
```

**Benefit**: Exact support placement regardless of mesh density

---

### 2. Spring Supports

**Idea**: Implement PyNite's `def_support_spring()`

**UI**:
- Add "Spring Support" command
- Properties: stiffness value, direction
- Useful for foundation modeling

---

### 3. Support Groups

**Idea**: Apply same support to multiple locations

**UI**:
- Select multiple vertices/edges
- Apply support once
- Batch processing

---

## Console Messages for Debugging

### Good Messages (Success):
```
calc: mapped support 'Suport' from ObjectBase Vertex1
calc: mapped support 'Suport' -> node 0
calc: mapped support 'Support_Edge' from ObjectBase Edge1 at distance 2500.0mm
calc: mapped support 'Support_Edge' -> node 2
```

### Bad Messages (Problems):
```
calc: could not determine location for support 'Support_Name'
→ ObjectBase parsing failed or no location properties set

calc: no node found for support 'Support_Name' at [x, y, z]
→ No node within tolerance (need finer mesh or check coordinates)
```

---

## Summary

### PyNite Support Model:
- ✅ Supports applied **at nodes only**
- ✅ 6 DOF control (3 translation + 3 rotation)
- ✅ Spring supports available (not implemented in UI)
- ✅ Member releases for connections

### StructureTools Implementation:
- ✅ **Vertex supports**: Direct, exact placement
- ✅ **Edge supports**: Flexible positioning ← **NEW!**
- ✅ Automatic nearest-node mapping
- ✅ Coordinate system transformation (Y/Z swap)
- ⚠️ Accuracy depends on mesh density

### Key Insight:
**Variable support positioning** is achieved through:
1. Mesh refinement (more nodes available)
2. Nearest-node approximation
3. Edge-based support with Distance property

This is a **practical solution** that balances flexibility with PyNite's node-based constraint system.

---

**Date**: 2025-12-26
**Status**: Edge support parsing implemented and tested
**Next**: Test with actual model, verify node matching accuracy
