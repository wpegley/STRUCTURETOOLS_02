# Unit System Fixes - Complete Implementation
## Date: 2025-12-26

## Overview
This document describes the comprehensive fixes applied to the StructureTools unit system to achieve a "bulletproof" approach with consistent, predictable behavior.

---

## Problems Identified

### 1. **Density Conversion Bug** (CRITICAL)
**Issue**: Conversion from kg/m³ to kN/m³ used incorrect multiplier (×10 instead of ×9.81/1000)

**Physics**:
- Force = mass × acceleration
- 1 kN = 1000 N = 1000 kg⋅m/s²
- Therefore: kg/m³ → kN/m³ = kg/m³ × 9.81/1000 = kg/m³ × 0.00981

**Example**: Steel at 7850 kg/m³
- **Wrong**: 7850 × 10 = 78500 → 78.5 kN/m³
- **Correct**: 7850 × 0.00981 = 77.0 kN/m³

### 2. **Unit System Mismatch**
**Issue**: Internal solver using mm/N caused huge numbers and precision issues

**Problems**:
- Beam lengths: 5000 mm instead of 5 m
- Moments: 1000000 N⋅mm instead of 1 kN⋅m
- Deflections: 0.001 mm instead of 1 mm

### 3. **Distributed Load Property Type**
**Issue**: PropertyForce (stores Force in N) used for UDL which needs force/length (kN/m)

**Problem**:
- User enters: 10 (expecting 10 kN/m)
- FreeCAD stores: 10000 N (PropertyForce converts kN → N)
- Code needs: 10 kN/m for solver
- Missing: Conversion from Force to Force/Length

### 4. **Deflection Display Units**
**Issue**: Results in meters but users expect millimeters

**User requirement**: "Deflection needs to be returned in mm's so we will need to divide the result after calc by 1000" [multiply by 1000 for m→mm]

---

## Solutions Implemented

### Fix 1: Corrected Density Conversion
**File**: [calc.py:848-853](calc.py#L848-L853)

**Before**:
```python
density = float(App.Units.Quantity(material.Density).getValueAs('t/m^3')) * 10
density = float(App.Units.Quantity(density, 'kN/m^3').getValueAs(f"{unitForce}/{unitLength}^3"))
```

**After**:
```python
# CORRECTED: kg/m³ → kN/m³ using g=9.81 m/s²
# density [kN/m³] = density [kg/m³] × 9.81/1000
density_kg_m3 = float(App.Units.Quantity(material.Density).getValueAs('kg/m^3'))
density_kN_m3 = density_kg_m3 * 9.81 / 1000
# Convert to target unit system
density = float(App.Units.Quantity(density_kN_m3, 'kN/m^3').getValueAs(f"{unitForce}/{unitLength}^3"))
```

**Result**: Steel now correctly 77.0 kN/m³ (was 78.5)

---

### Fix 2: Switched to m/kN Unit System
**File**: [unit_manager.py:195-203](unit_manager.py#L195-L203)

**Changed**: Default unit schemas 0 (Standard) and 6 (Metric small parts) from mm/N to m/kN

**Before**:
```python
schema_map = {
    0: UNIT_SI_MM_N,      # Standard
    6: UNIT_SI_MM_N,      # Metric small parts
}
```

**After**:
```python
schema_map = {
    0: UNIT_SI_M_KN,      # Standard (CHANGED: m/kN better for structural analysis)
    6: UNIT_SI_M_KN,      # Metric small parts (CHANGED: m/kN better)
}
```

**Benefits**:
- Beam lengths: 5 m (readable)
- Moments: 10 kN⋅m (engineering scale)
- Deflections: 0.005 m = 5 mm (convertible)
- Forces: 10 kN (typical UDL scale)

---

### Fix 3: Distributed Load Conversion
**File**: [calc.py:1068-1088](calc.py#L1068-L1088) and [calc.py:1113-1114](calc.py#L1113-L1114)

**Added new conversion function**:
```python
def _force_per_length_to_unit(force_val):
    """Convert PropertyForce (stored as force in N) to force/length for distributed loads.

    The PropertyForce stores force in N. We need to interpret this as kN/m.
    Since the property value represents the UDL intensity:
    - User enters 10 expecting 10 kN/m
    - FreeCAD stores as 10000 N (PropertyForce converts kN→N)
    - We need: 10 kN/m for solver

    Conversion: N → kN/m = (N / 1000) / (mm / 1000) = N / mm (numerically equal!)
    Then convert from N/mm to target unitForce/unitLength.
    """
    if hasattr(force_val, 'getValueAs'):
        # Get value in N (base unit)
        force_n = float(force_val.getValueAs('N'))
        # Interpret as kN/m: N → kN/m requires ÷1000
        force_kn_per_m = force_n / 1000.0
        # Now convert to target unit system
        udl_quantity = App.Units.Quantity(force_kn_per_m, 'kN/m')
        return float(udl_quantity.getValueAs(f'{unitForce}/{unitLength}'))
    return float(force_val)
```

**Updated load application**:
```python
# BEFORE:
w1 = _force_to_unit(load.InitialLoading)
w2 = _force_to_unit(load.FinalLoading)

# AFTER:
w1 = _force_per_length_to_unit(load.InitialLoading)
w2 = _force_per_length_to_unit(load.FinalLoading)
```

**Updated default values**:
**File**: [load_distributed.py:17-20](load_distributed.py#L17-L20)
```python
# BEFORE:
obj.addProperty("App::PropertyForce", "InitialLoading", "Distributed",
                "Initial loading (load per unit length)").InitialLoading = 10000000

# AFTER:
# Property stores force/length in kN/m (typical structural UDL)
# FreeCAD will display with units based on schema
obj.addProperty("App::PropertyForce", "InitialLoading", "Distributed",
                "Initial loading in kN/m").InitialLoading = 10000  # 10 kN
```

**Result**: User enters 10, system correctly interprets as 10 kN/m

---

### Fix 4: Deflection Display Conversion
**File**: [calc.py:1393-1410](calc.py#L1393-L1410)

**Added conversion from m to mm**:
```python
# Deflection
# PyNite returns deflection in solver units (m for our m/kN system)
# Convert to mm for display (user requirement: deflection in mm)
deflection_scale = 1000.0 if unitLength == 'm' else 1.0

xs_dy, dy = member.deflection_array('dy', obj.NumPointsDeflection)
xs_dz, dz = member.deflection_array('dz', obj.NumPointsDeflection)

# Scale deflections from m to mm
dy_mm = [v * deflection_scale for v in dy]
dz_mm = [v * deflection_scale for v in dz]

deflectiony.append(','.join(str(v) for v in xs_dy) + ';' + ','.join(str(v) for v in dy_mm))
deflectionz.append(','.join(str(v) for v in xs_dz) + ';' + ','.join(str(v) for v in dz_mm))
minDeflectiony.append(member.min_deflection('dy') * deflection_scale)
minDeflectionz.append(member.min_deflection('dz') * deflection_scale)
maxDeflectiony.append(member.max_deflection('dy') * deflection_scale)
maxDeflectionz.append(member.max_deflection('dz') * deflection_scale)
```

**Result**: Deflections displayed in mm (e.g., 5.2 mm instead of 0.0052 m)

---

## Unit Flow Summary

### Input (FreeCAD → PyNite)

| Property | FreeCAD Storage | User Enters | Conversion | Solver Receives |
|----------|----------------|-------------|------------|-----------------|
| Line length | mm (base unit) | 5000 mm | ÷1000 | 5 m |
| Section area | mm² | 10000 mm² | ÷1e6 | 0.01 m² |
| Moment of inertia | mm⁴ | 1e8 mm⁴ | ÷1e12 | 1e-4 m⁴ |
| Material density | kg/m³ | 7850 kg/m³ | ×0.00981 | 77.0 kN/m³ |
| UDL | N (PropertyForce) | 10 (kN/m) | stored as 10000 N → ÷1000 | 10 kN/m |
| Point load | N (PropertyForce) | 50 (kN) | stored as 50000 N → direct | 50 kN |

### Output (PyNite → Display)

| Result | Solver Returns | Conversion | Display Shows | Unit Label |
|--------|---------------|------------|---------------|------------|
| Deflection | 0.005 m | ×1000 | 5.0 | mm |
| Moment | 10.0 kN⋅m | (none) | 10.0 | kN⋅m |
| Shear | 25.0 kN | (none) | 25.0 | kN |
| Axial force | 100.0 kN | (none) | 100.0 | kN |

---

## Self-Weight Calculation

With corrected density and m/kN units:

```
Given:
- Section area: A = 10000 mm² = 0.01 m²
- Member length: L = 5000 mm = 5 m
- Material density: ρ = 7850 kg/m³ = 77.0 kN/m³

Volume: V = A × L = 0.01 m² × 5 m = 0.05 m³
Mass: m = ρ × V = 7850 kg/m³ × 0.05 m³ = 392.5 kg
Weight: W = m × g = 392.5 kg × 9.81 m/s² = 3850 N = 3.85 kN
UDL: w = W / L = 3.85 kN / 5 m = 0.77 kN/m
```

**PyNite's `add_member_self_weight()` does this automatically** when:
- Density is in kN/m³ (✓ now correct: 77.0)
- Area is in m² (✓ converted correctly)
- Length is in m (✓ internal unit system)

---

## Testing Checklist

### Test 1: Density Conversion
- [ ] Create steel beam (7850 kg/m³)
- [ ] Enable self-weight
- [ ] Run analysis
- [ ] Check console: density should be ~77.0 kN/m³ (not 78.5)

### Test 2: Unit System
- [ ] Create 5m beam
- [ ] Verify solver receives length = 5 (not 5000)
- [ ] Check console logs for unit values

### Test 3: Distributed Load
- [ ] Create distributed load, enter value 10
- [ ] System should store as 10000 N (PropertyForce)
- [ ] Run analysis
- [ ] Check console: "applied distributed load (10.0 to 10.0 kN/m)"
- [ ] NOT: "100000 kN/m" or other wrong scale

### Test 4: Deflection Display
- [ ] Run analysis on loaded beam
- [ ] Check MaxDeflectionY/Z values
- [ ] Should be in mm scale (e.g., 5.2 mm)
- [ ] NOT in m scale (e.g., 0.0052)

### Test 5: Self-Weight
- [ ] Create beam: 200×100mm section, 5m length, steel
- [ ] Enable self-weight
- [ ] Run analysis
- [ ] Expected UDL: ~0.155 kN/m (20000 mm² = 0.02 m² × 77 kN/m³ = 1.54 kN / 10m ≈ 0.154 kN/m)

---

## Files Modified

1. **[calc.py](calc.py)**
   - Lines 848-853: Density conversion fix
   - Lines 1068-1088: New `_force_per_length_to_unit()` function
   - Lines 1113-1114: Use new conversion for distributed loads
   - Lines 1393-1410: Deflection m→mm conversion

2. **[unit_manager.py](unit_manager.py)**
   - Lines 195-203: Changed default schemas to m/kN

3. **[load_distributed.py](load_distributed.py)**
   - Lines 17-20: Updated default values and help text

---

## Migration Notes

### For Existing Models

**Important**: Models created with the old mm/N system will need values adjusted:

1. **Distributed loads**: If you previously entered 10000000 (expecting 10 kN/m in old system), now enter just 10.
2. **Deflection results**: Old results in mm scale, new results also in mm (no change in display).
3. **Moments/forces**: Old results need no adjustment (forces always in kN).

### Unit Schema Compatibility

If users have **custom unit schema** set (not schema 0 or 6), behavior unchanged. Only schemas 0 and 6 now default to m/kN.

---

## Known Limitations

### 1. PropertyForce for UDL
**Issue**: Still using PropertyForce instead of a proper force-per-length property type

**Why not changed**: FreeCAD doesn't have a built-in "PropertyForcePerLength" type. Creating a custom property type would be complex.

**Mitigation**: Clear documentation and conversion function handle this correctly.

### 2. Unit Review Dialog
**Status**: Still present with unit correction features

**Recommendation**: Could be simplified or removed now that base units are correct. Unit correction should rarely be needed with proper input.

---

## Summary

### What Was Broken
1. ❌ Density conversion using ×10 instead of ×9.81/1000
2. ❌ Unit system using mm/N causing large numbers
3. ❌ Distributed loads using PropertyForce without proper conversion
4. ❌ Deflection results in meters without conversion to mm

### What Is Now Fixed
1. ✅ Density correctly converts using physics: kg/m³ × 9.81/1000 = kN/m³
2. ✅ Unit system uses m/kN for readable engineering values
3. ✅ Distributed loads properly convert PropertyForce(N) → kN/m
4. ✅ Deflection results scaled m→mm for display

### Expected Behavior
- **User enters 10 for UDL**: System correctly interprets as 10 kN/m
- **Deflection of 5mm**: Displayed as 5.0 (not 0.005)
- **Steel self-weight**: Correctly calculated using 77.0 kN/m³ (not 78.5)
- **Moments**: Displayed in kN⋅m at engineering scale

---

**Session Date**: 2025-12-26
**Status**: ✅ Complete - Ready for Testing
**Restart Required**: Yes - Restart FreeCAD to load updated code
**Priority Fixes**: All critical unit system bugs addressed
