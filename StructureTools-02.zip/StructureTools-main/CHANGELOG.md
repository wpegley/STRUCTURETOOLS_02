# Changelog

All notable changes to StructureTools will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased] - 2025-12-26

### Added
- **NEW: Comprehensive input validation** for all calculation functions
  - Segments per member validation (range: 1-100)
  - Tolerance parameter validation (must be > 0)
  - Material property validation (E > 0, -1 ≤ ν ≤ 0.5, ρ > 0)
  - Section property validation (A > 0, I ≥ 0, J ≥ 0)
- **NEW: Shared UI helpers module** (`ui_helpers.py`)
  - Centralized error/warning/info message dialogs
  - Eliminates code duplication across modules
  - Consistent user interface experience
- **NEW: Type hints** added to critical calculation functions
  - Better IDE support and code documentation
  - Improved code maintainability
- **NEW: Test suite framework** in `tests/` directory
  - Template tests for input validation
  - Framework for structural calculation validation
  - Test README with implementation guide

### Changed
- **SECURITY: Fixed path traversal vulnerabilities**
  - All ICONPATH and TRANSLATIONSPATH now use absolute paths
  - Prevents potential directory traversal attacks
- **IMPROVED: Error handling across all modules**
  - Replaced bare `except:` clauses with specific exception types
  - Added detailed error logging with `logger` module
  - Better error messages explaining what went wrong and how to fix it
- **IMPROVED: Better validation error messages**
  - Errors now explain the specific issue and valid ranges
  - Users get helpful guidance on how to correct problems
- **IMPROVED: Code organization**
  - Removed duplicate `show_error_message()` functions from 5 files
  - Standardized imports across all modules
  - Cleaner module structure

### Fixed
- **CRITICAL: Fixed pyproject.toml dependencies syntax**
  - Changed from malformed `["['numpy','scipy']"]` to proper `["numpy>=1.20.0", "scipy>=1.7.0"]`
  - Added version pinning for better compatibility
- **Fixed: Removed unsafe subprocess code**
  - Deleted commented-out automatic pip install code
  - Dependencies should be managed through proper installation
- **Fixed: Removed print() debugging statements**
  - Replaced with proper logger.info() calls
  - Better debugging and production logging

### Removed
- Commented-out code blocks that were cluttering the source
- Unused property definitions in load_distributed.py
- Unsafe subprocess import statement in init_gui.py
- Empty placeholder functions

## [0.0.1] - Previous Release

### Added
- Initial alpha release
- Basic FEA integration with PyNite solver
- Member, material, and section definition tools
- Support (boundary condition) definition
- Distributed and nodal load application
- Structural analysis calculation
- Result visualization with diagrams
- GUI integration with FreeCAD workbench system
- Multi-language support (English, Spanish)

### Known Issues in v0.0.1
- No input validation (FIXED in unreleased)
- Bare except clauses masking errors (FIXED in unreleased)
- Path traversal vulnerabilities (FIXED in unreleased)
- No test suite (PARTIALLY FIXED in unreleased)
- Duplicate code across modules (FIXED in unreleased)
- Poor error messages (FIXED in unreleased)
- Malformed dependencies in pyproject.toml (FIXED in unreleased)

---

## Migration Guide

### Upgrading from v0.0.1

#### For Users
- **No breaking changes** - All existing functionality preserved
- Better error messages will help diagnose issues
- Invalid inputs now properly rejected with helpful messages

#### For Developers
- Import `show_error_message` from `ui_helpers` instead of defining locally:
  ```python
  # OLD:
  def show_error_message(msg):
      msg_box = QtWidgets.QMessageBox()
      # ...

  # NEW:
  from .ui_helpers import show_error_message
  ```

- Use logger instead of print():
  ```python
  # OLD:
  print(f"Debug: {value}")

  # NEW:
  from . import logger
  logger.info(f"module: {value}")
  ```

- Handle specific exceptions instead of bare except:
  ```python
  # OLD:
  try:
      operation()
  except:
      show_error_message("Error")

  # NEW:
  try:
      operation()
  except ValueError as exc:
      logger.exception(f"module: operation failed: {exc}")
      show_error_message(f"Invalid value: {exc}")
  except Exception as exc:
      logger.exception(f"module: unexpected error: {exc}")
      show_error_message(f"Unexpected error: {exc}")
  ```

---

## Security Advisories

### Path Traversal Fix (2025-12-26)
- **Severity:** Low
- **Impact:** Potential unauthorized file access through manipulated paths
- **Fixed in:** Unreleased (pending next version)
- **Mitigation:** All file paths now use `os.path.abspath()` for validation

### Input Validation (2025-12-26)
- **Severity:** Medium
- **Impact:** Invalid inputs could cause crashes or incorrect calculations
- **Fixed in:** Unreleased (pending next version)
- **Mitigation:** Comprehensive input validation added to all calculation functions

---

## Credits

### Code Audit and Security Improvements (2025-12-26)
- Comprehensive security audit performed
- Input validation implementation
- Error handling improvements
- Code quality enhancements
- Test framework creation

### Original Development
- **Maintainer:** Maykow Menezes
- **Email:** eng.maykowmenezes@gmail.com
- **Support:** [Patreon](https://patreon.com/StructureTools) | [ApoiaSe](https://apoia.se/structuretools)

---

## Future Roadmap

### Planned for Next Release
- [ ] Complete test suite implementation
- [ ] Performance optimizations (spatial indexing for nodes)
- [ ] Configuration system for user preferences
- [ ] Better documentation and API reference
- [ ] CI/CD pipeline with automated testing

### Long-term Goals
- [ ] Separate PyNite as external dependency
- [ ] Support for additional FEA solvers
- [ ] Enhanced result export options
- [ ] Report generation functionality
- [ ] Integration with FreeCAD addon manager
- [ ] Design code checking (separate workbench)

---

For more information, see:
- [README.md](README.md) - Project overview and installation
- [tests/README.md](tests/README.md) - Testing guide
- [GitHub Issues](https://github.com/maykowsm/StructureTools/issues) - Bug reports and feature requests
